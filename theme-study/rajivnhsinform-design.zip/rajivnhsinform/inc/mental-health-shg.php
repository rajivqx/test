<?php
add_action('admin_head', 'shg_mental_custom_css');

function shg_mental_custom_css() {
  echo '<style>
  
.post-type-mental-health-shg .jpn-tabs-activated .acf-row-handle {

	display: block !important;
}
.post-type-mental-health-shg .acf-repeater .acf-row-handle .acf-icon.-minus {
    top: 142% !important;
}

.post-type-mental-health-shg .jpn-tabs-activated > .jpn-acf-tabs > .nav > ul > li > .jpn-acf-tab.active:after {
  content: "" !important;
  width:0px !important;
}

.jpn-tabs-activated.jpn-vertical > .jpn-acf-tabs > .nav > ul > li > .jpn-tab-hover{
  left: 116%;
  min-width: 46px !important;
  transform: rotate(180deg);
}
.jpn-tabs-activated.jpn-vertical > .jpn-acf-tabs > .nav > ul > li > .jpn-tab-hover .dashicons-clipboard{
  display:none !important;
}
.jpn-tabs-activated > .jpn-acf-tabs > .nav > ul > li > .jpn-tab-hover > a{
  transform: rotate(180deg);
}
</style>';
  ?>
  <script>
  	jQuery(document).ready(function(){

      jQuery('.nhs-mental-shg-btn .acf-button').last().hide();

  });

  </script>
<?php
}