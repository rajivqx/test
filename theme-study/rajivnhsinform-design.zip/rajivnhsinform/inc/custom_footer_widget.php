<?php
// Creating the widget
class Custom_footer_widget extends WP_Widget
{
    function __construct()
    {
        parent::__construct(
        // Base ID of your widget
            'Custom_footer_widget',
        // Widget name will appear in UI
            __('Footer Bottom Widget', 'Custom_widget'),
        // Widget description
            array(
            'description' => __('Footer Bottom show footer content Widgets',
                                     'Custom_widget')
        ));
    }

    
    // Widget Backend
    public function form($instance)
    {
        if (isset($instance['copyright'])) {
            $copyright = $instance['copyright'];
        } else {
            $copyright = __('', 'cw_widget_domain');
        }
        
        if (isset($instance['footer_facebook_url'])) {
            $footer_facebook_url = $instance['footer_facebook_url'];
        } else {
            $footer_facebook_url = __('', 'cw_widget_domain');
        }

        if (isset($instance['footer_twitter_url'])) {
            $footer_twitter_url = $instance['footer_twitter_url'];
        } else {
            $footer_twitter_url = __('', 'cw_widget_domain');
        }

        if (isset($instance['footer_youtube_url'])) {
            $footer_youtube_url = $instance['footer_youtube_url'];
        } else {
            $footer_youtube_url = __('', 'cw_widget_domain');
        }

        if (isset($instance['footer_youtube_url'])) {
            $footer_youtube_url = $instance['footer_youtube_url'];
        } else {
            $footer_youtube_url = __('', 'cw_widget_domain');
        }

      // Widget admin form
?>
    <label for="<?php echo $this->get_field_id('copyright');?>">
        <?php _e('Copyright:');?>
    <input class="widefat" id="<?php echo $this->get_field_id('copyright');?>" 
    name="<?php echo $this->get_field_name('copyright');?>" type="text" value="<?php echo esc_attr($copyright);?>" />

    <label for="<?php echo $this->get_field_id('footer_facebook_url');?>">
        <?php _e('Facebook URL:');?>
    <input class="widefat" id="<?php echo $this->get_field_id('footer_facebook_url');?>" 
    name="<?php echo $this->get_field_name('footer_facebook_url');?>" type="text" value="<?php echo esc_attr($footer_facebook_url);?>" /> 


    <label for="<?php echo $this->get_field_id('footer_twitter_url');?>">
        <?php _e('Twitter URL:');?>
    <input class="widefat" id="<?php echo $this->get_field_id('footer_twitter_url');?>" 
    name="<?php echo $this->get_field_name('footer_twitter_url');?>" type="text" value="<?php echo esc_attr($footer_twitter_url);?>" /> 

    <label for="<?php echo $this->get_field_id('footer_youtube_url');?>">
        <?php _e('Youtube URL:');?>
    <input class="widefat" id="<?php echo $this->get_field_id('footer_youtube_url');?>" 
    name="<?php echo $this->get_field_name('footer_youtube_url');?>" type="text" value="<?php echo esc_attr($footer_youtube_url);?>" /> 

<?php }

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance){
        $instance          = array();

        $instance['copyright'] = (!empty($new_instance['copyright']))  ? strip_tags($new_instance['copyright']) : '';

        $instance['footer_facebook_url'] = (!empty($new_instance['footer_facebook_url']))  ? strip_tags($new_instance['footer_facebook_url']) : '';

        $instance['footer_twitter_url'] = (!empty($new_instance['footer_twitter_url']))  ? strip_tags($new_instance['footer_twitter_url']) : '';

        
         $instance['footer_youtube_url'] = (!empty($new_instance['footer_youtube_url']))  ? strip_tags($new_instance['footer_youtube_url']) : '';

        return $instance;
    }

    // Creating widget front-end
    // This is where the action happens

    public function widget($args, $instance)
    {
        $copyright  = apply_filters('widget_title', $instance['copyright']);

        $footer_facebook_url  =  $instance['footer_facebook_url'];
        $footer_twitter_url   =  $instance['footer_twitter_url'];
        $footer_youtube_url   =  $instance['footer_youtube_url'];

        // before and after widget arguments are defined by themes
        echo $args['before_widget']; ?>
                    <div class="col-6">
                            <p>&copy; <?php echo $copyright;?> </p>
                    </div>
                    <div class="col-6 text-end">
                        <ul class="social-list">
                            <?php if (!empty($footer_facebook_url)){ ?>
                                <li>
                                    <a href="<?php echo $footer_facebook_url;?>" target="_blank"
                                        class="social-icon facebook"><span class="visuallyhidden"></span>
                                    </a>
                                </li>
                             <?php } ?>
                             <?php if(!empty($footer_twitter_url)){ ?>
                            <li>
                                <a href="<?php echo $footer_twitter_url;?>" target="_blank" class="social-icon twitter"><span
                                        class="visuallyhidden"></span>
                                </a>
                            </li>
                            <?php } ?>
                            <?php if(!empty($footer_youtube_url)){ ?>
                            <li>
                                <a href="<?php echo $footer_youtube_url;?>" target="_blank"
                                    class="social-icon youtube">
                                    <span class="visuallyhidden"></span>
                                </a>
                            </li>
                         <?php } ?>
                        </ul>
                    </div>
                    <?php echo $args['after_widget'];
            }

} // Class cw_widget ends here

// Register and load the widget
function cw_load_widget(){
    register_widget('Custom_footer_widget');
}

add_action('widgets_init', 'cw_load_widget');