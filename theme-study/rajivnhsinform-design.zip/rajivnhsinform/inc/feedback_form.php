<?php 
add_action('wp_ajax_feedback_form', 'feedback_handler' );
add_action('wp_ajax_nopriv_feedback_form','feedback_handler'); 

function feedback_handler(){
 try {

    $email  		 = $_POST['email'];
   $message  	 = $_POST['message'];

 $email_html = '
<table  width="650" cellpadding="0" cellspacing="0" align="center" style="border:1px solid #acacac;">
  <tr>
    <td style="padding:25px;"><table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #14c991; padding-bottom:15px;">
      <tr>
        <td width="56%"><img src="'.site_url().'/wp-content/themes/careinfoscotland/assets/images/newlogo2.png" width="320"/></td>
        <td width="44%" style="text-align:right"></td>
        <td>&nbsp;</td>
      </tr>
    </table>
      <table  width="100%" cellpadding="0" cellspacing="0" align="center" style="padding-top:15px;">
		     <tr>
                <td width="50%"><strong>Which of the following terms apply to you?</strong>&nbsp;</td>
                <td width="50%">'.$email.'</td>
            </tr>
              <tr>
                <td width="50%"><strong>Message</strong></td>
                <td width="50%">'.$message.'</td>
              </tr>
      </table>
     </td>
  </tr>
</table>
';

    echo  json_encode([
    	'status'=>true,
    	'message'=>"Feedback submit successfully!", 
    	 'data'=>"",
    	],true);
    }catch (Exception $e) {
   // echo 'Caught exception: '. $e->getMessage() ."\n";
    echo  json_encode([
    	'status'=>false,
    	'message'=>$e->getMessage(),
    	'data'=>""
    ],true);
 }

 exit;
}