<?php
/**
 * The template for displaying all single posts of Mental health
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();
$shg_id = get_the_ID();
$description = get_field('description',$shg_id);
$post_date = get_the_date( 'j F Y', $shg_id);
?>

 <nav class="breadcrumb_section mental-shg-breadcrum" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item d-none d-md-block"><a href="<?php echo home_url();?>">Home</a></li>
                <li class="breadcrumb-item d-none d-md-block"><a href="<?php echo home_url();?>/illnesses-and-conditions">Illnesses and conditions</a></li>
                <li class="breadcrumb-item d-none d-md-block"><a href="<?php echo home_url();?>/illnesses-and-conditions/mental-health/">Mental health</a></li>
                <li class="breadcrumb-item"><a href="<?php echo home_url();?>/illnesses-and-conditions/mental-health#mental-health-self-help-guides">Mental health self-help guides</a></li>
            </ol>
        </div>
    </nav>

     <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h1><?php echo get_the_title($shg_id);?></h1>
                    <?php if(!empty($description)){
                    	echo '<p class="mb-0">'.$description.'</p>';
                	} ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->

     <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="row">
            		 <div class="col-lg-3">
                    <div class="pannel_wrapper_container navigate_container">
                        <div class="navigate_part">
                            <h2 class="navigate_heading">Navigate self-help guide</h2>
                            <a class="btn btn--primary btn--icon btn_guide navigate_btn" title="Problem solving guide">Navigate self-help guide <span class="icon"><i class="fa-solid fa-plus"></i></span></a>
                            <?php $shg_tabs = get_field('mental_health_shg',$shg_id);
                                  if(!empty($shg_tabs)){
                                     	$total_tabs =  count($shg_tabs);
                                  
                            		//echo '<pre>'; print_r($shg_tabs);  die;
                            		$tab_no = 1;
                            ?>
                            <ul class="nav nav-tabs mental-shg-tb" id="myTab" role="tablist">
                            <?php 
                            	$parent = 1;
                            	$child =1;
                            foreach ($shg_tabs as $field){
                            	    $tab_title = isset($field['tab_title']) ? $field['tab_title']:"";
                            	    $tab_type = isset($field['select_parent_or_child_tab']) ? $field['select_parent_or_child_tab']:"";
                            	    $active = '';
                            	    if($tab_no == 1){
                            	    	$active = 'active';

                            	    }

                            	    $toggler ='';
                            	    $plus_icon = '';
                            	    $common_tb_class ='';

                            	    if($tab_type == 'parent'){
                            	    	$common_tb_class = 'mental_parent';
                            	    	$tab_class = 'nav_parent_'.$parent;
                            	    	$toggler = 'toggler';
                            	    	$plus_icon = '<button class="plusminus_btn"><i class="fa-solid fa-plus"></i></button>';
                            	    	$parent++;
                            	    }
                            	    else if($tab_type == 'child'){
                            	    	$common_tb_class = 'mental_child';
                            	    	$tab_class = 'nav_child_'.$parent-1;
                            	    }
                            	    else {
                            	    	$common_tb_class ='';
                            	    	$tab_class = '';
                            	    }


                            		?>

                                <li class="nav-item <?php echo $common_tb_class;?>" role="presentation" id="<?php echo $tab_class;?>">
                                  <button href="#" class="nav-link  <?php echo $toggler.' '.$active;?>" id="Tab<?php echo $tab_no;?>" data-bs-toggle="tab" data-bs-target="#Tab_<?php echo $tab_no;?>" type="button" role="tab" aria-controls="Tab_<?php echo $tab_no;?>" aria-selected="true"><?php echo $tab_no .'. '. $tab_title;?></button>

                                  <?php echo isset($plus_icon) ? $plus_icon:"";?>
                                </li>
                            <?php 
                            

                            	  $tab_no++;

                        		}  } ?>

                        		
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="pannel_wrapper_container detail_container">
                        <div class="detail_part">
                            <div class="tab-content" id="myTabContent">
                            	<?php
                            		if ( have_rows('mental_health_shg') ) :
                            		    $tab_count = 1; 
                            			while( have_rows( 'mental_health_shg') ) : the_row();
                            				$active = '';
                            				if($tab_count ==1){
                            					$active = 'active';
                            				}

                            				$tab_title = get_sub_field('tab_title');
                            	echo '<div class="tab-pane fade show '.$active.'" id="Tab_'.$tab_count.'" role="tabpanel" aria-labelledby="Tab'.$tab_count.'">';
                                 echo '<p class="mb-0"><strong>Section '.$tab_count.' of '.$total_tabs.'</strong></p>';
                                    echo '<h2 class="pt-0 primary-color">'.$tab_count.'. '. $tab_title.'</h2>';

                                    //$sections = get_sub_field( 'content_blocks');
                                    //echo '<pre>'; print_r($sections); //die;
                                    //echo $sections_count = count($sections);

                            		if ( have_rows('content_blocks', $shg_id) ) : 
                            			while( have_rows( 'content_blocks', $shg_id ) ) : the_row();
                            				global $hasContentBlock;
											$hasContentBlock = true;
											$arr=array();
                                              if(get_row_layout() == 'form_layouts' ){
                                                    
                                                     $arr= array( 
                                                              'tab_name' => $tab_title ,
                                                              'tab_no' => $tab_count,
                                                             
                                                          );
                                                   
                                                 }

										get_template_part( 'mental-shg-content-blocks/' . get_row_layout(), null,$arr );
                            			endwhile;
										endif;
										?>

										<?php if($tab_count ==1){?>
										<div class="bt_sec">
                                        <button type="submit" class="btn btn--primary btn--icon btn_guide next_btn">Start guide<span class="icon"><i class="fa fa-chevron-right f-8"></i></span> </button>
                                    	</div>
                                    <?php } else { ?>
										<div class="bt_sec">
                                        <div class="row">
                                            <div class="col-6 mb-0">
                                                <button type="submit" class="btn btn--primary btn--icon btn_guide prev_btn"><span class="icon"><i class="fa fa-chevron-left f-8"></i></span>Previous</button>
                                            </div>
                                            <?php if($tab_count < $total_tabs){?>
                                            <div class="col-6 mb-0 text-end">
                                                <button type="submit" class="btn btn--primary btn--icon btn_guide next_btn">Next<span class="icon"><i class="fa fa-chevron-right f-8"></i></span></button>
                                            </div>
                                        <?php } ?>
                                        </div>
                                    </div>
                                <?php } ?>

									<?php echo '</div>';

										$tab_count++;

                            			endwhile;
										endif;
                            		?>
                            	<!--<div class="tab-pane fade show active" id="Tab_1" role="tabpanel" aria-labelledby="Tab1">
                                    <p class="mb-0"><strong>Section 1 of 17</strong></p>
                                    <h2 class="pt-0 primary-color">1. Introduction</h2>
                                    <div class="care_card">
                                        <div class="hero_banner_content">
                                            <h3>Urgent help</h3>
                                            <span class="hero_arrow"></span>
                                        </div>
                                        <div class="care_card_body">
                                            <p>This self-help guide is intended for people with mild-to-moderate symptoms of depression.</p>
                                            <p>If you're feeling distressed, in a state of despair, suicidal or in need of emotional support you can phone NHS 24 on 111.</p>
                                            <p>For an emergency ambulance phone 999.</p>
                                        </div>
                                    </div>
                                    <p>This guide aims to help you:</p>
                                    <ul>
                                        <li>find out if you could have symptoms of depression</li>
                                        <li>understand more about depression</li>
                                        <li>find ways to manage or overcome depression</li>
                                    </ul>
                                    <p>This guide is based on Cognitive Behavioural Therapy (CBT). CBT helps you to examine how you think about your life, and challenge negative automatic thoughts to free yourself from unhelpful thought and behaviour patterns.</p>
                                    <h2 class="primary-color">How to use the depression self-help guide</h2>
                                    <p>Working through this guide can take around 30 to 40 minutes, but you should feel free to work at your own pace.</p>
                                    <p>Work through the guide on your device, using the "Next" button to move forward and use the "Previous" button instead of the Back button in your browser. To type in a graphic or diary, click or tap the part you’d like to fill in and use your keyboard as usual.</p>
                                    <p>If you’d like to save the guide and return to it later, you’ll need to save it as a PDF on your device before you leave the page. You can then continue filling it out on the PDF. We don’t use a login feature on our mental health self-help guides for privacy reasons.</p>
                                    <p>If you’d like to print the guide at any time, you’ll find an option to save and print the whole guide, including the parts you have added, in each section.</p>

                                    <div class="bt_sec">
                                        <button type="submit" class="btn btn--primary btn--icon btn_guide">Start guide<span class="icon"><i class="fa fa-chevron-right f-8"></i></span> </button>
                                    </div>

                                    <div class="bt_sec">
                                        <div>
                                            <a href="#" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s).">Email link to self help guide <span class="icon"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>
                                            </a>
                                        </div>
                                        <div>
                                            <a href="#" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s).">Save and download self help guide <span class="icon"><i class="fa-solid fa-file-pdf"></i></span>
                                            </a>
                                        </div>
                                        <div>
                                            <a href="#" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s).">Download blank planner and activities <span class="icon"><i class="fa fa-download" aria-hidden="true"></i></span>
                                            </a>
                                        </div>
                                    </div>

                                    <p class="mb-0 small_text">Last updated: <br>27 May 2021</p>
                                </div>
                                <div class="tab-pane fade" id="Tab_2" role="tabpanel" aria-labelledby="Tab2">
                                    <p class="mb-0"><strong>Section 2 of 17</strong></p>
                                    <h2 class="pt-0 primary-color">2. Symptoms of depression</h2>
                                </div>
                                <div class="tab-pane fade" id="Tab_3" role="tabpanel" aria-labelledby="Tab3">
                                    <p class="mb-0"><strong>Section 3 of 17</strong></p>
                                    <h2 class="pt-0 primary-color">3. Symptoms of depression</h2>
                                </div>-->

                            </div>
                            <div class="bt_sec">
                            	<?php
                            	$email_data = get_field('email_send_link__content',$shg_id);
                            	//echo '<pre>'; print_r($email_data);
                                $current_link = get_the_permalink($shg_id);
                            	$email_subject = $email_data['email_subject'];
                            	$email_intro = $email_data['email_intro'];
                                $email_body = $email_data['email_body']."\r\n";
                                $email_body .= $current_link;

                            	$email_button_text = $email_data['email_button_text'];

                            	?>
                            	
                            	<!--<a href="mailto:test@example.com?subject=Testing out mailto!&body=This is only a test!">Second Example</a>-->
                                <div>
                                    <?php
                                     if(!empty($email_button_text)){
                                    echo '<a href="mailto:someone@myemailaddress.com?subject='.$email_subject.'&body='.$email_intro." \r\n ".$email_body.'" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s).">'.$email_button_text.' <span class="icon"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>
                                    </a>';
                                    }
                                    ?>
                                </div>
                                <?php
                            	$download_data = get_field('downloads',$shg_id);
                            	//echo '<pre>'; print_r($download_data);
                            	$guide_pdf = isset($download_data['guide_pdf']['url']) ? $download_data['guide_pdf']['url']:"";
                                $file_path = explode('uploads/', $guide_pdf);
                                if(!empty($file_path[1])){
                                   $file_name = explode('/', $file_path[1]);
                                   $fileName = pathinfo($file_name[2], PATHINFO_FILENAME);

                                }

                            	$guide_pdf_button_text = $download_data['guide_pdf_button_text'];
                            	$planner_pdf = isset($download_data['planner_pdf']['url']) ? $download_data['planner_pdf']['url']:"";
                                $planner_file_path = explode('uploads/', $planner_pdf);
                                if(!empty($planner_file_path[1])){
                                   $planner_file_name = explode('/', $planner_file_path[1]);
                                   $planner_fileName = pathinfo($planner_file_name[2], PATHINFO_FILENAME);

                                }

                            	$planner_pdf_button_text = $download_data['planner_pdf_button_text'];
                            	?>
                                
                                <!--<div>
                                	<?php //if(!empty($guide_pdf_button_text) && !empty($guide_pdf)){?>
                                    <a href="<?php //echo $guide_pdf;?>" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s) (This will open in a new window)." download><?php //echo $guide_pdf_button_text;?> <span class="icon"><i class="fa-solid fa-file-pdf"></i></span>
                                    </a>
                                <?php //} ?>
                                </div>-->
                                <div>
                                    <?php
                                     $upload_dir = wp_upload_dir();
                                     $file_dir = $upload_dir['basedir'].'/'.$file_path[1];

                                    if(file_exists($file_dir)){
                                     if(!empty($guide_pdf_button_text) && !empty($guide_pdf)){?>
                                    
                                    <a href="#" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow dlBtn" title="Click here to download your item(s) (This will open in a new window)." fileUrl="<?php echo $file_path[1];?>" fileName="<?php echo $fileName;?>"><?php echo $guide_pdf_button_text;?> <span class="icon"><i class="fa-solid fa-file-pdf"></i></span>
                                    </a>
                                <?php } } ?>
                                </div>
                                <!--<div>
                                	<?php //if(!empty($planner_pdf_button_text) && !empty($planner_pdf)){?>
                                    <a download href="<?php //echo $planner_pdf;?>" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s)."><?php //echo $planner_pdf_button_text;?> <span class="icon"><i class="fa fa-download" aria-hidden="true"></i></span>
                                    </a>
                                    <?php //} ?>
                                </div>-->

                                 <div>
                                    <?php
                                     $upload_dir = wp_upload_dir();
                                     $file_dir = $upload_dir['basedir'].'/'.$planner_file_path[1];
                                     
                                    if(file_exists($file_dir)){

                                     if(!empty($planner_pdf_button_text) && !empty($planner_pdf)){?>
                                    <a href="#" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow planner-dlBtn" title="Click here to download your item(s) (This will open in a new window)." fileUrl="<?php echo $planner_file_path[1];?>" fileName="<?php echo $planner_fileName;?>"><?php echo $planner_pdf_button_text;?> <span class="icon"><i class="fa-solid fa-file-pdf"></i></span>
                                    </a>
                                <?php } } ?>
                                </div>

                            </div>

                            <p class="mb-0 small_text">Last updated: <br><?php echo $post_date;?></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
<!--<script src="https://cdn.jsdelivr.net/npm/jspdf-customfonts@0.0.4-rc.4/dist/jspdf.customfonts.min.js"></script>-->
<!--<script src="Avenir-Light.ttf"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js" integrity="sha512-Qlv6VSKh1gDKGoJbnyA5RMXYcvnpIqhO++MhIM2fStMcGT9i2T//tSwYFlcyoRRDcDZ+TYHpH8azBBCyhpSeqw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

 <script type="text/javascript">
let btnDownload = document.querySelector(".dlBtn");
let btnPlannerDownload = document.querySelector(".planner-dlBtn");

btnDownload.addEventListener("click", startDownload,false);
btnPlannerDownload.addEventListener("click", startDownload,false);

async function startDownload(event) {
    event.preventDefault();
let fileUrl = jQuery(this).attr('fileUrl');
var file_path = '<?php echo home_url();?>'+'/wp-content/uploads/'+fileUrl;
//alert(file_path);
let fileName = jQuery(this).attr('fileName');
  let url = file_path;
  //let fileName = "My Document";
  const res = await fetch(url);
  const blob = await res.blob();
  saveAs(blob, fileName);
}
    </script>

<script type="text/javascript">


     function generatePDF() {
            
            //const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            ////var tabHtml = jQuery( "#myTabContent" ).html();
            //doc.text(tabHtml, 100, 100);
            var pdfUrl = 'http://localhost/nhsinform/wp-content/uploads/2022/05/anxiety-mhshg-may-2021.pdf';
            //alert(pdfUrl);
             //doc.text("Hello world!", 100, 100);
            doc.save(pdfUrl);

            /*var doc = new jsPDF('l', 'mm', [1500, 1400]);
            var pdfjs = document.querySelector('#myTabContent');
 
            doc.html(pdfjs, {
                callback: function(doc) {
                    doc.save("newpdf.pdf");
                },
                x: 12,
                y: 12
            }); */               
        }

/*jQuery('.dl-shg-btn').click(function () {  
  var pdf = new jsPDF();
  pdf.setFont("Avenir W01");
  var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
  };
  var margin = {
  top: 0,
  left: 0,
  right: 0,
  bottom: 0
};
  //var $addr = $(this).closest('.res').find('.content');
  var $temp = jQuery('#myTabContent');
  //$temp.find('h3').text($addr.find('h3').text());
  pdf.fromHTML($temp.html(), 15, 15, {
        'width': 170,
        'elementHandlers':specialElementHandlers
        },
        function(bla){pdf.save('saveInCallback.pdf');},
margin);

  
  //pdf.save('sample-file.pdf');
});*/

    </script> 


<?php get_footer();?>