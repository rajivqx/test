<?php
/**
 * The template for displaying archive-illnesses pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nhsinform
 */
global $wp;
$td = get_queried_object();
if($td->term_id==336){
    wp_redirect(home_url('translations'));
}
if($td->term_id==337){
    wp_redirect(home_url('translations'));
}
$myterms = get_term_by('id', $td->term_id, 'languages');
if($myterms->parent=='336' || $myterms->parent=='337' ){

} else {
    if($myterms->parent!='0'){
    $cname = str_replace(' ','-',$myterms->name);
    $sublink = get_term_link($myterms->parent, 'languages').'#'.$cname;
    wp_redirect($sublink);
    }
}
get_header('inner1');?>

<div class="microsite_overlay"></div>
    <div class="microsite_navigation">
        <h3>Translations <button class="close_micro"><i class="fa-solid fa-xmark"></i></button></h3>
        <nav class="microsite_nav_list">
            <ul>
                <li>
                    <a href="<?php echo home_url('translations');?>/#15421">Languages</a>
                    <span class="micro_bg_01 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                        <?php
                    $terms = get_terms( 'languages', array( 'parent' => '336', 'orderby' => 'slug', 'hide_empty' => false ) );
                        foreach($terms as $term) { ?>
                        <li><a href="<?php echo get_term_link( $term->slug, 'languages' );?>"><?php echo $term->name;?></a></li>
                        <?php } ?>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo home_url('translations');?>/#15428">Formats</a>
                    <span class="micro_bg_02 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                    <?php $terms1 = get_terms( 'languages', array( 'parent' => '337', 'orderby' => 'slug', 'hide_empty' => false ) );
                        foreach($terms1 as $term) { ?>
                        <li><a href="<?php echo get_term_link( $term->slug, 'languages' );?>"><?php echo $term->name;?></a></li>
                        <?php } ?>
                        
                    </ul>
                </li>
            </ul>
        </nav>
        <div class="micro_nav_slide_list_container">
            <span class="micro_nav_slide_list_back">Back</span>
        </div>
    </div>
    <!-- MicroSite Header HTML Start -->
    <div class="microsite_header translateHeader">
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <a href="#" class="microsite_title">Translations</a>
                </div>
                <div class="col-3">
                    <div class="hamburger_icon">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->
    <!-- Pannel Intro Section HTML Start -->



    <section class="pannel_wrapper microsite_wrapper transcatwrapper">
        <div class="container">
            <div class="pannel_wrapper_container microsite_wrapper_container">
                                     <div class="row">
                                            <div class="col-md-10">
                                            <?php if(have_posts()):?>
                                                <?php
                                                    the_archive_title( '<h1>', '</h1>');
                                                    the_archive_description( '<p>', '</p>');
                                                endif;?>
                                            </div>
                                            <?php 
                                            $term = get_queried_object();
                                            $term_id = $term->term_id;
                                            if($term_id=='95') {   ?>
                                            <div class="col-md-2 d-none d-md-block d-lg-block">
                                            <img alt="BSL Icon 9 01" src="<?php echo get_template_directory_uri();?>/assets/images/bslicon9-01.png">
                                            </div>
                                            <?php } elseif($term_id=='338')  { ?>
                                                <div class="col-md-2 d-none d-md-block d-lg-block">
                                            <img alt="AUDIO 01" src="<?php echo get_template_directory_uri();?>/assets/images/audio-01.png">
                                            </div>
                                            <?php } ?>
                                     </div>
                  <div class="row alignRowTranslation">
                 
                     <?php                
                     $termChildren = get_term_children($term->term_id, 'languages');
                                        $args1 = array(
                                        'post_type' => 'translations',
                                        'posts_per_page' => -1,
                                        'tax_query' => array(             
                                            array(
                                                'taxonomy' => 'languages',
                                                'field' => 'term_id',
                                                'terms' =>  $term_id,
                                            ),
                                            array(
                                                'taxonomy' => 'languages',
                                                'field' => 'id',
                                                'terms' => $termChildren,
                                                'operator' => 'NOT IN'
                                            )
                                        )
                                    );
                                $query = new WP_Query($args1);
                                if($query->have_posts()){
                                while($query->have_posts()){
                                    $query->the_post(); ?>
                                    <div class="col-lg-4 col-md-6 col-sm-12 mb-4 mb4">
                                    <a href="<?php echo esc_url( get_permalink()); ?>" class="pannel_module">
                                        <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                                            <?php the_excerpt();?>
                                        </a>
                                    </div>
                                <?php
                                    }
                                }
                                wp_reset_postdata();
             
                                $terms = get_terms( 'languages', array( 'parent' => $term_id, 'orderby' => 'slug', 'hide_empty' => false ));
                                foreach($terms as $term) { ?>
                                <div class="col-sm-12 mb-0" id="<?php echo str_replace(' ','-',$term->name); ?>">
                                <div class="panel-display">
                                <h2 class="panel-text"> <?php echo $term->name; ?>  </h2>
                                </div>
                            </div>
                        <?php                
                                        $args = array(
                                        'post_type' => 'translations',
                                        'posts_per_page' => -1,
                                        'tax_query' => array(             
                                            array(
                                                'taxonomy' => 'languages',
                                                'field' => 'slug',
                                                'terms' =>  $term->slug, // or the category name e.g. Germany
                                            ),
                                        )
                                    );
                                $query = new WP_Query($args);
                                if($query->have_posts()){
                                while($query->have_posts()){
                                    $query->the_post(); ?>
                                    <div class="col-lg-4 col-md-6 col-sm-12 mb-4 mb4">
                                    <a href="<?php echo esc_url( get_permalink()); ?>" class="pannel_module">
                                        <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                                            <?php the_excerpt();?>
                                        </a>
                                    </div>
                                <?php
                                    }
                                }
                                wp_reset_postdata();
                                 }
                                ?>
                    
                </div>
            </div>
        </div>

    </section>   
<script>
    jQuery(document).ready(function () {

        $('<li class="breadcrumb-item"><a href="/translations/" class="nhsuk-breadcrumb__link">Translations</a></li>').insertAfter($('ol.breadcrumb li:eq(0)'));

                    var lspan = $('#breadcrumbs span span').children().length; 
                    if(lspan===2){
                        $("#breadcrumbs span span:first-child").remove();
                       // $("#breadcrumbs span span").children().eq(0).hide();
                       $("#breadcrumbs span span:eq(0)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                       }
                       if(lspan===3){
                        $("#breadcrumbs span span:first-child").remove();
                        $("#breadcrumbs span span").children().eq(0).hide();
                        $("#breadcrumbs span span:eq(1)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                       }
    });
</script>

<?php get_footer(); ?>