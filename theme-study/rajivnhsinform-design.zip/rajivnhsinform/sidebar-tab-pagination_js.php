<script type="text/javascript">
$(document).ready(function(){
       nextPreButton();
    });
   function nextPreButton(buttonType=""){
        let allTabIDs      = [];
        let allTabIDsPre   = [];
        let allTabIDsNext  = [];
        let dataActiveId   = '';
        let nextButtonURl  = "";
        let prevButtonURL  = "";
        
        $(".js-plethoraplugins-tabs li a").each(function(){
            var dataId = $(this).attr("id");
            allTabIDs.push(dataId);
            if($(this).hasClass("active")){
                dataActiveId = ($(this).attr("id"));
            }
        });

        var getCurrentTab  = dataActiveId.split("_");
        if(allTabIDs.length>0){
            var preID = parseInt(getCurrentTab[3])-1;
            var nextID = parseInt(getCurrentTab[3])+1;

            nextButtonURl = $("#plethorapluginstab_1_tablink_"+nextID).attr('href');
            $("#next_page").attr('href',nextButtonURl);

            prevButtonURL = $("#plethorapluginstab_1_tablink_"+preID).attr('href');
            $("#previous_page").attr('href',prevButtonURL);

            setTimeout(function(){
                nextPreButtonHideShow();
            }, 100);
        }else{
            $('.jsPrevNextContainer').hide(); 
        }
    }

    function nextPreButtonHideShow(){
         let allTabIDVal   = [];
         let currentActive = '';

        $(".js-plethoraplugins-tabs li a").each(function(){
            var getID = $(this).attr("id");
            allTabIDVal.push(getID);
            if($(this).hasClass("active")){
                currentActive = ($(this).attr("id"));
            }
        });

        var getCurrentTabAct = currentActive.split("_");
        var preIDPart            = parseInt(getCurrentTabAct[3]);
        var nextIDPart           = parseInt(getCurrentTabAct[3])+2;

        // Get 
        var prePartText      = parseInt(getCurrentTabAct[3])-1;
        var nextIPartText      = parseInt(getCurrentTabAct[3])+1;

        var firstID = allTabIDVal.at(0);
        var lastID  = allTabIDVal.at(-1);

        if(currentActive == lastID){
          $("#next_page").hide();
          $("#previous_page").show();
          $("#prePart").html("Part "+preIDPart);
          $("#prePartText").html($("#plethorapluginstab_1_tablink_"+prePartText).find('span').text());
        }else if(firstID == currentActive){
           $("#next_page").show();
           $("#previous_page").hide();
            $("#nextPart").html("Part "+nextIDPart);
            $("#nextPartText").html($("#plethorapluginstab_1_tablink_"+nextIPartText).find('span').text());
        }else{
           $("#next_page").show();
           $("#previous_page").show();
            $("#nextPart").html("Part "+nextIDPart);
            $("#nextPartText").html($("#plethorapluginstab_1_tablink_"+nextIPartText).find('span').text());

            $("#prePart").html("Part "+preIDPart);
            $("#prePartText").html($("#plethorapluginstab_1_tablink_"+prePartText).find('span').text());
        }
    } 


$(document).ready(function(){
    $("a.js-plethoraplugins-tabs--link").on("click", function(){
        nextPreButton();
    });
});

</script>