<?php
/**
 * nhsinform functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package nhsinform
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.1.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function nhsinform_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on nhsinform, use a find and replace
		* to change 'nhsinform' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'nhsinform', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary', 'nhsinform' ),
			'ready_steady_baby_menu' => esc_html__( 'Ready Steady Menu', 'nhsinform' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'nhsinform_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'nhsinform_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function nhsinform_content_width() {
	$GLOBALS['content_width'] = apply_filters('nhsinform_content_width',640);
	add_image_size('home-page-thumb',800,300,true);
	add_post_type_support( 'page', 'excerpt' );
	
}
add_action( 'after_setup_theme', 'nhsinform_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function nhsinform_widgets_init(){
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Left Logo', 'nhsinform' ),
			'id'            => 'footer-left-logo',
			'description'   => esc_html__( 'Add widgets here to show footer logo.', 'nhsinform' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		)
	);
    register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Right Logo', 'nhsinform' ),
			'id'            => 'footer-right-logo',
			'description'   => esc_html__( 'Add widgets here to show footer logo.', 'nhsinform' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Menu', 'nhsinform' ),
			'id'            => 'footer-menu',
			'description'   => esc_html__('Add Footer Menu.', 'nhsinform' ),
			'before_widget' => '<div id="%1$s" class="col-md-6 col-lg-3">',
			'after_widget'  => '</div>',
			'before_title'  =>'<h3>',
			'after_title'   => '<h3/>',
		)
	);


	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Bottom Content', 'nhsinform' ),
			'id'            => 'footer-bottom-content',
			'description'   => esc_html__('Add Footer Content.', 'nhsinform' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		)
	);
}
add_action('widgets_init','nhsinform_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function nhsinform_scripts(){

	wp_enqueue_style('nhsinform-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_enqueue_style('app-style','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css',array(), _S_VERSION);

	wp_enqueue_style('bootstrap-min',get_template_directory_uri().'/assets/css/bootstrap.min.css',array(), _S_VERSION);




	// Ready Steady
	// wp_enqueue_style('only-custom-ready',get_template_directory_uri().'/assets/css/only-custom-ready.css',array(), _S_VERSION);


	// if(is_page('ready-steady-baby') || is_tax('ready_categories') || is_singular('ready-steady-baby')){
	// 		wp_enqueue_style('only-custom-ready',get_template_directory_uri().'/assets/css/only-custom-ready.css',array(), _S_VERSION);
	// 	}

	if(is_page('9254') || is_tax( 'languages' ) || is_singular('translations')){
		wp_enqueue_style('custom-ready',get_template_directory_uri().'/assets/css/custom-ready.css',array(), _S_VERSION);
		wp_enqueue_style('translations',get_template_directory_uri().'/assets/css/translations.css',array(), _S_VERSION);
	} else {
		wp_enqueue_style('custom',get_template_directory_uri().'/assets/css/custom.css',array(), _S_VERSION);
		wp_enqueue_style('ssd',get_template_directory_uri().'/assets/css/ssds.css',array(), _S_VERSION);
		wp_enqueue_style('layoutTemp',get_template_directory_uri().'/assets/css/layoutTemp.css',array(), _S_VERSION);
	}


	if(is_singular( 'mental-health-shg' ) || is_tax('ready_categories') || is_singular('ready-steady-baby')){
			wp_enqueue_style('shg-mental-health',get_template_directory_uri().'/assets/css/main.css',array(), _S_VERSION);	
		}
	if(is_page('11168')){
		wp_enqueue_style('ready-steady-tpl',get_template_directory_uri().'/assets/css/micro-baby.css',array(), _S_VERSION);
	}

	wp_style_add_data('app-style','rtl','replace');
	
    wp_enqueue_script('jquery-3.3.1.min', get_template_directory_uri().'/assets/js/jquery-3.3.1.min.js', array(), _S_VERSION, true );

	wp_enqueue_script('bootstrap-bundle-min', get_template_directory_uri().'/assets/js/bootstrap.bundle.min.js', array(), _S_VERSION, true );


	wp_enqueue_script( 'custom-js', get_template_directory_uri().'/js/custom-js.js', array(), _S_VERSION, true );

	if(is_singular() && comments_open() && get_option( 'thread_comments' )){
		wp_enqueue_script( 'comment-reply' );
	}

if(is_singular( 'self-help-guides' ) || is_singular( 'symptoms-self-guides' )){
	wp_enqueue_script('shg-js', get_template_directory_uri().'/js/selfHelpGuide.js', array(), _S_VERSION, true );
	}
	wp_localize_script( 'shg-js', 'shg_js_object',
		array( 
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'home_url' => home_url(),
			
		)
	);

	if(is_singular( 'mental-health-shg' ) || is_tax('ready_categories') || is_singular('ready-steady-baby')){
		wp_enqueue_script( 'shg-custom-js', get_template_directory_uri().'/assets/js/custom.js', array(), _S_VERSION, true );
	}
	
	$main_url = get_permalink();
	if(strpos($main_url, '12-week-weight-management-programme') !== false){
	    wp_enqueue_style( 'healthy-main', get_stylesheet_directory_uri() . '/healthy-living/css/health-main.css' );
	    wp_enqueue_style( 'healthy-custom', get_stylesheet_directory_uri() . '/healthy-living/css/health-custom.css' );
	    wp_enqueue_script( 'healthy-script', get_stylesheet_directory_uri() . '/healthy-living/js/health-custom.js', array(), '1.0.0', true );
	 }
	
}
add_action('wp_enqueue_scripts', 'nhsinform_scripts');


/**
 * Implement the Custom Header feature.
 */
require get_template_directory().'/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory().'/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory().'/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory().'/inc/customizer.php';

require get_template_directory().'/inc/Class-wp-navwalker.php';

require get_template_directory().'/inc/custom_footer_widget.php';
require get_template_directory().'/inc/nhsinform_breadcrumbs.php';

if(is_admin()){
require get_template_directory().'/templates/get-all-shg.php';
}

require get_template_directory().'/inc/feedback_form.php';

require get_template_directory().'/inc/mental-health-shg.php';

//require get_template_directory().'/inc/mental-health-taxonomy.php';

/**
 * Load Jetpack compatibility file.
 */

if(defined('JETPACK__VERSION')){
	require get_template_directory().'/inc/jetpack.php';
}


add_filter( 'get_the_archive_title', function ($title) {    
	if ( is_category() ) {    
			$title = single_cat_title( '', false );    
		} elseif ( is_tag() ) {    
			$title = single_tag_title( '', false );    
		} elseif ( is_author() ) {    
			$title =get_the_author();    
		} elseif ( is_tax() ) { //for custom post types
			$title = sprintf( __( '%1$s' ), single_term_title( '', false ) );
		} elseif (is_post_type_archive()) {
			$title = post_type_archive_title( '', false );
		}
	return $title;    
});



// This sample uses the Apache HTTP client from HTTP Components (http://hc.apache.org/httpcomponents-client-ga/)
/*require_once 'HTTP/Request2.php';

$request = new Http_Request2('https://nsdfapp1.azure-api.net/nsd/servicetypes/13755');
$url = $request->getUrl();

$headers = array(
    // Request headers
    'Ocp-Apim-Subscription-Key' => '065671d43cfa4e38b9788f2aba0c356a',
);

$request->setHeader($headers);

$parameters = array(
    // Request parameters
);

$url->setQueryVariables($parameters);

$request->setMethod(HTTP_Request2::METHOD_GET);

// Request body
$request->setBody("{body}");

try
{
    $response = $request->send();
    echo $response->getBody();
}
catch (HttpException $ex)
{
    echo $ex;
}*/

function wp_get_attachment($attachment_id){
	$attachment = get_post($attachment_id);
	return array(
	    'alt' => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
	    'caption' => $attachment->post_excerpt,
	    'description' => $attachment->post_content,
	    'href' => get_permalink( $attachment->ID ),
	    'src' => $attachment->guid,
	    'title' => $attachment->post_title
		);
}

// healthy-living
add_filter( 'the_content', 'the_content_filter', 20 );

function the_content_filter( $content ) {
	if(is_singular('illnesses') || is_singular('tests-and-treatments') || is_singular('healthy-living') || is_singular('care_support') ){
		$content = str_replace('https://www.nhsinform.scot', '', $content);
		return $content;
	} else {
		return $content;
	}
}


// SSD APIs

require get_template_directory().'/ssd_service.php';
function my_enqueue_scripts() {
    wp_enqueue_script( 'jquery-cookie', get_template_directory_uri() . '/js/jquery.cookie.min.js', array( 'jquery' ), '1.4.1', true );
}
add_action( 'wp_enqueue_scripts', 'my_enqueue_scripts');



// save pdf
// add/remove info for me 
add_action('wp_ajax_info_save_pdf', 'savePDF_handler' );
add_action('wp_ajax_nopriv_info_save_pdf','savePDF_handler'); 

function savePDF_handler(){
  try{

  	$post_id = isset($_POST['id']) ? $_POST['id']:'';

  	$post = get_post($post_id);
	if ($post) {
	    $post_title = $post->post_title;
	    $page_intro = get_post_meta($post_id, 'page_intro', true);

	}
	$bmi_result = $_COOKIE['bmi_result'];
    $bmi_result = json_decode(stripslashes($bmi_result));
    if (isset($bmi_result) && !empty($bmi_result) && $bmi_result != NULL){
        $bmi_result1 = urldecode($bmi_result->content);
    }else{
    	$bmi_result1 = '
	    <h4 class="no-margin">Your BMI is</h4>
	    <p>You haven’t added a BMI score to your journal</p>';
    }

    $check_progress = $_COOKIE['check_progress'];
	$check_progress = json_decode(stripslashes($check_progress));

	if (isset($check_progress) && !empty($check_progress) && $check_progress != NULL){
		$check_progress_type = $check_progress->type;
		$check_progress_content = urldecode($check_progress->content);
	}else{
		$check_progress_type = '';
		$check_progress_content = '';
	}

	$goals = $_COOKIE['goals'];
    $goals = json_decode(stripslashes($goals));
    if (isset($goals) && !empty($goals) && $goals != NULL){
    	$goal = '<div id="journal-goal-one">
                    <p class="secondary-color">Goal 1.</p>
                    <p class="push--bottom">'.$goals->goal1.'</p>
                </div>
            <div id="journal-goal-two">
                    <p class="bold mega push--bottom secondary-color">Goal 2.</p>
                    <p class="push--bottom">'.$goals->goal2.'</p>
            </div>
            <div id="journal-goal-three">
                    <p class="bold mega push--bottom secondary-color">Goal 3.</p>
                    <p class="push--bottom">'.$goals->goal3.'</p>
            </div>';
    }else{
    	$goal = 'You haven’t added your goals to your journal';
    }
  	include(dirname(__FILE__) . "/inc/tcpdf/tcpdf.php");

    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Your Name');
	$pdf->SetTitle('WeeklyJournal');
	$pdf->setPrintHeader(false);
	$pdf->setPrintFooter(false);
	$pdf->setHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->setFooterMargin(PDF_MARGIN_FOOTER);
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    $pdf->SetMargins(13, 0, 13,0);
	$pdf->SetHeaderMargin(2);
	$pdf->SetFooterMargin(2);
 
	$pdf->AddPage();

	$html = ' 
		<style >
			.pdf_doc h1{
			    font-family: "Avenir W01",sans-serif !important;
			    font-size: 22px;
			    margin: 0;
			} 
			.pdf_doc p{
			    font-family: "Avenir W01",sans-serif !important;
			    font-size: 10px;
			}
			.pdf_doc h2{
			    font-family: "Avenir W01",sans-serif !important;
			    font-size: 18px;
			}
			.tab_item {
			    border: 1px solid #e6e6e6;
			}
		</style>
		<div class="pdf_doc">
			<h1>'.$post_title.'</h1>
			<p>'.$page_intro.'</p>
			<h2>Your Journal</h2>

			<div class="tab_item">
			    '.$bmi_result1.'
			</div>

			<div class="tab_item">
			    <h4 class="no-margin">Your progress since last week</h4>
			    <p class="push--bottom">Did you achieve the goals you set yourself last week?</p>
			    <p class="push_type">'.$check_progress_type.'</p>
			    <p class="push--bottom">'.$check_progress_content.'</p>
			</div>
			<div class="tab_item">
			    <h4 class="no-margin">Your goals for next week</h4>
			    '.$goal.'
			</div>
		</div>
	';
	$pdf->writeHTML($html, true, false, true, false, '');

	$filename 	= 'emailInfo_'.uniqid().".pdf"; 
	$uploads 		= wp_upload_dir();
	$upload_path 	= $uploads['basedir'];
	$pdf->Output($upload_path.'/user_pdf/'.$filename, 'F');
	$fileURL = site_url().'/wp-content/uploads/user_pdf/'.$filename;
	$delete_file 	= $upload_path.'/user_pdf/'.$filename;
	
	echo  json_encode([
    	'status'=>true,
    	'message'=>"Data add successfully!", 
    	'data'=>$fileURL,
    	'deleteFile'=>$delete_file
    	],true);

  }catch(Exception $e){
    echo  json_encode([
    	'status'=>false,
    	'message'=>1111,
    	'data'=>"0",
    	'deleteFile'=>''
    ],true);
  }	
 exit;
}

add_action('wp_ajax_deleteFile_pdf','deleteFile' );
add_action('wp_ajax_nopriv_deleteFile_pdf','deleteFile'); 

function deleteFile(){
  try{

  //wp_delete_file($delete_file);
  	$deleteFilePath = $_POST['deleteFilePath'];
  	if($deleteFilePath){
  		wp_delete_file($deleteFilePath);
  	}

    echo  json_encode([
    	'status'=>true,
    	'message'=>"Data add successfully!", 
    	'data'=>''
    	],true);
  }catch(Exception $e){
    echo  json_encode([
    	'status'=>false,
    	'message'=>$e->getMessage(),
    	'data'=>"0"
    ],true);
}	
 exit;
} 




// Hamburger Menu 

class add_span_walker extends Walker_Nav_Menu {
    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        global $wp_query;
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

        $class_names = '';

        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

        $id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
        $id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

        $output .= $indent . '<li' . $id . $class_names .'>';

        $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
        $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
        $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
        $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';

        $item_output = $args->before;
        $item_output .= '<a'. $attributes .'>';
        $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
        $item_output .= '</a>';
        
        if ( 'ready_steady_baby_menu' == $args->theme_location ) {
            $submenus = 0 == $depth || 1 == $depth ? get_posts( array( 'post_type' => 'nav_menu_item', 'numberposts' => 1, 'meta_query' => array( array( 'key' => '_menu_item_menu_item_parent', 'value' => $item->ID, 'fields' => 'ids' ) ) ) ) : false;
            $item_output .= ! empty( $submenus ) ? ( 0 == $depth ? '<span class="micro_bg_01 micro_nav_slide_ready"><i class="fa-solid fa-chevron-right"></i></span>' : '<span class="sub-arrow"></span>' ) : '';
        }
       
        $item_output .= $args->after;

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}
