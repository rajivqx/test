<?php
/**
 * The template for displaying Symptomps SHG Detail page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();?>

<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/assets/css/SHG.css" media="screen" />
   <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/assets/css/bootstrap.min.css" media="screen" />

 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/knockout/3.3.0/knockout-min.js"></script>
 
 <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.3/js/bootstrap.min.js"></script>

<!--<script type="text/javascript" src="<?php //echo get_template_directory_uri();?>/js/niceselect.js"></script>-->
<script type="text/javascript" src="https://nhs24-shgapi-live.azurewebsites.net/scripts/niceselect.min.js"></script>

 
<?php
 $shgID = get_the_ID();
$meta_key = 'shg-service-id';
$nodeID = get_post_meta( $shgID, $meta_key, true );
$nodeID = isset($nodeID) ? $nodeID:"";
$post_date = get_the_date( 'j F Y', $shgID);
$description = get_field('shg_long_description',$shgID);

?> 

 <!-- Symptoms Section HTML Start -->
     <div class="col-sm-12 bg-white-grey sghGuide" id="sghIDs">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 brdCrumbSGH">
                      <!-- Breadcrumb HTML Start -->
                        <?php //get_sidebar('breadcrumb');?>
        <nav class="breadcrumb_section" aria-label="breadcrumb">
            <div class="container">
    
        <ol id="breadcrumbs" class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo home_url();?>" title="Home">Home</a></li>
            <li class="breadcrumb-item self-help-guides"><a href="<?php echo home_url().'/self-help-guides'?>" title="Self Help Guides">Self-help guides</a></li>
        </ol>
          </div>
        </nav>
                        <!-- Breadcrumb HTML End -->
     </div>

     	 <div class="col-lg-9 col-sm-12 panel-content push--bottom ml-12">

                        <div class="row">
                            <div class="col-sm-12">
                                <h1 class="panel-intro__title">
                                    <?php echo get_the_title($shgID);?>
                                    <!--Self-help Guide: Get help with your mental wellbeing-->
                                </h1>
                                <?php if(!empty($description)){
                                 echo '<p class="panel-intro__desc nhsuk-body">'.$description.'</p>';
                            } ?>
                            </div>

 <div class="col-sm-12  soft--ends">
     <div class="self-help-guide">
        <h2 class="section-title" style="margin-top:25px;">Self-help guide</h2>


<div id="shg-container" class="row shg-containeList shg-id-<?php echo $nodeID;?>">
    <input type="hidden" id="userGUID" value="" />
    <input type="hidden" id="protocolID" value="<?php echo $nodeID;?>" />
    <!--<input type="hidden" id="protocolID" value="3883" />-->

    <div class="col-md-12">
     
        <div data-bind="visible: Questions().length > 0">
            <!-- ko if: $root.showReturn() -->
            <p id="symptom-container">
                <a id="symptoms" href="#" data-bind="click: $root.init">Return to Symptoms</a>
            </p>
            <!-- /ko -->
            <div data-bind="attr: { 'class': CurrentQuestionType() == 4 ? 'panel panel-' + CurrentQuestion().endPoint().endPointLayoutColour : 'panel panel-info' }">
                <div class="panel-heading">
                    <h2 class="h2" data-bind="text: ProtocolName"></h2>
                    <!-- ko if: CurrentQuestionType() == 4 -->
                    <img class="pull-right" style="margin-top: -48px" data-bind="attr: { src: CurrentQuestion().endPoint().endPointLayoutImage }" />
                    <!-- /ko -->
                </div>
                <div class="panel-body">
                    <div class="question-container" data-bind="with: CurrentQuestion">
                        <!-- ko if: nodeType() != 5 && nodeType() != 4 -->
                        <div data-bind="html: questionTop"></div>
                        <div data-bind="html: questionShared"></div>
                      
                        <div data-bind="foreach: answers().answersList">
                            <p data-bind="text: answerText, visible: $root.CurrentQuestionType() == 3"></p>
                            <div data-bind="visible: $root.CurrentQuestionType() == 0 || $root.CurrentQuestionType() == 2">
                                <label>
                                    <input type="radio" data-bind="checkedValue: id, checked: $root.CurrentSingleAnswer" />
                                    <span data-bind="text: answerText"></span>
                                </label>
                            </div>
                            <div data-bind="visible: $root.CurrentQuestionType() == 1">
                                <label>
                                    <input type="checkbox" data-bind="checkedValue: id, checked: $root.CurrentAnswers" />
                                    <span data-bind="text: answerText"></span>
                                </label>
                            </div>
                        </div>
                        <!-- /ko -->
                        <!-- ko if: nodeType() == 5 -->
                        <!-- ko if: $root.showIntro() -->
                        <div data-bind="html: protocol().questionTop"></div>
                        <!-- /ko -->
                        <!-- ko if: $root.showStatement() -->
                        <div data-bind="html: protocol().questionShared"></div>
                        <!-- /ko -->
                        <!-- ko if: $root.showExceptions() -->
                        <div data-bind="foreach: $root.Exceptions">
                            <h4 data-bind="text: title"></h4>
                            <div data-bind="html: description"></div>
                            <div data-bind="foreach: lookups">
                                <label>
                                    <input type="radio" data-bind="checkedValue: $data, checked: $parent.selectedLookup" />
                                    <span data-bind="text: $data"></span>
                                </label>
                                
                            </div>
                            <div class="shg-age-field age-<?php echo $nodeID;?>">
                            <label class="age-field">
                                <span class="visuallyhidden">Enter age</span>
                                <input type="number" min="0" max="125" step="1" pattern="\d+" class="form-control" id="age-input" data-bind="value: selectedLookup" style="width: 150px" onkeydown="javascript: return event.keyCode === 8 || event.keyCode === 46 ? true : !isNaN(Number(event.key))">
                                    
                               </label>
                           </div>
                           
                        </div>
                        <!-- /ko -->
                        <!-- ko if: $root.showIntro()-->
                        <div data-bind="html: protocol().questionBottom"></div>
                        <p>Last Updated: <b data-bind="text: moment(protocol().lastUpdated).format('Do MMMM YYYY')"></b></p>
                        <p>Next Review Date: <b data-bind="text: moment(protocol().nextReviewDate).format('Do MMMM YYYY')"></b></p>
                        <!-- /ko -->
                        <!-- /ko -->
                        <!-- ko if: nodeType() == 4 -->
                        <div data-bind="html: questionTop"></div>
                        <div data-bind="html: questionShared"></div>
                        <button class="btn btn-info" data-bind="click: $root.reviewAnswers, visible: nodeType() == 4">Review my answers</button>
                        
                        <div data-bind="html: questionBottom"></div>
                        
                        <!-- ko if: endPoint().showLocalSearch == true -->
                        <div id="local-services" class="local-service-hld">
                            <h2>Find your local services</h2>
                            <p>Search for a service near you by entering your postcode below.</p>
                            <p>Please input your postcode in the following format: A12 1BC</p>
                           <!--<p>To ensure accurate results, when entering your postcode please input your postcode in the following format: A12 1BC (Please ensure there are no spaces at the start or end of your postcode).</p>-->
                            <select name="shg-service" class="change">
                                <option value="gp-practices">GP Practices</option>
                                <option value="dental-services">Dental Services</option>
                                <option value="pharmacies">Pharmacies</option>
                                <option value="opticians">Opticians</option>
                            </select>
                            <div class="search-compass-home">
                                <label><span>Postcode</span> <input name="txtPostTown" type="text" id="txtPostTown" placeholder="A12 1BC" /></label>
                            </div>
                            <a onclick="return validateInput();" id="" class="read-mre" data-bind="click: $root.submitLocalServiceInfo">Search<span></span></a>
                            <input name="shg_hddnLat" type="hidden" id="shg_hddnLat" />
                            <input name="shg_hddnLng" type="hidden" id="shg_hddnLng" />
                        </div>
                       
                        <!-- /ko -->
                        <!-- ko if: endPoint().showInformInfo == true -->
                        <div id="inform-link" class="shg-nhs-inform alert-success">
                            <!--<img style="margin-bottom:10px;" src="http://shg.factory73.com/img/nhsinform_logo_small.png" />-->
                            <img style="margin-bottom:10px; margin-bottom:10px;width:190px;height:59px;" src="<?php echo get_template_directory_uri().'/assets/images/nhs-inform-logo--white.svg'?>" />
                            <p>NHS inform has more information on this condition.</p>
                            <a target="_blank" class="btn btn-success" data-bind="attr: { href: endPoint().informUrl }">Read more</a>
                        </div>
                        <!-- /ko -->
                        <!-- /ko -->
                        <!-- ko if: questionBottom().length > 0 && nodeType() !== 4 -->
                        
                        <div data-bind="html: questionBottom"></div>
                        <!-- /ko -->
                    </div>
                </div>
                <div class="panel-footer">
                    <!--<div class="buttons" style="height:60px; margin-top:10px;">
                        <button class="btn btn-info pull-left" data-bind="click: $root.previous, visible: !$root.hidePrevious()"><i class="glyphicon glyphicon-arrow-left"></i> Previous</button>
                        <button class="btn btn-info pull-right" data-bind="click: $root.next, visible: !$root.hideNext(), css: { disabled: $root.disableNext() == true }">Next <i class="glyphicon glyphicon-arrow-right"></i></button>
                    </div>-->
                    <div class="buttons shg-btn" style="height:60px; margin-top:10px;">
                        <button class="btn btn-info pull-left" data-bind="click: $root.previous, visible: !$root.hidePrevious()" style="display: none;">Previous</button>
                        <button class="btn btn-info pull-right" data-bind="click: $root.next, visible: !$root.hideNext(), css: { disabled: $root.disableNext() == true }, text: $root.showStatement() ? 'Start guide' : 'Next'">Start guide</button>
                    </div>
                </div>
            </div>
            <div id="ReviewAnswers" class="modal fade in" data-bind="showModal: $root.openDialog()">
                <div class="modal-dialog SSIDModal">
                    <div class="modal-content">
                        <div class="modal-header">
                           <h4>Review my answers</h4>
                           <button type="button" class="close" data-bind="click: $root.closeDialog" data-dismiss="modal" aria-hidden="true">&times;</button>
                            
                        </div>
                        <div class="modal-body popUps">
                            <div data-bind="foreach: $root.Questions">
                                <div data-bind="'if': nodeType() == 5">
                                    <h2 data-bind="text: protocol().protocolName"></h2>
                                    <div data-bind="html: protocol().questionTop"></div>
                                    <p data-bind="'if': $root.Exceptions().length > 0">
                                        You told us your credentials were:
                                    </p>
                                    <div data-bind="foreach: $root.Exceptions">
                                        <span data-bind="text: title"></span>: <span data-bind="text: selectedLookup"></span>
                                        <br />
                                    </div>
                                    <div data-bind="html: protocol().questionBottom"></div>
                                    <hr />
                                </div>
                                <div data-bind="visible: nodeType() != 4 && nodeType() != 5">
                                    <p data-bind="html: questionTop"></p>
                                    <p data-bind="html: questionShared"></p>
                                    <p><b>You said: </b> <span data-bind="text: answerText() == '' ? 'None' : answerText"></span></p>
                                    <p data-bind="html: questionBottom"></p>
                                    <hr />
                                </div>
                                <div data-bind="'if': nodeType() == 4">
                                    <p><b>Based on the information you gave us, we made the following recommendation: </b></p>
                                    <p data-bind="html: questionTop"></p>
                                    <p data-bind="html: questionShared"></p>
                                    <p data-bind="html: questionBottom"></p>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer sghFooter">
                            <a class="btn btn-default btnClosePop" data-bind="click: $root.closeDialog">Close</a>
                            <a class="btn btn-info btnInfoPop" data-bind="visible: $root.canDownload() == false, click: $root.createPDF">Keep a copy</a>
                            <a class="btn btn-success viewPdf" target="_blank" data-bind="visible: $root.canDownload() == true, attr: { href: $root.PDFLink }">View PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <!--shg-container-->
</div>

                            <div class="push--ends">
                                    <div class="epsilon dark-grey-2">
                                        Last updated:
                                    </div>
                                    <div class="gamma dark-grey-3">
                                       
                                      <?php echo isset($post_date) ? $post_date: "";?>
                                    </div>
                                </div>
                                
                                 <?php //get_sidebar('breadcrumb');?>
                                <nav class="breadcrumb_section bg-white" aria-label="breadcrumb">
                                    <div class="">
                                        <ol class="breadcrumb breadcrumFooter">
                                            <li class="breadcrumb-item"><a href="<?php echo home_url();?>">Home</a></li>
                                            <li class="breadcrumb-item"><a href="<?php echo home_url().'/self-help-guides' ?>"> Self-help guides</a></li>
                                        </ol>
                                    </div>
                                </nav>


            
                                <div class="no-print push--ends">
                <a onclick ="myFunction()" id="dropList" href="javascript:void(0)" class="js-toggle btn btn--icon btn--feedback" role="button" aria-controls="feedback" aria-expanded="false">
                    How can we improve this page?
                    <span class="icon  toggle-off" style="display:none">
                        <i class="fa fa-chevron-up f-8"></i>
                    </span>
                    <span class="icon  toggle-on">
                        <i class="fa fa-chevron-down f-8"></i>
                    </span>
                </a>
                <div id="feedback" class="feedback mystyle">
                    <h2 class="primary-color no-margin">
                        Help us improve NHS inform
                    </h2>
                   <div style="display:none;" id="feedback-message" class="alert">
                        <!-- Replaced by JS -->
                        <h2>Thank You</h2>
                        <p>Your feedback has been received</p>
                    </div>
                    <form id="feedbackForm" autocomplete="off" novalidate="" name="feedbackForm" class="form" method="POST" action="">
                        <div class="form-row">
                            <p class="dark-grey-2">
                                Don’t include personal information e.g. name, location or any personal health conditions.
                            </p>
                        </div>
                        <div class="form-row">
                            <label for="Email" class="form-control-label required">
                                Email Address
                            </label>
                            <input id="Email" name="email" class="form-control" type="email" maxlength="255" required="">
                            <span class="block delta dark-grey-2">
                                e.g. you@example.com
                            </span>
                            <span class="field-validation-error push-half--bottom"></span>
                        </div>
                        <div class="form-row">
                            <label for="Message" class="form-control-label required">
                                Message
                            </label>
                            <input id="Message" name="message" class="form-control" type="text" maxlength="500" required="">
                            <span class="block delta dark-grey-2">
                                Maximum of 500 characters
                            </span>
                            <span class="field-validation-error push-half--bottom"></span>
                        </div>
                        <div class="form-row form-row--btns">
                           <button id="feedback-submit" type="submit" class="btn btn--primary btn--icon btn-bg">
                                Send feedback
                                <span class="icon"> 
                                    <i class="fa fa-chevron-right f-8" style="font-size: 0.8rem; padding: 8px"></i>
                                </span> 
                            </button>
                        </div>
                    </form>
                </div>
            </div>


</div><!--12-->
</div> <!--row end-->
</div>

                
     <div class="col-lg-3 col-sm-12 mb-4 w-24">

        <?php get_sidebar('shg');?>
                    
            <!--<div class="panel-content panel-content--half push--bottom text-center pc-alter">
                <button class="btn--clean border-none" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
                    <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
                </button>
            </div>-->

                <!-- <div class="col-lg-4 col-md-5 col-sm-12 mb-4 bg-white panel-content push--bottom push--top "> -->
                   
                </div>
                



    	</div> <!--row-->

	</div>
</div>



<script>
function myFunction() {
const elementDropList = document.getElementById('dropList');

const attrs = elementDropList.getAttributeNames().reduce((acc, name) => {
  return {...acc, [name]: elementDropList.getAttribute(name)};
 }, {}); 
 if(attrs['aria-expanded']==='false') {
    elementDropList.setAttribute( "aria-expanded", true ) 
 }
 else {
     elementDropList.setAttribute( "aria-expanded", false ) 
 }

  var elementFeedBack = document.getElementById("feedback");
  elementFeedBack.classList.toggle("mystyle");
}
</script>

<style>
.mystyle {
    display:none;
    color:blue;
}
.shg-age-field{
    display: none !important;
}
.shg-age-field.age-6761{
    display: block !important;
}
.shg-nhs-inform.alert-success{
    background-color: #fff !important;
    border-color: #fff !important;
    margin-top: 45px;
}
.shg-nhs-inform.alert-success p{
    color:#404040 ;
}
.form label.required:after { 
    content: " *";
 color: #a10000;
}
.error{
   color: #a10000 !important;
}
.shg-btn .btn.disabled{
    pointer-events: auto;
}

</style>
<?php
//get_sidebar();
get_footer();
get_sidebar('feedback_js');