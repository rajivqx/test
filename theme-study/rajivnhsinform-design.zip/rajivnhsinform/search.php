<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package nhsinform
 */

get_header();
?>
<div class="row main_row">
    <div class="col-sm-12">
        <nav class="breadcrumb_section" aria-label="breadcrumb">
            <ol id="breadcrumbs" class="breadcrumb">
                 <li class="breadcrumb-item">
                    <a href="<?= home_url() ?>" title="Home">Home</a>
                </li>
            </ol>   
        </nav>
    </div>

     
                
				 
	                    
	                    	
		<?php if ( have_posts() ) :

			 get_template_part( 'template-parts/content', 'search' );
			 

			

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>		   
            
</div>

 
<?php 
get_footer();
