<?php
/**
 * The template for displaying all single posts
 *
 *
 * @package nhsinform
 */

get_header('inner1');?>


<div class="microsite_overlay"></div>
    <div class="microsite_navigation">
        <h3>Translations <button class="close_micro"><i class="fa-solid fa-xmark"></i></button></h3>
        <nav class="microsite_nav_list">
            <ul>
                <li>
                    <a href="<?php echo home_url('translations');?>/#15421">Languages</a>
                    <span class="micro_bg_01 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                        <?php
                    $terms = get_terms( 'languages', array( 'parent' => '336', 'orderby' => 'slug', 'hide_empty' => false ) );
                        foreach($terms as $term) { ?>
                        <li><a href="<?php echo get_term_link( $term->slug, 'languages' );?>"><?php echo $term->name;?></a></li>
                        <?php } ?>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo home_url('translations');?>/#15428">Formats</a>
                    <span class="micro_bg_02 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                    <?php $terms1 = get_terms( 'languages', array( 'parent' => '337', 'orderby' => 'slug', 'hide_empty' => false ) );
                        foreach($terms1 as $term) { ?>
                        <li><a href="<?php echo get_term_link( $term->slug, 'languages' );?>"><?php echo $term->name;?></a></li>
                        <?php } ?>
                        
                    </ul>
                </li>
            </ul>
        </nav>
        <div class="micro_nav_slide_list_container">
            <span class="micro_nav_slide_list_back">Back</span>
        </div>
    </div>
    <!-- MicroSite Header HTML Start -->
    <div class="microsite_header translateHeader">
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <a href="#" class="microsite_title">Translations</a>
                </div>
                <div class="col-3">
                    <div class="hamburger_icon">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <?php get_sidebar('breadcrumb');?>

    <!-- Symptoms Section HTML Start -->
    <section class="pannel_wrapper microsite_wrapper translationsingle">
        <div class="container">
		<div class="row">
		<div class="col-sm-12 col-lg-9  push--bottom wbsl-72">
             
        <div class="pannel_wrapper_container microsite_wrapper_container">
                    <!-- <div class="wrapperNHS panel-content push--bottom push--top"> -->
                    <div class="row">
                        <div class="col col-sm-12">
                            <h1 class="giga bold primary-color push--bottom">
                                <?php the_title();?>
                            </h1>
                        </div>

                    <div class="col-sm-12 translationcontent" style="margin-bottom:0px;">
                    <?php  
                        while(have_posts()): the_post();?>
                            <?php the_content(); 
                                if(comments_open() || get_comments_number()) :
                                    //comments_template();
                                endif;?>
                        <?php endwhile; ?>
                    </div>


                        <?php if(get_field('attribution_logo')):
                            $attribution_logo = get_field('attribution_logo'); 
                            $imageID  = attachment_url_to_postid($attribution_logo);
                            $imageData = wp_get_attachment($imageID);
                        ?>
                        <div class="row">
                            <div class="col-sm-12 soft bg-light-grey-1 translationgrey">
                                <img src="<?php echo $attribution_logo;?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
                                <?php if(get_field('attributed_to')):?>
                                    <p class="nhsuk-body-s no-margin">
                                        Source:
                                        <?php if(!get_field('attributed_url')) { 
                                             the_field('attributed_to');
                                        }  else {  ?>
                                        <a href="<?php echo get_field('attributed_url');?>" class="bold" rel="external" target="_blank"><?php the_field('attributed_to');?> <span class="visuallyhidden">- Opens in new browser window</span></a>
                                            <?php } ?>
                                        </p>
                                <?php endif;?>
                            </div>
                        </div>
                        <?php endif;?>
                        <div class="col-sm-12 col-lg-9 lgtranslate">
                        <div class="push--ends translationpush">
                            <p class="nhsuk-body-s nhsuk-u-secondary-text-color no-margin">
                                Last updated:
                                <br>
                                <?php  the_date('d F Y'); ?> 
                            </p>
                        </div>
                    <?php //get_sidebar('breadcrumb-bottom');?>
                        <?php
						if (!empty(get_sidebar('feedback-form-transalation'))) {
                        if(get_field('feedback_disabled')[0] !="yes"){
                        get_sidebar('feedback-form-transalation'); 
                        } }
                        ?>
                        </div>
        
      </div>
                    </div> </div>

                    <div class="col-sm-12 col-lg-3  push--bottom wbsl-24">
                    <?php // get_sidebar('translations'); ?>
                    <?php if(@get_field('disable_info_for_me')[0] !="yes") { ?>
                        <div class="wrapperNHS panel-content push--bottom panel-content--half text-center translationLeftImg1">
                        <button aria-pressed="false" class="ifmButton remove"><span class="visuallyhidden">Add this page to Info For Me</span></button>
                        <button aria-pressed="false" class="ifmButton add"><span class="visuallyhidden">Add this page to Info For Me</span></button>
                        </div>
                        <?= add_sidebar_info(); ?>
                    <?php } ?>
                    <?php if(@get_field('web_chat_disabled')[0] !="yes" ) { ?>
                        <div class="panel-content panel-content--half push--bottom text-center translationLeftImg2">
                        <button class="btn--clean informBSLbtn" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
                            <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
                        </button>
                    </div>
                    <?php } ?>
                </div>
  </div>
</div>
</div>
</section>
<script>
        jQuery(document).ready(function () {

                        var lspan = $('#breadcrumbs span span').children().length; 
                       if(lspan===5){
                        $("#breadcrumbs span span:first-child").remove();
                        $("#breadcrumbs span span").children().eq(0).hide();
                        $("#breadcrumbs span span").children().eq(1).hide();
                        $("#breadcrumbs span span").children().eq(2).hide();
                        $("#breadcrumbs span span:eq(3)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                        //var href = $("#breadcrumbs span span:last-child a[href]").attr('href');
                        //var result1 = href.replace("falls_type", "falls-assessment");
                        //$("#breadcrumbs a[href]").attr("href", result1);
                        //alert(href);
                       }
                       if(lspan===4){
                        $("#breadcrumbs span span:first-child").remove();
                        $("#breadcrumbs span span").children().eq(0).hide();
                        $("#breadcrumbs span span").children().eq(1).hide();
                        //$("#breadcrumbs span span").children().eq(2).hide();
                        $("#breadcrumbs span span:eq(2)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                        //var href = $("#breadcrumbs span span:last-child a[href]").attr('href');
                        //var result1 = href.replace("falls_type", "falls-assessment");
                        //$("#breadcrumbs a[href]").attr("href", result1);
                        //alert(href);
                       }                      
                    });
         
function myFunction() {
const elementDropList = document.getElementById('dropList');

const attrs = elementDropList.getAttributeNames().reduce((acc, name) => {
  return {...acc, [name]: elementDropList.getAttribute(name)};
 }, {}); 
 if(attrs['aria-expanded']==='false') {
    elementDropList.setAttribute( "aria-expanded", true ) 
 }
 else {
     elementDropList.setAttribute( "aria-expanded", false ) 
 }

  var elementFeedBack = document.getElementById("feedback");
  elementFeedBack.classList.toggle("mystyle");
}
</script>

<style type="text/css">
    #breadcrumbs span span span span:before{
    background: url("data:image/svg+xml,%3Csvg class='nhsuk-icon nhsuk-icon__chevron-left' xmlns='http://www.w3.org/2000/svg' fill='%23005eb8' height='24' width='24' viewBox='8 0 24 24' aria-hidden='true'%3E%3Cpath d='M8.5 12c0-.3.1-.5.3-.7l5-5c.4-.4 1-.4 1.4 0s.4 1 0 1.4L10.9 12l4.3 4.3c.4.4.4 1 0 1.4s-1 .4-1.4 0l-5-5c-.2-.2-.3-.4-.3-.7z'%3E%3C/path%3E%3C/svg%3E") no-repeat;
    content: '';
    display: flex;
    height: 18px;
    left: 0;
    position: relative;
    top: 0;
    width: 10px;
    }
.wp-embed-responsive .wp-block-embed .wp-block-embed__wrapper:before {
    position: relative;
}
.mystyle {
    display:none;
    color:blue;
}
.form label.required:after { 
    content: " *";
 color: #a10000;
}
.error{
   color: #a10000 !important;
}
.bg-light-grey-1{
    width:80%;
    margin-left:10px !important;
}
.microsite_wrapper::before {
    height: 180px;
    background-color: #208da0;
}
.contact__title, .support-service__title {
color: #666;
display: block;
margin: 0;
font-weight: 300;
left: -12px;
position: relative;
}
.contact__desc, .support-service__desc {
color: #333;
display: block;
margin: 0;
}
.contact__desc, .support-service__desc {
color: #333;
display: block;
margin: 0;
left: -12px;
position: relative;
}
.gutt {
width: 46%;
margin: 2%;
}
</style> 
      
<?php
get_footer();
get_sidebar('feedback_js');
?>