<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nhsinform
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2" />
        <style type="text/css">
    </style>
	<?php wp_head(); ?>
</head>
<body>
<header>
      <nav class="navbar navbar-expand-lg">
        <div class="container">
        <a class="navbar-brand" href="<?php echo esc_url( home_url( '/'));?>">
                <?php
						$custom_logo_id = get_theme_mod( 'custom_logo');
						$logo = wp_get_attachment_image_src( $custom_logo_id,'full');
						if(has_custom_logo()){
                            $imageID  = attachment_url_to_postid(@$logo[0]);
                            $imageData = wp_get_attachment($imageID);
                        ?>
                        <img src="<?php echo esc_url( $logo[0]);?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
						<?php }else{
							echo '<h1>' .get_bloginfo('name').'</h1>';
						}
					?>
                </a>

          <!-- Mobile Search Icon -->
          <form class="mobile_search d-md-block d-lg-none">
            <button class="btn" type="button">
              <i class="fa-solid fa-magnifying-glass"></i>
            </button>
          </form>
          <!-- Mobile Search Icon -->

          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarScroll"
            aria-controls="navbarScroll"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarScroll">
            
          <form class="d-flex custom_search d-none d-lg-block">
                        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
                        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </form>

            <ul class="nav_right navbar-nav navbar-nav-scroll">
             <!-- <li class="nav-item">
                <a class="nav-link touch_pad" href="#"
                  ><img src="images/launchpad-icon.svg" alt="" Icon
                /></a>
              </li> -->
              <li class="nav-item user_info">
              <a class="nav-link" href="<?php echo esc_url( home_url( '/' ) ); ?>info-for-me"><span>0</span></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>