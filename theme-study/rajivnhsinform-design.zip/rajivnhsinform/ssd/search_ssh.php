<form class="search-results relative js-location" id="search-form" action="<?= home_url( $wp->request ) ?>"  method="GET">
    <input id="sortby" name="sortby" type="hidden" value="_distance">
    <input id="sortdir" name="sortdir" type="hidden" value="Asc">
      <input name="q" type="text" id="location-input" class="search-results__input js-geolocation__input" placeholder="Place / postcode">
       <button type="submit" class="search-results__submit btn--green btn"><i class="fa-solid fa-magnifying-glass"></i></button>
</form>

<script type="text/javascript">
  const API_KEY = 'AIzaSyBcxJ4JU_Ie4ePFv3yMAcBWSeRgS2xgpg0';
  const searchForm = document.getElementById('search-form');
  searchForm.addEventListener('submit', event => {
    event.preventDefault();
    const locationInput = document.getElementById('location-input').value;
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: locationInput }, (results, status) => {
      if (status === 'OK') {
        const location = results[0].geometry.location;
        const newUrl = `${window.location.origin}${window.location.pathname}?sortby=_distance&sortdir=Asc&locpt=${location.lat()},${location.lng()}&q=`;
        window.location.href = newUrl;
      } else {
        const newUrl = `${window.location.origin}${window.location.pathname}?sortby=_distance&sortdir=Asc&locpt=55.378051,-3.435973&q=`;
        window.location.href = newUrl;
      }
    });
  });

  function initMap() {
  }
  const script = document.createElement('script');
  script.src = `https://maps.googleapis.com/maps/api/js?key=${API_KEY}&callback=initMap`;
  document.body.appendChild(script);
</script>
