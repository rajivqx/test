<?php 

function side_info_me($current_collection,$id) {

?>

<div class="sidebar_infome wrapperNHS panel-content push--bottom panel-content--half push--top text-center">    
		<button aria-pressed="false" class="ifmButton" data_id="<?= $id; ?>"><span class="visuallyhidden">Add this page to Info For Me</span></button>
	</div>

	 
	<script type="text/javascript">
		jQuery(document).ready(function() {
	 
			let storedDataString = $.cookie('data');


			try {

			  	let jsonStr = JSON.parse(storedDataString);


			  	if (jsonStr.length == 0) {
					var dataItems = [];
				}else{
					let emailToRemove = '<?= $id ?>';
			  		let indexToRemove = -1;
			  		let id;

					for (let i = 0; i < jsonStr.length; i++) {
					  if (jsonStr[i].Id === emailToRemove ) {
					    indexToRemove = i;
					    id = jsonStr[i].Id;
					    break;
					  }
					}

					if (indexToRemove !== -1) {

					var let  = '<?= $id; ?>';

					console.log(let);
					console.log(id);
 

					  if (let == id) {
					  	jQuery('.user_info .nav-link span').text(jsonStr.length);
					  	jQuery('.wrapperNHS .ifmButton').addClass('remove');
					  }


					}
					var dataItems = jsonStr;
				}


			} catch (e) {
			  var dataItems = [];
			}

	 		$.cookie('service_tab', 1,{ expires: 30, path: '/' });
	 		
	  
	  		jQuery('.wrapperNHS .ifmButton').on('click', function() {
			 	if (jQuery(this).hasClass('remove')) {

			 		let myData = $.cookie('data');
			 		let jsonStr = JSON.parse(myData);
			  		let emailToRemove = '<?= $id; ?>';
			  		let indexToRemove = -1;
			  		let id_name = -1;
					for (let i = 0; i < jsonStr.length; i++) {
					  if (jsonStr[i].Id === emailToRemove ) { 
					    id_name = jsonStr[i].Id;
					    indexToRemove = i;
					    break;
					  }
					}

					if (indexToRemove !== -1) {
						let newArray = jsonStr.filter(obj => obj.Id !== id_name);
						let dataStrinsg = JSON.stringify(newArray);	
						$.cookie('data', dataStrinsg,{ expires: 30, path: '/' });
						console.log(newArray);
					}

					var count = jQuery('.user_info .nav-link span').text();
				  	let num = parseInt(count)-1;
				  	jQuery('.user_info .nav-link span').text(num);
			   		jQuery(this).removeClass('remove');
			  	}else{

			  		let newData = <?= $current_collection; ?>;
				  	dataItems.push(newData);
				  	let dataString = JSON.stringify(dataItems);
				  	$.cookie('data', dataString,{ expires: 30, path: '/' });

				  	let storedDataString = $.cookie('data');


				  	var count = jQuery('.user_info .nav-link span').text();
				  	let num = parseInt(count)+1;
				  	jQuery('.user_info .nav-link span').text(num);
			   		jQuery(this).addClass('remove');
			  	}
			});
		});
	</script>

<?php 

}
 ?>