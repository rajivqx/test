<div class="row main_row">
    <div class="col-sm-12">
        <nav class="breadcrumb_section" aria-label="breadcrumb">
            <ol id="breadcrumbs" class="breadcrumb">
                 <li class="breadcrumb-item">
                    <a href="<?= home_url() ?>" title="Home">Home</a></li>
                 <li class="breadcrumb-item">
                    <a href="<?= home_url() ?>/scotlands-service-directory" title="Scotland's Service Directory">Scotland's Service Directory</a>
                </li>
            </ol>   
        </nav>
    </div>
    <div class="col-lg-3 col-sm-12 mb-4 filter_tab">
        <?php include(dirname(__FILE__) . "/filter.php"); ?>
    </div>
    <div class="col-lg-9 col-sm-12 mb-4 panel-content ">
        <div class="row">
            <div class="col col-sm-12">
                <!-- <pre><?php //print_r($collectionJsone) ?></pre>; -->
                <?php if (!isset($_GET['locpt'])): ?>
                    <!--<h1 class="giga bold primary-color push--bottom">
                        <//?= @$collectionJsone->Documents[0]->Dataset->Text;?>
                    </h1>-->
                <?php endif ?>
            </div>
            <div class="col-sm-12">
                <div class="header_search">
                    <?php if (!empty($collectionJsone->Pagination->Total)): ?>
                        <?php if (isset($_GET['locpt'])): ?>
                            <h3 class="push-half--bottom nhsuk-heading-m"><?= $collectionJsone->Pagination->Total ?> Search results (ordered by service nearest to your location)</h3>
                        <?php else: ?>
                            <h3 class="push-half--bottom nhsuk-heading-m"><?= $collectionJsone->Pagination->Total ?> Search results </h3>
                        <?php endif; ?>
                    <?php endif ?>

                    <form class="search-results relative js-location" id="search-form" action="<?= home_url( $wp->request ) ?>"  method="GET">
                        <input id="sortby" name="sortby" type="hidden" value="_distance">
                        <input id="sortdir" name="sortdir" type="hidden" value="Asc">
                        <input type="hidden" id="locpt" name="locpt" value="" class="js-locpt">
                        <input name="q" type="text" id="location-input" class="search-results__input js-geolocation__input" placeholder="Place / postcode">
                        <button type="submit" class="search-results__submit btn--green btn"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </form>

                    <div class="block push-half--bottom" >
                        <p class="bold red nhsuk-body-s" style="color: #d20c0c;">With current Public Health advice around COVID-19, some offered services may not be available and some services may be operating different opening times from that stated below or may be closed temporarily.  We recommend that you contact the service prior to attending.</p>
                    </div>
                </div>
                <ul class="search__results">
                <?php 
                    foreach ($collectionJsone->Documents as $value): ?>
                        <li class="search__item search__item--ssd">
                            <div class="ssd_content-block">
                            <span class="block">
                                <?php if($value->Dataset->Text!='Accident And Emergency'){ 
                                 if (isset($value->Dataset->Text) && !empty($value->Dataset->Text)){ echo $value->Dataset->Text; }} ?>
                                 </span>

                                <h2 class="nhsuk-heading-m">
                                    <a href="<?= home_url( $wp->request ) ?>/<?= $value->Id ?>" title="1 Smile Dental Clinic"><?= $value->Name ?></a>
                                </h2>
                               <?php if(isset($value->Distance)){ ?>
                                    <span class="delta dark-grey-2">
                                    <?php echo number_format(round($value->Distance,1),'1','.','').' miles away';?>
                                    </span>
                                <?php } ?>    
                                <p class="search__content">
                                        <?php
                                            if(isset($value->OpenState->State) && !empty($value->OpenState->State)){
                                             echo '<span class="open-status open-status--'.$value->OpenState->State.'">';  
                                                echo "Currently ".$value->OpenState->State;
                                            echo '</span>';
                                            }
                                            else if(empty($value->OpenState->State) && $value->Dataset->Text == 'Health and Well-being'){
                                                echo '<span class="open-status open-status-not-provided">';
                                                echo 'Opening times not provided';
                                                 echo '</span>';
                                            }
                                        ?> 
                                    <div class="details_c"> 
                                        <?php 
                                            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 

                                            if(strpos($actual_link, 'health-and-wellbeing-services') !== false):
                                        ?>
                                            <p>
                                            <?php 
                                                if((isset($value->Summary) && !empty($value->Summary)) || (isset($value->Description) && !empty($value->Description))){  

                                                    $Summary = strip_tags($value->Summary);
                                                    $Description = strip_tags($value->Description);
                                                    $details = $Summary.$Description; 
                                                    if (strlen($details) > 196 ) {
                                                        echo substr($details, 0, 196) . "...";
                                                    }else{
                                                        echo $details;
                                                    }
                                                } 
                                            ?>
                                            </p>
                                        <?php else: ?>
                                            <?php if (isset($value->Summary) && !empty($value->Summary)) :?>
                                            <p><?= $value->Summary ?></p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </p>
                            </div>
                            <div class="ssd_details-block">
                                <div class="row relative">

                                    <?php if (!empty($value->Contact->OrganisationName) || !empty($value->Contact->Address1)  || !empty($value->Contact->Address2) ||  !empty($value->Contact->Address3) ||  !empty($value->Contact->Town) ||  !empty($value->Contact->County) ||  !empty($value->Contact->Postcode)): ?>
                                        <div class="col-sm-12 col-md-6">
                                            <h3 class="no-margin nhsuk-heading-s">Address</h3>
                                            <address class="no-margin">
                                            <?php
                                                    if (!empty($value->Contact->OrganisationName )) {
                                                         echo $value->Contact->OrganisationName."</br>";
                                                    }
                                                    if (!empty($value->Contact->Address1)) {
                                                         echo $value->Contact->Address1."</br>";
                                                    }
                                                    if (!empty($value->Contact->Address2)) {
                                                         echo $value->Contact->Address2."</br>";
                                                    }
                                                    if (!empty($value->Contact->Address3)) {
                                                         echo $value->Contact->Address3."</br>";
                                                    }
                                                    if (!empty($value->Contact->Town)) {
                                                         echo $value->Contact->Town."</br>";
                                                    }
                                                    if (!empty($value->Contact->County)) {
                                                         echo $value->Contact->County."</br>";
                                                    }
                                                    if (!empty($value->Contact->Postcode)) {
                                                        echo $value->Contact->Postcode;
                                                    }
                                                ?>
                                            </address>
                                        </div>

                                    <?php endif; ?>
                                    <div class="col-sm-12 col-md-6">
                                       <?php
                                        if(!empty($value->Service) && $value->Service[0]->ServiceSubType->Text != 'None') { ?>
                                        <h3 class="no-margin nhsuk-heading-s">Services Offered</h3>
                                        <ul class="nhsuk-list nhsuk-list--bullet no-margin">
                                            <?php $ServiceSubType =[]; ?>
                                            <?php foreach ($value->Service as $service): ?>
                                                <?php if ($service->ServiceSubType->Text != 'None'): ?>
                                                    <?php $ServiceSubType[] = $service->ServiceSubType->Text; ?>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                            <?php $aa = array_unique($ServiceSubType); ?>
                                            <?php foreach ($aa as $service): ?>
                                                    <li><?= $service ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                        <?php } ?>
                                    </div>
                                      
                                </div>
                            </div>

                            <?php if (isset($value->Service[0]->ServiceSubType->Text) && !empty($value->Service[0]->ServiceSubType->Text)): ?>
                                <?php if ($value->Service[0]->ServiceSubType->Text =='Telephone Support'): ?> 
                                    <a href="<?= home_url() ?>/contact-request?ds=<?= $value->Dataset->Value ?>&id=<?= $value->Id ?>" class="btn btn--green btn--cfc btn--small" title="Request this service to contact you" alt="Request service to contact you">Click To Be Contacted</a>
                                <?php endif ?>
                            <?php endif ?>

                            <?php
                                    if(isset($value->Dataset->Text) && !empty($value->Dataset->Text) && strtolower($value->Dataset->Text) == "health and well-being"){ 
                                        $classNameByProvider = '';
                                        $contentByProvideName = '';
                                        if($value->ProviderName == "ALISS" && $value->IsClaimed){
                                            $classNameByProvider = 'ssd--aliss-secured';
                                            $contentByProvideName ="'Claimed' ALISS information is maintained directly by the organisation, group or individual delivering the services or activities."; 
                                        }elseif($value->ProviderName == 'ALISS'){
                                            $classNameByProvider = 'ssd--aliss';
                                            $contentByProvideName ="ALISS information is added and maintained by professionals, organisations and citizens living or working in local communities throughout Scotland."; 
                                                
                                        }elseif($value->ProviderName == 'NHS Scotland'){
                                            $classNameByProvider = 'ssd--nhs';
                                            $contentByProvideName ="This service has been added and quality assured by your local NHS Board or NHS Scotland and is provided at national and/or local level.";
                                        }else{
                                         $classNameByProvider = 'ssd--hscp';
                                         $contentByProvideName ="This service has been added and quality assured by your local Health and Social Care Partnership (HSCP) and is provided, commissioned or regularly signposted to by them.";
                                        } 

                                        ?>
                                        <div class="ssd-service-provider">
                                            <p class="nhsuk-body-s no-margin">
                                                <span class="inline-block ssd <?php echo $classNameByProvider;?> ssd--spaced" title="Service listing maintained by <?=$value->ProviderName;?>" aria-label="Service listing maintained by <?=$value->ProviderName;?>"></span><?php echo $contentByProvideName;?> More information <a target="_blank" href="<?=home_url('scotlands-service-directory');?>" title="More Information About Scotland's Service Directory">about Scotland's Service Directory</a>.
                                            </p>
                                        </div>
                                     <?php } ?> 
                        </li>
                    <?php endforeach; ?>
                 
                        <div class="text-center">
                            <?php include(dirname(__FILE__) . "/pagination.php"); ?>
                        </div>
                </ul>
             </div>
        </div>
    </div>
</div>

<style type="text/css">
    .search__item--ssd {
        border: 0;
        padding: 20px;
        background: #efefef;
        margin: 0 0 20px;
        position: relative;
    }
    .pagination__list {
        border-top: 1px solid #e6e6e6;
        width: auto;
        display: flex;
        gap: 15px;
        justify-content: center;
    }

    .filter__list-link:before {
    color: #b3b3b3;
    content: "\E823";
    display: block;
    font-family: fontello;
    left: 0;
    position: absolute;
    top: 7px;
}.filter__list-link {
    color: #707070;
    display: block;
    margin-bottom: 0;
    padding: 6px 0 6px 24px;
    position: relative;
}.header_search {
    display: flex;
    flex-wrap: wrap;
}

.filter__list-link:before {
    color: #b3b3b3;
    content: "\f096";
    display: block;
    font-family: FontAwesome;
    left: 0;
    position: absolute;
    top: 7px;
}
.filter__list-item.selected .filter__list-link:before {
    color: #03759b;
    content: "\f046";
}

.nhsuk-selected__remove {
    display: inline-block;
    width: 24px;
    height: 24px;
    background: #03759b;
    color: #fff;
    text-align: center;
    border-radius: 50%;
}

.ssd--aliss {
    background-image: url('<?php echo get_template_directory_uri();?>/assets/images/ssd-aliss.png');
}

.ssd--hscp{
    background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/ssd-hscp.png);
    background-position: 0 0;
    width: 32px;
}
.ssd--nhs {
    background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/ssd-nhs.png);
    background-position: top right;
    width: 56px;
}

.ssd--aliss-secured{
    background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/ssd-aliss-secured.png);
}
.inline-block {
    display: inline-block;
}
.ssd-service-provider p span {
    position: absolute;
    top: 3px;
    left: 0;
    }


 
</style>
 

<script type="text/javascript">
    jQuery(document).ready(function() {

        jQuery(".js-toggle").click(function(){
          jQuery(this).toggleClass('active');
        });

    });
 
    // const API_KEY = 'AIzaSyBcxJ4JU_Ie4ePFv3yMAcBWSeRgS2xgpg0';
    // const searchForm = document.getElementById('search-form');
    // searchForm.addEventListener('submit', event => {
    //   event.preventDefault();
    //   const locationInput = document.getElementById('location-input').value;
    //   const geocoder = new google.maps.Geocoder();
    //   geocoder.geocode({ address: locationInput }, (results, status) => {
    //     if (status === 'OK') {
    //       const location = results[0].geometry.location;
    //       const newUrl = `${window.location.origin}${window.location.pathname}?sortby=_distance&sortdir=Asc&locpt=${location.lat()},${location.lng()}&q=`;
    //       window.location.href = newUrl;
    //     } else {
    //       const newUrl = `${window.location.origin}${window.location.pathname}?sortby=_distance&sortdir=Asc&locpt=55.378051,-3.435973&q=`;
    //       window.location.href = newUrl;
    //     }
    //   });
    // });

    // function initMap() {
    // }
    // const script = document.createElement('script');
    // script.src = `https://maps.googleapis.com/maps/api/js?key=${API_KEY}&callback=initMap`;
    // document.body.appendChild(script);
</script>
