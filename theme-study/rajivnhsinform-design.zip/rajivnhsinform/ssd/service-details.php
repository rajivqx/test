<?php 
function ssd_style2(){
    wp_enqueue_style('ssd',get_template_directory_uri().'/assets/css/ssd.css',array(), _S_VERSION);
    }
add_action('wp_enqueue_scripts', 'ssd_style2'); 

$key = '065671d43cfa4e38b9788f2aba0c356a';
$args = array(
    'headers' => array(
        'Ocp-Apim-Subscription-Key' => $key,
        'Authorization' => $key
    ),
); 
global $wp;
$url1 = "";
$url= home_url( $wp->request );
$url = explode("/",$url);
$dataset = array_slice(array_filter($url), -2)[0];
$last_part = end($url);
switch ($dataset) {
    case "dental-services":
        $url = "dentist";
        break;
    case "gp-practices":
        $url = "gp-practice";
        break;
    case "health-and-wellbeing-services":
        $url = "hwb";
        break;
    case "hospitals":
        $url = "hospital";
		$url1 = "hospital";
        break;
    case "opticians":
        $url = "optician";
        break;
    case "pharmacies":
        $url = "pharmacy";
        break;
    case "sexual-health-clinics":
        $url = "sexual-health-clinic";
        break;
  default:
    $url = "accident-and-emergency";
}

$response = wp_remote_get('https://nsdfapp1.azure-api.net/nsd/'.$url.'/'.$last_part, $args);

if (!is_wp_error($response)):
	$body = wp_remote_retrieve_body($response);
    $data = json_decode($body);
    if ($data):

?>

<?php get_header(); ?>

<?php 
    global $wp;
    $url= home_url( $wp->request );
    $url = explode("/",$url);
    $url = end($url);
?>


<!--Alert Section HTML End-->
    <!--Banner Section HTML End-->
    <!-- Symptoms Section HTML Start -->
	
    <div class="bg-white-grey soft--bottom ssd-servive-detail <?= $url ?>">
        <div class="container">
			 <div class="row main_row">
			    <div class="col-sm-12 ssd_breadcrumbs">
			    <?php get_sidebar('ssd_breadcrumbs');?>
			    </div>
			    <div class="col-lg-9 col-sm-12 mb-4 panel-content ssdW-72">
			        <div class="row">
			            <div class="col col-sm-12">
			            	<div role="alert" title="Your feedback for this service has been sent" class="alert alert--info" id="nsdFeedbackConfirmation" name="nsdFeedbackConfirmation" style="display: none;">
						        <p>Thank you for reporting a problem with this service. We will consider your request and make any changes within 48 hours.</p>
						        <span class="fa fa-exclamation-triangle"></span>
						    </div>
						    
			                <h1 class="giga bold primary-color push--bottom service_title">
			                    <?php if (isset($data->Name) && !empty($data->Name)){ echo $data->Name; } ?>
			                </h1>
			            </div>
			            <div class="col-sm-12"> 
							<div class="col-sm-12">
							    	<button class="btn btn--primary push-half--bottom" onclick="history.back()" onkeydown="history.back()">Back To List</button>
							        <a href="#user-feedback-form" class="form_btn_link">
							        	<button class="btn btn--primary push-half--bottom form_btn">Report Listing</button>
							        </a>

							        <?php if (isset($data->Service[0]->ServiceSubType->Text) && !empty($data->Service[0]->ServiceSubType->Text)): ?>
                                		<?php if ($data->Service[0]->ServiceSubType->Text =='Telephone Support'): ?> 
							        		<a href="/contact-request?ds=<?= $data->Dataset->Value ?>&id=<?= $data->Id ?>" class="btn btn--green push-half--bottom btn--cfc" title="Request service to contact you" alt="Request service to contact you">Click To Be Contacted</a>
		                                <?php endif ?>
		                            <?php endif ?>

							</div>
							<div class="col-sm-12">
								<?php if(isset($data->Description) && !empty($data->Description)):?>
									<div class="editor beta push--bottom remove-inline-style">
										<p></p>
										<?php if (strpos($data->Description, "<li>") !== false): ?>
											<?= $data->Description ?>

											 <?php
											 	$b_open = substr_count($data->Description, '<b>'); 
											 	$b_close = substr_count($string, '</b>');
											 	if ($b_open > $b_close) {
											 		$b = $b_open-$b_close+1;
											 		for ($i=0; $i < $b; $i++) { 
											 			echo '</b>';
											 		}
											 	}
											 ?>
										<?php	else: ?>
											<pre>
												<?php  
													$paragraphs = explode("\n", $data->Description);
													
													$paragraph = array_filter($paragraphs, function($value) {
													    return trim($value) !== '';
													});

													foreach ($paragraph as $key => $value) {
														echo '<p>'.$value.'</p>';
													}
													?>
											</pre>
										<?php endif; ?>
									</div>
								<?php endif; ?>
								<?php if(isset($data->Summary) && !empty($data->Summary)):?>

									<?php 
										if(strpos($data->Description, $data->Summary) === false  && $data->Summary != 'Accident & Emergency department'): 
									?>

										<p class="de_summary"><?= $data->Summary; ?></p>
									<?php endif; ?>


								<?php endif; ?>
								<?php if (isset($data->Service) && !empty($data->Service)): ?>
								   	<div class="editor beta push--bottom">
								    	<h2>Services Offered</h2>
								        <ul class="nhsuk-list nhsuk-list--bullet">
								        		<?php $serviceSubType = []; ?>
									            <?php foreach (@$data->Service as $service): ?>
									                 <?php if ($service->ServiceSubType->Text != 'None'): ?>
	                                                    <?php $serviceSubType[] = $service->ServiceSubType->Text ?>
	                                                <?php endif; ?>
									            <?php endforeach; ?>
									            <?php 
										            $_service = array_unique($serviceSubType); 
										            sort($_service);
									            ?>
									            <?php foreach ($_service as $service): ?>
									            	<li><?= $service;  ?></li>
									            <?php endforeach; ?>
									            
								        </ul>
									</div>
							      <?php endif; ?>
								<?php if (isset($data->AdditionalInformation) && !empty($data->AdditionalInformation)):?>
								   	<div class="editor beta push--bottom">
								   		<?php if (strpos($data->AdditionalInformation, "<li>") !== false): ?>
											<?= $data->AdditionalInformation ?>
										<?php	else: ?>
											<pre>
												<p>
												<?php  $paragraphs = explode("\n", $data->AdditionalInformation);
												foreach ($paragraphs as $key => $value): ?>
													<?= $value ?><br>
												<?php endforeach; ?>
												</p>
											</pre>
										<?php endif; ?>

								   	</div>
							   	<?php endif; ?>


							    <div class="row push--ends">

									
									<div class="col-sm-12 Opening_times">
										<h3>Opening times</h3>
									</div>
									<?php if (isset($data->Schedule->DailySchedule) && !empty($data->Schedule->DailySchedule)): ?>
									<div class="cf row">
										<div class="col-sm-12 col-md-6 delta">
											<h3 class="delta dark-grey-2 push-half--bottom">Normal opening times</h3>
											<div class="panel-times">
											<dl class="nhsuk-body-m">
											
												<?php foreach (@$data->Schedule->DailySchedule as $dailySchedule):
													$open = explode(":",$dailySchedule->Open);
													$open = $open[0].':'.$open[1];
													if($open=='00:00'){
														$open = 'closed';
													}
													$close = explode(":",$dailySchedule->Close);
													$close = $close[0].':'.$close[1];
													if($close=='00:00' || $close=='23:59'){
														$close = 'closed';
													}
													?>
													<dt>
														<?= @$dailySchedule->DayOfWeek; ?>
													</dt>
													<dd>
														<?php
														if($open=='closed' && $close=='closed'){
															if($url1=='hospital'){
																echo '24 hours';
															} elseif($dataset=='aes-and-minor-injuries-units'){
																echo '24 hours';
															}  else {
															echo 'Closed';
															}
														} else {
														echo $open.' - '.$close;
														 } ?>
													</dd>
												<?php endforeach; ?>
												</dl>
											</div>
										</div>
										<?php if (!empty($data->Schedule->SpecialSchedule)):?>
											 <div class="col small-12 medium-6 delta">
												<h3 class="delta dark-grey-2 push-half--bottom">
													Special opening times
												</h3>
												<div class="panel-times">
													<dl class="nhsuk-body-m">
														<dt><?= date("d/m/Y", strtotime($data->Schedule->SpecialSchedule[0]->Date)); ?></dt>
														<dd>Closed</dd>
													</dl>
												</div>
											</div>
										<?php endif; ?>
									</div>
							    <?php endif; ?>
								<?php if (isset($data->Schedule->ScheduleInformation) && !empty(@$data->Schedule->ScheduleInformation)): ?>
									<div class="col-sm-12 push--ends">
										<span class="gamma dark-grey-2">
											<pre><p>
												<?php  $paragraphs = explode("\n", $data->Schedule->ScheduleInformation);
												foreach ($paragraphs as $key => $value): ?>
													<?= $value ?><br>
												<?php endforeach; ?></p></pre>
										</span>
									</div>
								<?php endif; ?>
							        <div class="col-sm-12 push--ends">
							            <h3>
							                Contact details
							            </h3>
							            <div class="row">
							                <div class="col-sm-12 col-lg-6">
										<?php if (isset($data->Contact->Phone) && !empty($data->Contact->Phone)):?>
								                	<?php foreach ($data->Contact->Phone as $key => $value): ?>
										        <dl>
										            <dt class="nhsuk-body-m bold no-margin">
										                 <?=  @$value->Description ?>
										            </dt>
										            <dd class="nhsuk-body-m">
										                <?=  @$value->Number ?>
										            </dd>
										        </dl>
											         <?php endforeach; ?>
										         <?php endif; ?>
										       
										        <?php if (isset($data->Contact->EmailAddress) && !empty($data->Contact->EmailAddress)):?>
							                    <dl>
												    <dt class="nhsuk-body-m bold no-margin">
												        Email
												    </dt>
												        <dd class="nhsuk-body-m">
												        	<?php if (isset($data->Contact->EmailAddress) && !empty(@$data->Contact->EmailAddress)):?>

												            	<?php foreach (@$data->Contact->EmailAddress as $emailAddress): ?>
												            		<a class="wordbreak" href="mailto:<?= @$emailAddress; ?>">
												            		 <?= @$emailAddress; ?>
													            	</a>
												            	<?php endforeach; ?>	
												            <?php endif; ?>
												        </dd>
												</dl>
													<?php endif; ?>

							                    <dl>
							                    <?php if (isset($data->Contact->ExternalUrl->Uri) && !empty($data->Contact->ExternalUrl->Uri)):?>
										            <dt class="nhsuk-body-m bold no-margin">Website</dt>
											            <dd class="nhsuk-body-m">
											                <a href="<?=  @$data->Contact->ExternalUrl->Uri; ?>" class="external" target="_blank">
											                    Visit website
											                </a>
											            </dd>
											        </dl>
											    <?php endif; ?>
							              	</div>
							                <div class="col-sm-12 col-md-6 push--bottom">
												<h3 class="delta dark-grey-2">Address</h3>
										        <address class="beta dark-grey-3 push-half--bottom">
										            <?php  if (isset($data->Contact->Address1) && !empty($data->Contact->Address1)):?>
										            	<?= $data->Contact->Address1 ?><br>
										            <?php endif; ?>
										            <?php  if (isset($data->Contact->Address2) && !empty($data->Contact->Address2)):?>
										            	<?= $data->Contact->Address2 ?><br>
										            <?php endif; ?>
										            <?php  if (isset($data->Contact->Address3) && !empty($data->Contact->Address3)):?>
										            	<?= $data->Contact->Address3 ?><br>
										            <?php endif; ?>
										            <?php  if (isset($data->Contact->Town) && !empty($data->Contact->Town)):?>
										            	<?= $data->Contact->Town ?><br>
										            <?php endif; ?>
										            <?php  if (isset($data->Contact->County) && !empty($data->Contact->County)):?>
										            	<?= $data->Contact->County ?><br>
										            <?php endif; ?>
										            <?php  if (isset($data->Contact->Postcode) && !empty($data->Contact->Postcode)):?>
										            	<?= $data->Contact->Postcode ?>
										            <?php endif; ?>

										        </address>
											</div>

							            </div>
							        </div>
							        <div class="col-sm-12 push--ends">
							            <h3>Find us</h3>
							            <img src="https://maps.googleapis.com/maps/api/staticmap?center=<?= @$data->Location->lat ?>,<?= @$data->Location->lon ?>&amp;zoom=17&amp;size=800x480&amp;markers=color:blue%7C<?= @$data->Location->lat ?>,<?= @$data->Location->lon ?>&amp;key=AIzaSyBcxJ4JU_Ie4ePFv3yMAcBWSeRgS2xgpg0" alt="find us on the map">
							            <div class="push--top cf bg-light-grey-1 soft mt3">
							                <a href="http://www.google.co.uk/maps/place/<?= @$data->Location->lat ?>,<?= @$data->Location->lon ?>" class="btn btn--primary btn--icon pull-left">
							                    View map
							                    <span class="icon icon-angle-right"></span>
							                </a>
							            </div>
							        </div>
							        <?php if (isset($data->Accessibility[0]->Text) && !empty($data->Accessibility[0]->Text)): ?>
								        <div class="col small-12 push--ends">
								            <dl>
								                <dt class="nhsuk-body-m bold no-margin">
								                    Accessibility
								                </dt>
								                    <dd class="nhsuk-body-m">
								                       <?= $data->Accessibility[0]->Text;  ?>
								                    </dd>
								            </dl>
								        </div> 
								    <?php endif; ?>
							        <div class="col-12 push--ends" id="last-updated-date">
							         <?php $lp= explode('T',@$data->UpdatedDate); 
							           $date_explode = explode('-',$lp[0]);
							           $date =$date_explode[2].'/'.$date_explode[1].'/'.$date_explode[0];  
							         echo 'Last Updated: '.$date;
							       ?></div>


							            <div class="col-sm-12 push--ends" id="user-feedback-form" style="display: none;">


							            	<form  id="info_submit" class="form" enctype="multipart/form-data" method="post">

							            		<input name="__RequestVerificationToken" type="hidden" value="Cgo21mumvo2aQzQau8a5tuN4djGlbjFzYokQe0qLQNp_EjdDKSkuwLYj_QYaMUZLLoBvdIWZbya35vDU55W74nKfxDPNap83_UFSiyFz5e41">

												<h3 class="primary-color bold">Report this listing</h3>
												<br>
												<p>
												    Use this form to report a problem with this service or group.
												    <br>
												    For comments or complaints, use our <a href="/feedback">feedback form.</a>
												    <br>
												    If you're unwell or need medical advice, phone 111.
												</p>
												<br>
												<input id="ServiceId" name="ServiceId" type="hidden" value="3290 1glc1116">
												<input id="ServiceName" name="ServiceName" type="hidden" value="1 Smile Dental Clinic">
												<input id="ServicePostcode" name="ServicePostcode" type="hidden" value="G2 5AH">
												<div class="form-item">
												    <label class="required" for="Forename" aria-required="true">Forename</label>
												    <input class="text-box single-line" data-val="true" data-val-length="'Forename' must be between 1 and 35 characters." data-val-length-max="35" data-val-length-min="1" data-val-required="'Forename' should not be empty." id="Forename" name="Forename" placeholder="Maximum of 35 characters" type="text" value="">
												    <span class="field-validation-valid" data-valmsg-for="Forename" data-valmsg-replace="true"></span>
												</div>
												<div class="form-item">
												    <label class="required" for="Surname" aria-required="true">Surname</label>
												    <input class="text-box single-line" data-val="true" data-val-length="'Surname' must be between 1 and 35 characters." data-val-length-max="35" data-val-length-min="1" data-val-required="'Surname' should not be empty." id="Surname" name="Surname" placeholder="Maximum of 35 characters" type="text" value="">
												    <span class="field-validation-valid" data-valmsg-for="Surname" data-valmsg-replace="true"></span>
												</div>
												<div class="form-item">
												    <label class="required" for="EmailAddress" aria-required="true">Email</label>
												    <input class="text-box single-line" data-val="true" data-val-email="'Email' is not a valid email address." data-val-required="'Email' should not be empty." id="EmailAddress" name="EmailAddress" placeholder="e.g. you@example.com" type="email" value="">
												    <span class="field-validation-valid" data-valmsg-for="EmailAddress" data-valmsg-replace="true"></span>
												</div>
												<div class="form-item">
												    <label for="ContactReason">Reason for reporting this listing</label>
												    <select class="" data-val="true" data-val-required="'Contact Reason' must not be empty." id="ContactReason" name="ContactReason"><option selected="selected" value="0">Please Select...</option>
												<option value="1">I Can Not Find A Service</option>
												<option value="2">The Service Information Is Unclear</option>
												<option value="3">The Service Contact Information Is Incorrect</option>
												<option value="4">The Service No Longer Exists</option>
												<option value="5">The Service Does Not Operate In My Area</option>
												<option value="6">Other</option>
												</select>
												    <span class="field-validation-valid" data-valmsg-for="ContactReason" data-valmsg-replace="true"></span>
												</div>
												<div class="form-item">
												    <label class="" for="OtherComments">Other comments</label>
												    <textarea cols="20" data-val="true" data-val-length="'Other comments' must be between 0 and 3000 characters." data-val-length-max="3000" id="OtherComments" name="OtherComments" rows="2" style="width: 100%; height: 120px"></textarea>
												    <span class="field-validation-valid" data-valmsg-for="OtherComments" data-valmsg-replace="true"></span>
												</div>
												<div class="form-item visuallyhidden">
												    <label for="FeedbackNotes">Notes</label>
												    <textarea class="text-box multi-line" id="FeedbackNotes" name="FeedbackNotes" placeholder="Additional notes"></textarea>
												    <span class="field-validation-valid" data-valmsg-for="FeedbackNotes" data-valmsg-replace="true"></span>
												</div>		<div class="clearfix pull-right">
															<button class="btn btn--icon close_form" type="button" value="Cancel"  title="Click here to cancel submitting this form.">
																<span class="icon icon-cancel"></span>Cancel
															</button>
															<button class="btn btn--primary btn--icon" type="submit" value="Submit" >
																<span class="icon icon-angle-right"></span>Submit
															</button>
														</div>
											</form>

							            </div>
							    </div>
							</div> 
							<style type="text/css">
								.panel-times dd, .panel-times dt {
							    display: block;
							    float: left;
							    padding: 2px 0;
							    width: 50%;
							}
							</style>

						</div>
			        </div>
			    </div>
			    <div class="col-lg-3 col-sm-12 mb-4 ssdW-24">
							<?php 

							include(dirname(__FILE__) . "/sidebar_infome.php");

							$current_collection = json_encode(array('dataset'=>$data->Dataset->Value,'Id'=>$data->Id,'name'=>$data->Name));

							side_info_me($current_collection,$data->Id);
							?>
			    </div>
			
 		</div>
	</div>
</div>
<?php 
    get_footer();
?>
 
<script>
jQuery(document).ready(function($) {
    jQuery('#info_submit').on('submit', function(event) {
        var successMessage = $('#nsdFeedbackConfirmation');
 
        event.preventDefault();
        successMessage.show();
        $(this).hide();
        $(document).scrollTop(0);
        setTimeout(function() {
		    successMessage.hide();
		},5000);
        // jQuery.ajax({
        //     type: 'POST',
        //     url: $(this).attr('action'),
        //     data: formData,
        //     success: function(response) {
 
                
        //     }
        // });
    });

 
});

</script>

 
<script type="text/javascript">
	jQuery(document).ready(function() {

		jQuery(".form_btn").click(function(){
		  jQuery("#user-feedback-form").show();
		});
		jQuery(".close_form").click(function(){
		  $("html, body").animate({ scrollTop: 0 }, "slow");
		  jQuery("#user-feedback-form").hide();
		});
	});
</script>


<style type="text/css">
	#user-feedback-form textarea{
		border: 1px solid #ccc;
	    background: #f6f9f7;
	    padding: 12px;
	    width: 100%;
	    height: 120px;
	    resize: vertical;
	}
	#user-feedback-form input{
		border: 1px solid #ccc;
	    background: #f6f9f7;
	    padding: 12px;
	    width: 100%;
	    box-sizing: border-box;
	}
	#user-feedback-form select{
		-webkit-appearance: none;
	    -moz-appearance: none;
	    border: 1px solid #ccc;
	    background: #f6f9f7;
	    padding: 12px;
	    width: 100%;
	    height: 50px;
    background-image: url(data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjMDAwMDAwIiBoZWlnaHQ9IjE4IiB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIxOCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxwYXRoIGQ9Ik03IDEwbDUgNSA1LTV6Ii8+CiAgICA8cGF0aCBkPSJNMCAwaDI0djI0SDB6IiBmaWxsPSJub25lIi8+Cjwvc3ZnPg==);
    background-repeat: no-repeat;
    background-position: 98% center;
	}
	.clearfix.pull-right p {
    display: flex;
}
.ssd-servive-detail.\33 ff5cc0062a24006bb8f5c45ddc6f99a\%201 .Opening_times {
    display: none;
}
.ssd-servive-detail.\39 289\%201glc1116 .editor.beta.push--bottom h2 ,
.ssd-servive-detail.\39 311\%201arb1116 p.de_summary {
    display: none;
}
</style>
	<?php else: ?>

		<?php 
			status_header( 404 );
            nocache_headers();
            include( get_404_template() );
            exit;
		?>
	<?php endif; ?>
<?php endif; ?>
