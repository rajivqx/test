
<?php 
/* 
Template Name: info for me page
*/
get_header(); 


function ssd_style3(){
    wp_enqueue_style('ssd',get_template_directory_uri().'/assets/css/ssds.css',array(), _S_VERSION);
    }
add_action('wp_enqueue_scripts', 'ssd_style3');
?>


<div class="row">
    <div class="col-sm-11 m-auto">
    <?php get_sidebar('breadcrumb');?>
    </div>
    <div class="col-lg-11 col-sm-12 mb-4 panel-content m-auto ssd-infofor-me" id="print_doc">
        <div class="row">
            <div class="col col-sm-12 large-10 soft-double--bottom">
                <h1 class="giga bold primary-color push--bottom service_title">
                     Info for Me
                </h1>
                <div class="print-only pdf_header" style="display:none;">
                    <div class="logo-left" style="display: inline-block;float: left;width:10px;">
                        <img style="width:10px;" src="<?php echo  get_template_directory_uri(); ?>/assets/images/info-for-me--full.png" alt="Info For Me">
                    </div>
                    <div class="logo-right" style="display: inline-block;float: right;">
                        <img style="width:10px;" src="<?php echo  get_template_directory_uri(); ?>/assets/images/nhs-inform-logo.png" alt="NHS Inform">
                    </div>
                </div>

                <div class="editor">
                    <p><span>Info for Me helps you to create your own personalised leaflet with the health and social care information you select. You can then save, print or share this leaflet with others.</span></p>
                    <p>This tool&nbsp;was developed in partnership with Macmillan Cancer Support.</p>
                </div>


                <?php if (isset($_COOKIE['service_tab'])): ?>
                    <?php 
                        $service_tab = $_COOKIE['service_tab'];
                        $service_tab = json_decode($service_tab);
                        if ($service_tab == 1):
                    ?>
                        <?php include(dirname(__FILE__) . "/info_tab1.php"); ?>

                <?php endif; ?>
                <?php endif; ?>



                <?php if (isset($_COOKIE['service_tab'])): ?>
                    <?php 
                        $service_tab = $_COOKIE['service_tab'];
                        $service_tab = json_decode($service_tab);
                        if ($service_tab == 2):
                            include(dirname(__FILE__) . "/info_tab2.php");
                    ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


 
<?php
    get_footer();
?>
 
<style type="text/css">
    #ifmCart {
        background: #eee;
        padding: 12px;
        list-style: none;
        margin: 24px 0;
    }
    #ifmCart li {
        padding: 12px;
        background: #fff;
        margin-bottom: 12px;
        position: relative;
        display: flex;
        justify-content: space-between;
    } 
    .ifmCartItem button {
        border: 0;
        padding: 0 15px;
        color: #515050;
    }
    div#ifmButtonWrapper {
        display: flex;
        justify-content: space-between;
    }
    .ifmBtn {
        border: 0;
        background: #dcedf4;
        color: #515050 !important;
        padding: 12px 24px;
        display: inline-block;
        cursor: pointer;
    }
</style>


