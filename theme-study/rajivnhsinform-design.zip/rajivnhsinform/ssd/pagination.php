<ul class="pagination__list">
    <?php $i=1; ?>

    <?php 

        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
        $actual = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
        $actual = trim($actual_link,"?sortby=_distance&sortdir=Asc"); 


        if (isset($_GET['locpt'])) {

            $actual_link1 =  explode("&",$actual);

            $rm = [];
            foreach ($actual_link1 as $key => $value) {
                 if(strpos($value, 'page') !== false){
                    $rm[] = $value;
                 }
            }
            $actual_link = str_replace($rm[0],"",$actual); 

            if (strpos($actual_link, 'q&') !== false) {

               $actual_link = str_replace('q&',"q",$actual_link); 
                  
            }
        }else{

             if(strpos($actual_link, '?') !== false){
                $actual_link2 =  explode("?",$actual)[1];
                $actual_link3 =  explode("&",$actual_link2);

                $rm = [];
                foreach ($actual_link3 as $key => $value) {
                     if(strpos($value, 'page') !== false){
                        $rm[] = $value;
                     }
                }

                if(strpos($actual_link, '?') !== false){

                    if(strpos($actual_link, 'page') !== false){
                        $actual_link = str_replace('?'.$rm[0],"",$actual); 
                    }else{
                        $actual_link = str_replace('&'.$rm[0],"",$actual);
                    }

                    if(strpos($actual_link, '&') !== false){
                        $actual_link = str_replace('&'.$rm[0],"",$actual);
                    }

                }else{
                    $actual_link = str_replace('?'.$rm[0],"",$actual);
                }
            }

        }


    ?>
    <?php if (isset($_GET['page'])): ?>
        <?php if ($_GET['page'] > 6): ?>
            <li class="pagination__item">
                <?php if(strpos($actual_link, '?') !== false): ?>
                    <a href="<?= $actual_link; ?>" class="pagination__link">
                <?php else: ?>
                    <a href="<?= $actual_link; ?>" class="pagination__link">
                <?php endif; ?>
                    «
                </a>
            </li>
        <?php else:  ?>
        <?php endif;  ?>
    <?php endif ?>


    <?php if ($collectionJsone->Pagination->Pages > 1): ?>
        <?php while ($i <= $collectionJsone->Pagination->Pages){?>
            <?php 
                if(@$_GET['page']==$i){
                    $active = 'active';
                } else {
                    $active = '';
                }
            ?>
            <?php if (empty($_GET['page'])): ?>

                <?php if ($i < 7): ?>
                    <li class="pagination__item">
                        <?php if(strpos($actual_link, '?') !== false): ?>
                            <a class="pagination__link <?php echo $active;?>" href="<?= $actual_link; ?>&page=<?= $i; ?>">
                        <?php else: ?>
                            <a class="pagination__link <?php if ($i == 1){ echo "active"; } ?>" href="<?= $actual_link; ?>?page=<?= $i; ?>&sortby=_distance&sortdir=Asc">
                        <?php endif; ?>
                            <?= $i; ?>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="pagination__item">
                        <?php if(strpos($actual_link, '?') !== false): ?>
                            <a href="<?= $actual_link; ?>&page=<?= $collectionJsone->Pagination->Pages ?>" class="pagination__link">
                         <?php else: ?>
                            <a href="<?= $actual_link; ?>?page=<?= $collectionJsone->Pagination->Pages ?>&sortby=_distance&sortdir=Asc" class="pagination__link">
                        <?php endif; ?>
                            »
                        </a>
                    </li>
                    <?php break; ?>
                <?php endif; ?>

            <?php else: ?>
                    <?php 
                        $page = $_GET['page'];

                        if ($page > 1) {
                            if ($i >= $page-5 && $i <= $page+5): ?>
                                <li class="pagination__item">
                                    <?php if(strpos($actual_link, '?') !== false): ?>
                                        <a class="pagination__link <?php echo $active;?> " href="<?= $actual_link; ?>&page=<?= $i; ?>">
                                    <?php else: ?>
                                        <a class="pagination__link <?php echo $active;?> " href="<?= $actual_link; ?>?page=<?= $i; ?>&sortby=_distance&sortdir=Asc">
                                    <?php endif; ?>
                                        <?= $i; ?>
                                    </a>
                                </li>
                            <?php endif;
                        }else{ ?>
                            <?php if ($i < 7): ?> 


                                <li class="pagination__item">
                                    <?php if(strpos($actual_link, '?') !== false): ?>
                                        <a class="pagination__link <?php echo $active;?>" href="<?= $actual_link; ?>&page=<?= $i; ?>">
                                    <?php else: ?>
                                        <a class="pagination__link <?php echo $active;?>" href="<?= $actual_link; ?>?page=<?= $i; ?>&sortby=_distance&sortdir=Asc">
                                    <?php endif; ?>
                                        <?= $i; ?>
                                    </a>
                                </li>

                            <?php endif; ?>
                        <?php }
                    ?>  

            <?php endif; ?>
            <?php $i++; ?>
        <?php } ?>
    <?php endif;  ?> 
    <?php if (isset($_GET['page'])): ?>
        <?php if ($_GET['page'] < $collectionJsone->Pagination->Pages-5): ?>
            <li class="pagination__item">
                <?php if(strpos($actual_link, '?') !== false): ?>
                    <a href="<?= $actual_link; ?>&page=<?= $collectionJsone->Pagination->Pages ?>" class="pagination__link">
                <?php else: ?>
                    <a href="<?= $actual_link; ?>?page=<?= $collectionJsone->Pagination->Pages ?>&sortby=_distance&sortdir=Asc" class="pagination__link">
                <?php endif; ?>
                    »
                </a>
            </li>
        <?php endif;  ?>
    <?php endif;  ?>
</ul>


<style type="text/css">
    .pagination__link:hover:after {
        background-color: #03759b;
        content: '';
        height: 2px;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
    }
    a.pagination__link:hover {
        color: #03759b!important;
        font-weight: 700;
    }
</style>