function searchToggle() {
  $('.mobile_search').on('click', function () {
    $('.mobile_search_detail').toggle();
    $(this).siblings('.navbar-collapse').removeClass('show');
  });

  $('.navbar-toggler').on('click', function () {
    $(this).parents('header').siblings('.mobile_search_detail').hide();
  });
}

function list_scroll() {
  console.log("testing");
  $('.list_a').on('click', function () {
    $('html, body').animate({ scrollTop: $('.a_detail').offset().top }, 100);
  });
  $('.list_b').on('click', function () {
    $('html, body').animate({ scrollTop: $('.b_detail').offset().top }, 100);
  });
  $('.list_c').on('click', function () {
    $('html, body').animate({ scrollTop: $('.c_detail').offset().top }, 100);
  });
  $('.list_d').on('click', function () {
    $('html, body').animate({ scrollTop: $('.d_detail').offset().top }, 100);
  });
  $('.list_e').on('click', function () {
    $('html, body').animate({ scrollTop: $('.e_detail').offset().top }, 100);
  });
  $('.list_f').on('click', function () {
    $('html, body').animate({ scrollTop: $('.f_detail').offset().top }, 100);
  });
  $('.list_g').on('click', function () {
    $('html, body').animate({ scrollTop: $('.g_detail').offset().top }, 100);
  });
  $('.list_h').on('click', function () {
    $('html, body').animate({ scrollTop: $('.h_detail').offset().top }, 100);
  });
  $('.list_i').on('click', function () {
    $('html, body').animate({ scrollTop: $('.i_detail').offset().top }, 100);
  });
  $('.list_j').on('click', function () {
    $('html, body').animate({ scrollTop: $('.j_detail').offset().top }, 100);
  });
  $('.list_k').on('click', function () {
    $('html, body').animate({ scrollTop: $('.k_detail').offset().top }, 100);
  });
  $('.list_l').on('click', function () {
    $('html, body').animate({ scrollTop: $('.l_detail').offset().top }, 100);
  });
  $('.list_m').on('click', function () {
    $('html, body').animate({ scrollTop: $('.m_detail').offset().top }, 100);
  });
  $('.list_n').on('click', function () {
    $('html, body').animate({ scrollTop: $('.n_detail').offset().top }, 100);
  });
  $('.list_o').on('click', function () {
    $('html, body').animate({ scrollTop: $('.o_detail').offset().top }, 100);
  });
  $('.list_p').on('click', function () {
    $('html, body').animate({ scrollTop: $('.p_detail').offset().top }, 100);
  });
  $('.list_q').on('click', function () {
    $('html, body').animate({ scrollTop: $('.q_detail').offset().top }, 100);
  });
  $('.list_r').on('click', function () {
    $('html, body').animate({ scrollTop: $('.r_detail').offset().top }, 100);
  });
  $('.list_s').on('click', function () {
    $('html, body').animate({ scrollTop: $('.s_detail').offset().top }, 100);
  });
  $('.list_t').on('click', function () {
    $('html, body').animate({ scrollTop: $('.t_detail').offset().top }, 100);
  });
  $('.list_u').on('click', function () {
    $('html, body').animate({ scrollTop: $('.u_detail').offset().top }, 100);
  });
  $('.list_v').on('click', function () {
    $('html, body').animate({ scrollTop: $('.v_detail').offset().top }, 100);
  });
  $('.list_w').on('click', function () {
    $('html, body').animate({ scrollTop: $('.w_detail').offset().top }, 100);
  });
  $('.list_x').on('click', function () {
    $('html, body').animate({ scrollTop: $('.x_detail').offset().top }, 100);
  });
  $('.list_y').on('click', function () {
    $('html, body').animate({ scrollTop: $('.y_detail').offset().top }, 100);
  });
  $('.list_z').on('click', function () {
    $('html, body').animate({ scrollTop: $('.z_detail').offset().top }, 100);
  });

  $('.back_top_button').on('click', function () {
    $('html, body').animate({ scrollTop: $('body').offset().top }, 100);
  });
}

function show_nav_list() {
  
  $('.plusminus_btn').on('click', function() {
        $('.default_hide').toggleClass('default_show');
        $(this).children('i').toggleClass('fa-minus');
    });

  $('.mental_parent .plusminus_btn').on('click', function () {
    ///alert('kk');
    var parentId = $(this).parent('.nav-item').attr('id');
    var idno = parentId.split('_');
    var childDynamicId = idno[2];
    $(this)
      .parent('.nav-item')
      .siblings('#nav_child_' + childDynamicId)
      .toggleClass('default_show');
  });

  $('.default_hide .nav-item').on('click', function () {
    if ($(this).siblings().children('.nav-link').hasClass('active')) {
      $(this).siblings().children('.nav-link').removeClass('active');
    }
  });

  $('.navigate_part .nav-item').on('click', function () {
    if ($(this).siblings().find('.nav-link').hasClass('active')) {
      $(this).siblings().find('.nav-link').removeClass('active');
    }
  });

  $('.toggler').on('click', function () {
    if ($(this).siblings().find('.nav-link').hasClass('active')) {
      $(this).siblings().find('.nav-link').removeClass('active');
    }
  });
}

function nav_btn_toggle() {
  $('.navigate_btn').on('click', function () {
    $('.navigate_container .navigate_part .nav-tabs').toggleClass('show');
    $(this).find('i').toggleClass('fa-minus');
  });
}

function navScrollTop() {
  $('.navigate_container .navigate_part .nav-item .nav-link').each(function () {
    $(this).click(function () {
      if ($(window).width() > 767) {
        $('html, body').animate(
          {
            scrollTop: $('header').offset().top,
          },
          100
        );
      } else {
        $('html, body').animate(
          {
            scrollTop: $('.detail_container').offset().top,
          },
          100
        );
      }
    });
  });
}

function RHamburgerClick() {
  $('.hamburger_icon').on('click', function () {
    $('.microsite_overlay').css('display', 'block');
    $('body').css('overflow', 'hidden');
    $('.microsite_navigation').css('display', 'block');
  });

  $('.microsite_overlay').on('click', function () {
    $(this).hide();
    $('body').css('overflow', 'auto');
    $('.microsite_navigation').css('display', 'none');
  });

  $('.close_micro').on('click', function () {
    $(this).parents('.microsite_navigation').hide();
    $(this)
      .parents('.microsite_navigation')
      .siblings('.microsite_overlay')
      .hide();
    $('body').css('overflow', 'auto');
  });

  $('.micro_nav_slide_ready').on('click', function () {
    //var singleClone = $(this).siblings('.micro_nav_slide_list');
    var singleClone = $(this).siblings('.sub-menu');
    //console.log(singleClone);
    var copiedData = singleClone.clone();
    //alert(copiedData);
    copiedData.appendTo('.micro_nav_slide_list_container');
    $(this)
      .parents('.microsite_nav_list')
      .siblings('.micro_nav_slide_list_container')
      .css({ right: '0px' });
  });

  $('.micro_nav_slide_list_back').on('click', function () {
    $(this)
      .siblings('.sub-menu')
      .delay(700)
      .queue(function () {
        $(this).remove();
      });

    $(this).parents('.micro_nav_slide_list_container').css({ right: '-800px' });
  });
}

function Prev_btn() {
  $('.prev_btn').on('click', function () {
    if ($(window).width() > 767) {
      $('html, body').animate(
        {
          scrollTop: $('header').offset().top,
        },
        100
      );
    } else {
      $('html, body').animate(
        {
          scrollTop: $('.detail_container').offset().top,
        },
        100
      );
    }

    $(this).parents('.tab-pane').removeClass('active show');
    $(this).parents('.tab-pane').prev('.tab-pane').addClass('active show');
  });
}

function Next_btn() {
  $('.next_btn').on('click', function () {
    if ($(window).width() > 767) {
      $('html, body').animate(
        {
          scrollTop: $('header').offset().top,
        },
        100
      );
    } else {
      $('html, body').animate(
        {
          scrollTop: $('.detail_container').offset().top,
        },
        100
      );
    }

    $(this).parents('.tab-pane').removeClass('active show');
    $(this).parents('.tab-pane').next('.tab-pane').addClass('active show');
  });
}

function Prev_Next() {
  $('.next_btn').each(function () {
    $(this).on('click', function () {
      var nextBtnId = $(this).parents('.tab-pane').attr('id');
      var idArray = nextBtnId.split('_');
      var addDynamicId = '#Tab' + idArray[1];

      $(addDynamicId).removeClass('active');
      $(addDynamicId)
        .parent('.nav-item')
        .next('.nav-item')
        .children('.nav-link')
        .addClass('active');
    });
  });

  $('.prev_btn').each(function () {
    $(this).on('click', function () {
      var nextBtnId = $(this).parents('.tab-pane').attr('id');
      var idArray = nextBtnId.split('_');
      var addDynamicId = '#Tab' + idArray[1];

      $(addDynamicId).removeClass('active');
      $(addDynamicId)
        .parent('.nav-item')
        .prev('.nav-item')
        .children('.nav-link')
        .addClass('active');
    });
  });
}

function formQuestion() {
  $('.graph_view textarea').blur(function () {
    var textAreaValue = $(this).val();
    var textAreaId = $(this).attr('id');
    var IdArray = textAreaId.split('_');
    var prependId = '#graphicQuestion' + IdArray[1];

    $(prependId).prepend(textAreaValue);
  });

  $('.fill_act_response textarea').blur(function () {
    var TabId = $(this).parents('.tab-pane').attr('id');
    //alert(TabId);
    var TabidArray = TabId.split('_');
    var cur_tabNo = TabidArray[1];
    var nextTab_no = parseInt(cur_tabNo) + parseInt(1);
    var textAreaValue = $(this).val();
    var textAreaId = $(this).attr('id');
    var IdArray = textAreaId.split('_');
    var prependId = '#Tab_' + nextTab_no + ' #actResp_' + IdArray[1];
    $(prependId).text(textAreaValue);
  });
}

$(document).ready(function () {
  searchToggle();
  list_scroll();
  show_nav_list();
  nav_btn_toggle();
  navScrollTop();
  RHamburgerClick();
  Prev_btn();
  Next_btn();
  Prev_Next();
  formQuestion();
});