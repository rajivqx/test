<?php
/**
 * The template for displaying archive-illnesses pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nhsinform
 */
get_header();?>
<!-- Mobile Search HTML Start -->
<form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

   <!-- Breadcrumb HTML Start -->
   <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->
    <!-- Pannel Intro Section HTML Start -->
    <?php
      $td = get_queried_object();
    ?>

    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                       <?php if(have_posts()):?>
						<?php
						    //post_type_archive_title('',false);
							the_archive_title( '<h1>', '</h1>');
							the_archive_description( '<p>', '</p>');
						else :
							get_template_part( 'template-parts/content', 'none' );
						endif;?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->
    <?php 

            $term       = get_queried_object(); 
            $getSlug    = $term->slug;
            if($getSlug == "mental-wellbeing") {
                get_template_part( 'template-parts/healthy', 'mental-wellbeing' );?>
            <?php } else if($getSlug == "stopping-smoking") { ?>
                <?php get_template_part( 'template-parts/healthy', 'stopping-smoking' );?>
            <?php } else if($getSlug == "immunisation") { ?>
                <?php get_template_part( 'template-parts/healthy', 'immunisation' );?>
            <?php } else { 
             get_template_part( 'template-parts/healthy', 'default' ); 
             } ?>
<script>
    jQuery(document).ready(function () {

        //$('<li class="breadcrumb-item"><a href="/translations/" class="nhsuk-breadcrumb__link">Translations</a></li>').insertAfter($('ol.breadcrumb li:eq(0)'));

                    var lspan = $('#breadcrumbs span span').children().length; 
                    if(lspan===2){
                        $("#breadcrumbs span span:first-child").remove();
                       // $("#breadcrumbs span span").children().eq(0).hide();
                       $("#breadcrumbs span span:eq(0)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                       }
                       if(lspan===3){
                        $("#breadcrumbs span span:first-child").remove();
                        $("#breadcrumbs span span").children().eq(0).hide();
                        $("#breadcrumbs span span:eq(1)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                       }
    });
</script>
<style>
@media(max-width: 767px) {
    .pannel_module h3 {
    font-size: 18px;
    }
    .gutt {
     width: 92% !important; 
    margin-left: 4% !important;
}
#dropList {
	 width: 100%;
}

#yost_custom {
	display:none;
}
.breadcrumb {
	height:50px;
}
#breadcrumbs {
	display:block !important;
}
#breadcrumbs .laste:before {
    background: url("data:image/svg+xml,%3Csvg class='nhsuk-icon nhsuk-icon__chevron-left' xmlns='http://www.w3.org/2000/svg' fill='%23005eb8' height='24' width='24' viewBox='8 0 24 24' aria-hidden='true'%3E%3Cpath d='M8.5 12c0-.3.1-.5.3-.7l5-5c.4-.4 1-.4 1.4 0s.4 1 0 1.4L10.9 12l4.3 4.3c.4.4.4 1 0 1.4s-1 .4-1.4 0l-5-5c-.2-.2-.3-.4-.3-.7z'%3E%3C/path%3E%3C/svg%3E") no-repeat;
    content: '';
    display: flex;
    height: 18px;
    left: 0;
    position: relative;
    top: 0;
    width: 10px;
}
.laste {
    position: relative;
    right: 0px;
    top: 5px;
}
#breadcrumbs {
padding: 3px;
position: relative;
top: 3px;
margin-bottom: 0px;
}
#breadcrumbs .laste a {
    position: relative;
    padding-left: 16px;
    bottom: 18px;
    color: #03759b !important;
    font-size: 14px;
}
}
</style>
<?php get_footer();
