<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();?>
    <!-- Symptoms Section HTML Start -->
    <div class="bg-white-grey soft--bottom healthyliving">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                      <!-- Breadcrumb HTML Start -->
                        <?php get_sidebar('breadcrumb');?>
                        <!-- Breadcrumb HTML End -->
                </div>
                <div class="col-lg-9 col-sm-12 mb-4 panel-content guidetabs healthyliving">
                    <!-- <div class="wrapperNHS panel-content push--bottom push--top"> -->
                    <div class="row">
                        <div class="col col-sm-12">
                            <h1 class="giga bold primary-color push--bottom">
                                <?php the_title();?>
                            </h1>
                        </div>

    <div class="col-sm-12">
      <?php 

       
        while(have_posts()): the_post();?>
            <?php the_content(); 
                if(comments_open() || get_comments_number()) :
        			//comments_template();
        		endif;?>
        <?php endwhile;?>

            <div class="jsPrevNextContainer js-guide__incremental page-navigation no-print">
            <a href="javascript:void(0)" rel="previous" class="js-guide__incremental--previous nav-incremental-link page-navigation__prev" id="previous_page" style="display:block;"
             onclick="nextPreButton('pre');"> 
                <div class="nav-incremental__part" id="prePart"></div>
                <div class="nav-incremental__title" id="prePartText"></div>
            </a>

            <a href="javascript:void(0)" rel="next" class="js-guide__incremental--previous nav-incremental-link page-navigation__next" id="next_page" style="display:block;" onclick="nextPreButton('next');">
              <i class="fa fa-chevron-right" aria-hidden="true"></i>
                <div class="nav-incremental__part" id="nextPart"></div>
                <div class="nav-incremental__title" id="nextPartText"></div>
            </a>

          </div>
    </div>

    <div class="col-sm-12 col-lg-9 soft--ends healthyliving">

    <?php if(get_field('attribution_logo')):
        $attribution_logo = get_field('attribution_logo'); 
        $imageID  = attachment_url_to_postid($attribution_logo);
        $imageData = wp_get_attachment($imageID);
    ?>
    <div class="row">
        <div class="col-sm-12 soft bg-light-grey-1">
             <img src="<?php echo $attribution_logo;?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
             <?php if(get_field('attributed_to') && get_field('attributed_url')):?>
                 <p class="nhsuk-body-s no-margin">
                    Source:
                     <a href="<?php echo get_field('attributed_url');?>" class="bold" rel="external" target="_blank"><?php the_field('attributed_to');?> <span class="visuallyhidden">- Opens in new browser window</span></a>
                </p>
             <?php endif;?>
        </div>
    </div>
    <?php endif;?>

    <div class="push--ends healthyliving">
        <p class="nhsuk-body-s nhsuk-u-secondary-text-color no-margin">
            Last updated:
            <br>
            <?php  the_modified_date('d F Y'); ?>
        </p>
    </div>
        <?php get_sidebar('breadcrumb-bottom');?>
            <?php
                if(@get_field('feedback_disabled')[0] !="yes"){
                        get_sidebar('feedback-form-transalation');
                }
            ?>
      </div>
    </div>
    </div>
    <div class="col-lg-3 col-sm-12 mb-4">
         <?php get_sidebar();?>
    </div>
      </div>
    
    </div>
    </div>
<script>
        jQuery(document).ready(function () {

                           var lspan = $('#breadcrumbs span span').children().length; 
                       if(lspan===5){
                        $("#breadcrumbs span span:first-child").remove();
                        $("#breadcrumbs span span").children().eq(0).hide();
                        $("#breadcrumbs span span").children().eq(1).hide();
                        $("#breadcrumbs span span").children().eq(2).hide();
                        $("#breadcrumbs span span:eq(3)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                        //var href = $("#breadcrumbs span span:last-child a[href]").attr('href');
                        //var result1 = href.replace("falls_type", "falls-assessment");
                        //$("#breadcrumbs a[href]").attr("href", result1);
                        //alert(href);
                       }
                       if(lspan===4){
                        $("#breadcrumbs span span:first-child").remove();
                        $("#breadcrumbs span span").children().eq(0).hide();
                        $("#breadcrumbs span span").children().eq(1).hide();
                        //$("#breadcrumbs span span").children().eq(2).hide();
                        $("#breadcrumbs span span:eq(2)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                        //var href = $("#breadcrumbs span span:last-child a[href]").attr('href');
                        //var result1 = href.replace("falls_type", "falls-assessment");
                        //$("#breadcrumbs a[href]").attr("href", result1);
                        //alert(href);
                       }                      
                    });
         
                    function myFunction() {
                    const elementDropList = document.getElementById('dropList');

                    const attrs = elementDropList.getAttributeNames().reduce((acc, name) => {
                    return {...acc, [name]: elementDropList.getAttribute(name)};
                    }, {}); 
                    if(attrs['aria-expanded']==='false') {
                        elementDropList.setAttribute( "aria-expanded", true ) 
                    }
                    else {
                        elementDropList.setAttribute( "aria-expanded", false ) 
                    }

                    var elementFeedBack = document.getElementById("feedback");
                    elementFeedBack.classList.toggle("mystyle");
                    }

</script>
<style>
#breadcrumbs span span span span:before{
    background: url("data:image/svg+xml,%3Csvg class='nhsuk-icon nhsuk-icon__chevron-left' xmlns='http://www.w3.org/2000/svg' fill='%23005eb8' height='24' width='24' viewBox='8 0 24 24' aria-hidden='true'%3E%3Cpath d='M8.5 12c0-.3.1-.5.3-.7l5-5c.4-.4 1-.4 1.4 0s.4 1 0 1.4L10.9 12l4.3 4.3c.4.4.4 1 0 1.4s-1 .4-1.4 0l-5-5c-.2-.2-.3-.4-.3-.7z'%3E%3C/path%3E%3C/svg%3E") no-repeat;
    content: '';
    display: flex;
    height: 18px;
    left: 0;
    position: relative;
    top: 0;
    width: 10px;
    }
.mystyle {
    display:none;
    color:blue;
}
.form label.required:after { 
    content: " *";
 color: #a10000;
}
.error{
   color: #a10000 !important;
}
.gutt {
width: 46%;
margin: 2%;
}
.js-toggle {
    display: block;
}
#dropList {
    background-color: #f6f9f7;
    padding: 12px;
    width: 50%;
    text-align: left;
    color: #03759b;
}
</style>
<?php

    get_footer();
    get_sidebar('feedback_js');
    get_sidebar('tab-pagination_js');
?>