<div class="microsite_overlay"></div>
<div class="microsite_navigation week_navigation">
    <h3>Menu <button class="close_micro"><i class="fa-solid fa-xmark"></i></button></h3>
    <nav class="microsite_nav_list">
        <ul>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme'); ?>">12 Week Weight Management Programme</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/about-this-programme'); ?>about-this-programme">About this programme</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-1'); ?>">Week 1</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-2'); ?>">Week 2</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-3'); ?>">Week 3</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-4'); ?>">Week 4</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-5'); ?>">Week 5</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-6'); ?>">Week 6</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-7'); ?>">Week 7</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-8'); ?>">Week 8</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-9'); ?>">Week 9</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-10'); ?>">Week 10</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-11'); ?>">Week 11</a></li>
            <li><a href="<?= home_url('healthy-living/12-week-weight-management-programme/week-12'); ?>">Week 12</a></li>
        </ul>
    </nav>
    <div class="micro_nav_slide_list_container">
        <span class="micro_nav_slide_list_back">Back</span>
    </div>
</div>