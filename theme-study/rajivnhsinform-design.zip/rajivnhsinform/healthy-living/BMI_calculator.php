<div class="pannel_wrapper_container right_container space_zero">
    <div class="accordion bmi_calculator" id="accordionExample">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne"><span class="btn_text">Calculate your BMI</span></button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <div class="week_form">
                            <form class="form no-margin">
                                <div id="bmi-form">
                                    <p>The BMI scale uses your weight and height to calculate roughly how much body fat you have.</p>
                                    <div class="row mb-2">
                                        <div class="col-5"><h3>Height</h3></div>
                                        <div class="col-7 text-end"><a href="#" class="height_swapper">CM</a></div>
                                    </div>
                                    <div class="week_form_row">
                                        <div class="bmi_height_ft height_show">
                                            <div class="row">
                                                <div class="col-6">
                                                    <label for="feet" class="form-label">Feet</label>
                                                    <input type="number" class="form-control" id="wgt-ft" min="0">
                                                </div>
                                                <div class="col-6">
                                                    <label for="Inches" class="form-label">Inches</label>
                                                    <input type="number" class="form-control" id="wgt-in" min="0">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="bmi_height_cm">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label for="Centimeters" class="form-label">Centimeters</label>
                                                    <input type="number" class="form-control" id="Centimeters" min="0">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-5"><h3>Weight</h3></div>
                                        <div class="col-7 text-end"><a href="#" class="weight_swapper">KG</a></div>
                                    </div>
                                    <div class="week_form_row">
                                        <div class="bmi_weight_lbs weight_show">
                                            <div class="row">
                                                <div class="col-6">
                                                    <label for="feet" class="form-label">Stone</label>
                                                    <input type="number" class="form-control" id="wgt-st" min="0" max="99">
                                                </div>
                                                <div class="col-6">
                                                    <label for="Inches" class="form-label">Pounds</label>
                                                    <input type="number" class="form-control" id="wgt-po" min="0" max="13">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="bmi_weight_kg">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label for="Centimeters" class="form-label">Kilograms</label>
                                                    <input type="number" class="form-control" id="wgt-kg" min="6" max="635">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-12"><h3>Ethnic group</h3></div>
                                    </div>
                                    <div class="week_form_row">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="row">
                                                    <div class="col-5">
                                                        <label for="Ethnicity" class="form-label">Ethnicity</label>
                                                    </div>
                                                    <div class="col-7 text-end">
                                                        <a href="#" class="ask_question">Why are we asking?</a>
                                                    </div>
                                                </div>
                                                <div class="ask_quesAnswer">
                                                    <p>Black, Asian and other ethnic minority groups with a BMI of 23 or more have a higher risk of developing type 2 diabetes and other long term illnesses</p>
                                                </div>
                                                <select class="form-select" id="Ethnicity">
                                                    <option>Please Select</option>
                                                    <option value="White">White</option>
                                                    <option value="Black Caribbean">Black Caribbean</option>
                                                    <option value="Black African">Black African</option>
                                                    <option value="Indian">Indian</option>
                                                    <option value="Pakistani">Pakistani</option>
                                                    <option value="Bangladeshi">Bangladeshi</option>
                                                    <option value="Chinese">Chinese</option>
                                                    <option value="Middle Eastern">Middle Eastern</option>
                                                    <option value="Mixed">Mixed</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-12"><h3>Age</h3></div>
                                    </div>
                                    <div class="week_form_row">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="age">
                                            <label class="form-check-label" for="age">
                                                Are you over the age of 18?
                                            </label>
                                        </div>
                                    </div>

                                    <div id="bmi-error"></div>
                                </div>
                                <div id="bmi-resultcontainer" class="hide">
                                    <div class="bmi-resultcontainers">
                                        <div id="bmi-result" class="push--bottom"></div>
                                        <div id="bmi-result-message" class="push--bottom"></div>
                                    </div>
                                    <div class="row">
                                            <div class="col small-12">
                                                <div class="nhsuk-action-link">
                                                    <a class="nhsuk-action-link__link" target="_blank" title="Find out more about BMI" href="/healthy-living/food-and-nutrition/healthy-eating-and-weight-loss/body-mass-index-bmi/">
                                                        <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                                                            <path d="M0 0h24v24H0z" fill="none"></path>
                                                            <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
                                                        </svg>
                                                        <span class="nhsuk-action-link__text">
                                                            What is BMI? <span class="visuallyhidden">- opens in a new window</span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        <div class="col small-12">
                                            <p class="push--bottom">
                                                <button id="bmi-startover" class="btn btn--primary btn--block btn--icon" type="reset" title="Start over calculating your BMI">
                                                    <span class="icon icon-angle-right"></span>
                                                    Start over
                                                </button>
                                            </p>
                                        </div>
                                        <div class="col small-12">
                                            <hr class="push--bottom">
                                        </div>
                                    </div>
                                </div>
                            <div class="week_form_row">
                                <div class="row">
                                    <div class="col-12">
                                        <button id="bmi-submit" type="submit" class="btn btn--primary btn--icon w-full mb-3">Calculate<span class="icon"><i class="fa fa-chevron-right f-8"></i></span> </button>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" id="bmi-reset" class="btn btn--secondary btn--icon w-full">Reset<span class="icon"><i class="fa fa-chevron-right f-8"></i></span> </button>


                                        <button  type="submit" style="display: none;" id="bmi-addjounal" class="btn btn--primary btn--block btn--icon"><span class="icon icon-angle-right"></span>Add to Journal</button>

                                        <button type="submit" style="display: none;" id="bmi-removejounal" href="#" class="btn btn--primary btn--block btn--icon hide" ><span class="icon icon-angle-right"></span>Remove from Journal</button>

                                        <a style="display: none;" href="<?= home_url('healthy-living/12-week-weight-management-programme/your-weekly-journal/'); ?>" title="Go to your journal" id="bmi-viewjournal" class="btn btn--secondary btn--block btn--icon"> <span class="icon icon-angle-right"></span>View Journal</a>
                                    </div>
                                </div>
                            </div>
                       
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<script id="ethnic-data" type="application/json">
    [{"Name":"White","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"You are in the healthy weight range, but at the higher end."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your health would benefit from gradually losing weight. Our 12 week programme can help you manage your weight."},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"Excess weight can put you at risk of health issues such as tupe 2 diabetes, heart disease and stroke. Gradually losing weight can help reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"Losing weight gradually and keeping it off can have health beneifts and reduce your risk of type 2 diabetes , heart disease and stroke. If you are concerned about your weight, speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"Losing weight gradually and keeping it off can have health beneifts and reduce your risk of type 2 diabetes , heart disease and stroke. If you are concerned about your weight, speak to your health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Black Caribbean","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak your  health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak your  health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak your  health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Black African","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak your health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak your health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Indian","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Grandually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Grandually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Pakistani","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Bangladeshi","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional.   Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional.   Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional.   Our 12 week programme could help you manage your weight."}]},{"Name":"Chinese","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Middle Eastern","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."}]},{"Name":"Mixed","Range":[{"From":0.0,"To":18.5,"Status":"Underweight","Message":"If you are receiving treatment for an eating disorder then this tool is NOT to be used. There may be an underlying medical cause for your weight, or your diet may not be providing you with enough calories. We suggest you discuss this with your health professional."},{"From":18.51,"To":23.0,"Status":"Healthy (low)","Message":"You are in the healthy weight range, we suggest you maintain your weight. Your ethnicity increases the risk of health issues with a BMI of 23 or more."},{"From":23.01,"To":25.0,"Status":"Healthy (high)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight."},{"From":25.01,"To":27.5,"Status":"Overweight (low)","Message":"Your ethnicity means that excess weight can put you at higher risk of health problems like type 2 diabetes, heart disease and stroke. Gradually losing weight will significantly reduce your risk of health problems. Our 12 week programme can help you manage your weight"},{"From":27.51,"To":30.0,"Status":"Overweight (high)","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":30.01,"To":40.0,"Status":"Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."},{"From":40.01,"To":100.0,"Status":"Severe Obesity","Message":"You ethnicity means that with a BMI above 27.5 you are at high risk of health problems like type 2 diabetes. Gradually losing weight will significantly reduce your risk of health problems. If you are concerned about your weight speak to your health professional. Our 12 week programme could help you manage your weight."}]}]
</script>



<script type="text/javascript">
    


    jQuery(document).ready(function() {
        heightSwap();
    })
</script>