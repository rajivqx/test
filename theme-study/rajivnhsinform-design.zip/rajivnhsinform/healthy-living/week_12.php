<?php 
/* 
Template Name: week_3
* Template Post Type: healthy-living
*/
get_header(); 
 
?>   
    <?php include(dirname(__FILE__) . "/header_menu.php"); ?>

    <!-- MicroSite Header HTML Start -->
    <div class="microsite_header">
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <a href="<?= home_url('healthy-living/12-week-weight-management-programme'); ?>" class="microsite_title">12 Week Weight Management Programme</a>
                </div>
                <div class="col-3">
                    <div class="hamburger_icon week_hamburger">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- MicroSite Header HTML End -->

    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section microsite_breadcrumb" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item d-none d-md-block"><a href="<?= home_url(); ?>">Home</a></li>
                <li class="breadcrumb-item d-none d-md-block"><a href="<?= home_url('healthy-living'); ?>">Healthy living</a></li>
                <li class="breadcrumb-item"><a href="<?= home_url('healthy-living/12-week-weight-management-programme'); ?>">12 Week Weight Management Programme</a></li>
            </ol>
        </div>
    </nav>
    <!-- Breadcrumb HTML End -->

     <!-- Pannel Intro Section HTML Start -->
     <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <span class="week_no"><?= get_the_title() ?></span>
                    <?php 
                        $page_intro = get_field('page_intro'); 
                        if (isset($page_intro) && !empty($page_intro)) {
                            echo $page_intro;
                        }
                    ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->

    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="pannel_wrapper_container detail_container weeks_container">
                        <div class="detail_part">
                            

                            <?php include(dirname(__FILE__) . "/goals_tab.php"); ?>

                            <div class="editor">
                                <?php if(!empty(the_content())): ?>
                                    <?= the_content(); ?>
                                <?php endif; ?>
                            </div>
                            
                            <?php include(dirname(__FILE__) . "/goals_form.php"); ?>



                            <div class="week_alert">
                                <span class="week_alert_icon"><i class="fa-solid fa-circle-info"></i></span>
                                <p></p>

                                <?php  $alert_title = get_field('alert_title');
                                $alert_content = get_field('alert_content');
                                if (isset($alert_title) && !empty($alert_title)): ?> 
                                    <h2><?= $alert_title; ?></h2>
                                <?php endif; ?>
                                <?php if (isset($alert_content) && !empty($alert_content)): ?> 
                                    <?= $alert_content ?>
                                <?php endif; ?>
                            </div>



                            <?php include(dirname(__FILE__) . "/footer_hl.php"); ?>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    
                    <?php include(dirname(__FILE__) . "/BMI_calculator.php"); ?>

                    <div class="pannel_wrapper_container right_container">
                        <h3>Useful documents</h3>
                        <?php 
                            $useful_documents = get_field('useful_documents'); 
                            if (isset($useful_documents) && !empty($useful_documents)):
                                foreach ($useful_documents as $key => $value):
                        ?>
                                <a href="<?= $value['document']['url'] ?>" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s)."><?= $value['document']['title'] ?> (<?= $value['document']['subtype'] ?> <?= intval($value['document']['filesize']/1024) ?>KB) <span class="icon"><i class="fa fa-download" aria-hidden="true"></i></span>
                            </a>
                                <?php endforeach; ?>
                            <?php endif; ?>
                    </div>

                    <div class="panel-content panel-content--half push--bottom text-center pc-alter">
                        <button class="btn--clean border-none" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
                            <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Wrapper Section HTML Start -->
  

<?php
    get_footer();
?>