<div class="accordion bmi_calculator" id="accordionExample2">
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingTwo">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><span class="btn_text">Goals for week 2</span></button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordionExample1">
            <div class="accordion-body">
                <div class="week_form">
                    <form>
                        <?php 
                            $goals = @$_COOKIE['goals'];
                            $goals = json_decode(stripslashes($goals));
                        ?>
                        <p>Set goals for the week ahead, for example eat a piece of fruit at work instead of my morning biscuits and go for a 30 minute walk on 3 different days.</p>
                        <div class="week_form_row">
                            <div class="row">
                                <div class="col-12">
                                    <input id="goal1" name="goal1" type="text" class="form-control"
                                    <?php if (isset($goals) && !empty($goals->goal1)): ?>
                                        value="<?= $goals->goal1; ?>" 
                                    <?php endif; ?>
                                    >
                                </div>
                            </div>
                        </div>
                        <div class="week_form_row">
                            <div class="row">
                                <div class="col-12">
                                    <input id="goal2"  name="goal2" type="text" class="form-control"
                                    <?php if (isset($goals) && !empty($goals->goal2)): ?>
                                        value="<?= $goals->goal2; ?>" 
                                    <?php endif; ?>>
                                </div>
                            </div>
                        </div>
                        <div class="week_form_row">
                            <div class="row">
                                <div class="col-12">
                                    <input id="goal3"name="goal3" type="text" class="form-control"
                                    <?php if (isset($goals) && !empty($goals->goal3)): ?>
                                        value="<?= $goals->goal3; ?>" 
                                    <?php endif; ?>>
                                </div>
                            </div>
                        </div>
                        <div class="week_form_row pb-0">
                            <p>All fields have a maximum character limit of 140.</p>
                        </div>
                        <div class="col small-12" id="goals-error"></div>
                        <div class="week_form_row">
                            <div class="row">
                                <div class="col-6 goals_btn">
                                    <?php if (!isset($goals) || $goals == NULL): ?>
                                         <button id="goals-submit" class="btn btn--primary btn--block btn--icon push--bottom" type="submit"><span class="icon icon-angle-right"></span> Add<span class="visuallyhidden"> Goals</span> to journal </button>
                                    <?php else: ?>
                                        <button id="goals-reset" class="btn btn--primary btn--block btn--icon push--bottom" type="reset"> <span class="icon icon-angle-right"></span>  Remove<span class="visuallyhidden"> Goals</span>  from journal</button>
                                    <?php endif; ?>
                                    
                                </div>
                                <div class="col-6">
                                    <a href="<?= home_url('healthy-living/12-week-weight-management-programme/your-weekly-journal/'); ?>" class="btn btn--secondary btn--block btn--icon">
                                    <span class="icon icon-angle-right"></span>
                                    View journal
                                     </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>