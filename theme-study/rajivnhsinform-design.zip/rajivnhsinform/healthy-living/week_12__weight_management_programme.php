<?php 
/* 
Template Name: 12 Week Weight Management Programme
* Template Post Type: healthy-living
*/

get_header(); 
?> 

    <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section microsite_breadcrumb" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item d-none d-md-block"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Healthy living</a></li>
            </ol>
        </div>
    </nav>
    <!-- Breadcrumb HTML End -->

    <!-- 12 Week Banner Section HTML Start-->
    <section class="week_hero_banner" style="background-image: url('<?php echo  get_template_directory_uri(); ?>/healthy-living/images/healthfoodspread.jpg');">
        <div class="container">
            <div class="row week_hero_text">
                <div class="col-lg-6 col-md-8 lg-push-3 offset-lg-3 offset-md-2 week_hero_text_editor">
                    <h2><?= get_the_title() ?></h2>
                    <p><?= get_the_excerpt() ?></p>
                </div>
            </div>
        </div>
    </section>
    <!--12 Week Banner Section HTML End-->

    <!-- Is this right for me Section HTML Start -->
    <section class="week_wrapper text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <?php if(!empty(the_content())): ?>
                        <?= the_content(); ?>
                    <?php endif; ?>
                    <a class="nhsuk-action-link__link" target="_self" href="<?= home_url(); ?>/healthy-living/12-week-weight-management-programme/about-this-programme">
                        <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M0 0h24v24H0z" fill="none"></path><path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path></svg>
                        <span class="nhsuk-action-link__text"> About this programme and your BMI</span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Is this right for me Section HTML Start -->

    <!-- Tabs Section HTML Start -->
    <section class="week_wrapper week_bg-light-grey text-center">
        <div class="container">
            <h2>The programme</h2>
            <p class="scroll-p d-sm-block d-md-none d-lg-none">Scroll ⇿</p>
            <div class="week_tabs">
            <?php 
            $the_programme_week = get_field('the_programme_week');
            if (isset($the_programme_week) && !empty($the_programme_week)): ?>
                <div class="nav_over">
                    <ul class="nav nav-pills" id="weekTab" role="tablist">

                        <?php foreach ($the_programme_week  as $key => $value): ?>
                            <?php if ($key == 0):?>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="weekTab_<?= $key+1 ?>" data-bs-toggle="pill" data-bs-target="#weekTab<?= $key+1 ?>" type="button" role="tab" aria-controls="weekTab<?= $key+1 ?>" aria-selected="true"><?= $value['weeks_number']; ?></button>
                                </li>
                            <?php else:?>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="weekTab_<?= $key+1 ?>" data-bs-toggle="pill" data-bs-target="#weekTab<?= $key+1 ?>" type="button" role="tab" aria-controls="weekTab<?= $key+1 ?>" aria-selected="true"><?= $value['weeks_number']; ?></button>
                            </li>
                            <?php endif;?>
                        <?php endforeach;?>

                    </ul>
                </div>
                <div class="tab-content" id="weekTabContent">
                     <?php foreach ($the_programme_week  as $key => $value): ?>
                            <?php if ($key == 0):?>
                                <div class="tab-pane fade show active" id="weekTab<?= $key+1 ?>" role="tabpanel" aria-labelledby="weekTab_<?= $key+1 ?>">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-7 text_block">
                                            <h2><?= $value['title'] ?></h2>
                                            <p><?= $value['weeks_contents'] ?></p>

                                            <a class="nhsuk-action-link__link" target="_self" href="<?= home_url(); ?>/healthy-living/12-week-weight-management-programme/week-1">
                                                <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M0 0h24v24H0z" fill="none"></path><path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path></svg>
                                                <span class="nhsuk-action-link__text"> Get Started</span>
                                            </a>
                                        </div>
                                        <div class="col-lg-6 col-md-5 d-none d-md-block img_block">
                                            <img src="<?= $value['weeks_image'] ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                            <?php else:?>
                                <div class="tab-pane fade" id="weekTab<?= $key+1 ?>" role="tabpanel" aria-labelledby="weekTab_<?= $key+1 ?>">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-7 text_block">
                                            <h2><?= $value['title'] ?></h2>
                                            <p><?= $value['weeks_contents'] ?></p>

                                            <a class="nhsuk-action-link__link" target="_self" href="<?= home_url(); ?>/healthy-living/12-week-weight-management-programme/week-<?= $key+1 ?>">
                                                <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M0 0h24v24H0z" fill="none"></path><path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path></svg>
                                                <span class="nhsuk-action-link__text"> Get Started</span>
                                            </a>
                                        </div>
                                        <div class="col-lg-6 col-md-5 d-none d-md-block img_block">
                                            <img src="<?= $value['weeks_image'] ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                            <?php endif;?>
                    <?php endforeach;?>
                </div>
            <?php endif;?>
                
                
            </div>
        </div>
    </section>
    <!-- Tabs Section HTML Start -->

    <!-- Useful documents Section HTML Start -->
    <section class="week_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-9">
                    <h2>Useful documents</h2>
                        <?php 
                        $useful_documents_content = get_field('useful_documents_content');
                        if (isset($useful_documents_content) && !empty($useful_documents_content)) {
                            echo $useful_documents_content;
                        }
                        ?>
                </div>
                <div class="col-md-4 col-lg-3">
                    <?php 
                        $useful_documents = get_field('useful_documents'); 
                        if (isset($useful_documents) && !empty($useful_documents)):
                            foreach ($useful_documents as $key => $value):
                    ?>
                            <a href="<?= $value['document']['url'] ?>" class="btn btn--primary btn--icon btn_custom push--bottom btn--hollow" target="_blank" title="Click here to download your item(s)."><?= $value['document']['title'] ?> (<?= $value['document']['subtype'] ?> <?= intval($value['document']['filesize']/1024) ?>KB) <span class="icon"><i class="fa fa-download" aria-hidden="true"></i></span>
                        </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Useful documents Section HTML Start -->

    <!-- Recipes Section HTML Start -->

    <section class="week_wrapper week_bg-light-grey text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h2>Recipes</h2>
                    <?php  $recipes_content = get_field('recipes_content'); ?>
                    <?php if (isset($recipes_content) && !empty($recipes_content)) {
                        echo $recipes_content;
                    } ?>
                </div>
            </div>
            <div class="row">

            <?php  $recipes = get_field('recipes'); ?>
            <?php if (isset($recipes) && !empty($recipes)): ?>
                <?php foreach ($recipes as $key => $value):?>
                    <div class="col-md-6">
                        <div class="week_block">
                            <a href="<?=$value['recipes_url']; ?>">
                                <img src=" <?=$value['recipes_img']; ?>" alt="">
                                <div class="week_block_bg"></div>
                                <div class="week_block_text"> <?=$value['recipes_title']; ?></div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Recipes Section HTML Start -->

    <!-- Recipes Section HTML Start -->
    <section class="week_wrapper text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h2>Related articles</h2>
                    <p>
                        <?php  $related_articles_content = get_field('related_articles_content'); ?>
                        <?php if (isset($related_articles_content) && !empty($related_articles_content)) {
                            echo $related_articles_content;
                        } ?>
                    </p>
                </div>
            </div>
            <div class="row">
                <?php  $related_articles = get_field('related_articles'); ?>
                <?php if (isset($related_articles) && !empty($related_articles)): ?>
                    <?php foreach ($related_articles as $key => $value):?>
                    <div class="col-md-4">
                        <div class="week_block">
                            <a href="<?=$value['related_url']; ?>">
                                <img src=" <?=$value['related_img']; ?>" alt="">
                                <div class="week_block_bg"></div>
                                <div class="week_block_text"> <?=$value['related_title']; ?></div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Recipes Section HTML Start -->

    <!-- Recipes Section HTML Start -->
    <section class="week_wrapper week_bg-light-grey text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <p class="mb-0">This programme was developed by AppleTree Healthy Lifestyle Consultancy on behalf of the British Dietetic Association for Public Health Scotland.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Recipes Section HTML Start -->
 
<?php
    get_footer();
?>