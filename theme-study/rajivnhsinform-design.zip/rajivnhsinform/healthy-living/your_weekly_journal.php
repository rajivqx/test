<?php 
/* 
Template Name: journal
* Template Post Type: healthy-living
*/
get_header(); 
 
?>   
    <?php include(dirname(__FILE__) . "/header_menu.php"); ?>

    <!-- MicroSite Header HTML Start -->
    <div class="microsite_header">
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <a href="#" class="microsite_title">12 Week Weight Management Programme</a>
                </div>
                <div class="col-3">
                    <div class="hamburger_icon week_hamburger">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- MicroSite Header HTML End -->

    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section microsite_breadcrumb" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item d-none d-md-block"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item d-none d-md-block"><a href="#">Healthy living</a></li>
                <li class="breadcrumb-item"><a href="#">12 Week Weight Management Programme</a></li>
            </ol>
        </div>
    </nav>
    <!-- Breadcrumb HTML End -->


    <div id="main_content">
     <!-- Pannel Intro Section HTML Start -->
     <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <h1><?= get_the_title() ?></h1>
                    <?php 
                        $page_intro = get_field('page_intro'); 
                        if (isset($page_intro) && !empty($page_intro)) {
                            echo $page_intro;
                        }
                    ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->

    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="pannel_wrapper_container detail_container weeks_container">
                        <div class="detail_part">
                            <?php 
                                $weekly_check_in_content = get_field('weekly_check_in_content');
                                if (isset($weekly_check_in_content) && !empty($weekly_check_in_content)):  
                            ?>   
                            <div class="editor">
                                <?= $weekly_check_in_content; ?>
                            </div>
                        <?php endif; ?>

                            <h2>Your Journal</h2>
                            <div class="panel-content panel-content--half push--bottom">
                                <?php 
                                    $bmi_result = @$_COOKIE['bmi_result'];
                                    $bmi_result = json_decode(stripslashes($bmi_result));
                                    if (isset($bmi_result) && !empty($bmi_result) && $bmi_result != NULL): 
                                        $data = urldecode($bmi_result->content);
                                ?>
                                    <?= $data; ?>
                                <?php else: ?>
                                <div id="journal-bmi-title"><h3 class="no-margin">Your BMI</h3></div>
                                <div id="journal-bmi-score"><p class="bold mega push--bottom secondary-color">You haven’t added a BMI score to your journal</p></div>
                                <div id="journal-bmi-message"><p>Please go back and use the BMI Calculator which can be found on the weekly checkin page</p></div>
                                <?php endif; ?>
                            </div>
 

                            <div class="panel-content panel-content--half push--bottom">
                                <div id="journal-progress-title"><h3 class="no-margin">Your progress since last week</h3></div>

                                <?php 
                                    $check_progress = @$_COOKIE['check_progress'];

                                    $check_progress = json_decode(stripslashes($check_progress));
 
                                    if (isset($check_progress) && !empty($check_progress) && $check_progress != NULL):
                                        $data = urldecode($check_progress->content);
                                ?>
                                <p class="push--bottom">Did you achieve the goals you set yourself last week?</p>
                                <p class="bold mega push--bottom secondary-color"><?= $check_progress->type ?></p>
                                <p class="push--bottom">
                                    <?= $data; ?>
                                </p>
                                <?php else: ?>
                                    <div id="journal-progress-message"><p class="push--bottom">You haven’t added your weekly check-in to your journal</p></div>
                                <?php endif; ?>
                            </div>


                            <div class="panel-content panel-content--half push--bottom">
                                <div id="journal-goal-title"><h3 class="no-margin">Your goals for next week</h3></div>
                                <?php 
                                    $goals = @$_COOKIE['goals'];
                                    $goals = json_decode(stripslashes($goals));
                                    if (isset($goals) && !empty($goals) && $goals != NULL):
                                     
                                ?>
                                    <div id="journal-goal-one">
                                        <div class="push--bottom">
                                            <p class="bold mega push--bottom secondary-color">Goal 1.</p>
                                            <p class="push--bottom"><?= $goals->goal1 ?></p>
                                        </div>
                                    </div>
                                    <div id="journal-goal-two">
                                        <div class="push--bottom">
                                            <p class="bold mega push--bottom secondary-color">Goal 2.</p>
                                            <p class="push--bottom"><?= $goals->goal2 ?></p>
                                        </div>
                                    </div>
                                    <div id="journal-goal-three">
                                        <div class="push--bottom">
                                            <p class="bold mega push--bottom secondary-color">Goal 3.</p>
                                            <p class="push--bottom"><?= $goals->goal3 ?></p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                <div id="journal-goal-one"><p>You haven’t added your goals to your journal</p></div>
                                 <?php endif; ?>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <p class="push--bottom">

                                        <?php if (@$goals != NULL || @$check_progress != NULL || @$bmi_result != NULL): ?>
                                            <button id="journal-clear" class="btn btn--primary btn--block btn--icon" title="Click here to clear your current journal.">
                                                <span class="icon icon-angle-right"></span>
                                                Clear journal
                                            </button>
                                        <?php endif ?>
                                    </p>
                                </div>
                            </div>

                            <div class="alert alert--danger alert--small">
                                
                                <?php 
                                    $alert_title = get_field('alert_title');
                                    $alert_content = get_field('alert_content');
                                    if (isset($alert_title) && !empty($alert_title)): ?> 
                                        <h2 class="no-margin">
                                            <?= $alert_title; ?>
                                        </h2>
                                    <?php endif; ?>
                                    <?php if (isset($alert_content) && !empty($alert_content)): ?> 
                                        <p id="wght-mgnt-journal-data--notice"><?= $alert_content ?></p>
                                    <?php endif; ?>
                            </div>


                            <div class="row ">
                                <div class="col-lg-9">
                                    <div class="week_bg-light-grey img_text_block">
                                        <img src="images/phstransparent240x80.png" alt="">
                                        <p>Source:Public Health Scotland</p>
                                    </div>
                                </div>
                            </div>
 
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 sidebar_1">

  
                        <button onclick="savePDF()"  type="submit" aria-pressed="false" aria-label="Save this page as PDF" class="btn btn--primary btn--block btn--icon">Save as PDF</button>
                        <input type="hidden" name="changeOrderValue" id="changeOrderValue" value="">


                    
                    <div class="panel-content panel-content--half push--bottom text-center pc-alter">
                        <button class="btn--clean border-none" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
                            <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Wrapper Section HTML Start -->
    </div>

     <style type="text/css">
         h3.no-margin {
            font-family: 'Avenir W01',sans-serif !important;
        }
     </style>
 
 



    <script type="text/javascript">
        function deleteFile(deleteFilePath){
          $.ajax({
            type: "post",
            url: "<?php echo admin_url('admin-ajax.php');?>",
            data: {action:'deleteFile_pdf',deleteFilePath:deleteFilePath},
            success: function(response){  
                var getData = JSON.parse(response);
               console.log(response);
            }
          }); 
        }
        function pdfDwonload(fileURL){
            $.ajax({
                url: fileURL,
                method: 'GET',
                xhrFields: {
                    responseType: 'blob'
                },
                beforeSend: function(){
              $('.ajax_loader').show();
              $(window).scrollTop(5);
            },
            complete: function(){
              $('.ajax_loader').hide();
            },
                success: function(data){
                    var a = document.createElement('a');
                    var url = window.URL.createObjectURL(data);
                    a.href = url;
                    a.download = 'info_for_me_<?php echo uniqid();?>.pdf';
                    document.body.append(a);
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);

                }
            });
        }
        function savePDF(){
          var changeOrderValue  = $('#changeOrderValue').val();
          $.ajax({
            type: "post",
            url: "<?php echo admin_url('admin-ajax.php');?>",
            data: {action:'info_save_pdf',id: "<?= get_the_ID();?>",changeOrderValue:changeOrderValue},
            beforeSend: function(){
              $('.ajax_loader').show();
              $(window).scrollTop(5);
            },
            complete: function(){
              $('.ajax_loader').hide();
            },
            success: function(response){  
                var getData = JSON.parse(response);
                if(getData.status ==true){
                  pdfDwonload(getData.data);
                  deleteFile(getData.deleteFile);
                }else{
                  alert(getData.message);
                }
            }
          }); 
         }


         jQuery('#journal-clear').on('click', function(e) {
            e.preventDefault();
            let newData = null;
            let dataString = JSON.stringify(newData);
            $.cookie('check_progress', dataString,{ expires: 30, path: '/' });
            $.cookie('goals', dataString,{ expires: 30, path: '/' });
            $.cookie('bmi_result', dataString,{ expires: 30, path: '/' });
            location.reload();
        });
    </script>
<?php
    get_footer();
?>