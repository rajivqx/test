<?php 
    $weekly_check_in_content = get_field('weekly_check_in_content');
    if (isset($weekly_check_in_content) && !empty($weekly_check_in_content)):  
?>   
<div class="editor">
    <?= $weekly_check_in_content; ?>
</div>
<?php endif; ?>
<div class="accordion bmi_calculator" id="accordionExample">
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne"><span class="btn_text">Check your progress</span></button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
            <div class="accordion-body">
                <div class="week_form">
                    <form>
                        <p>Did you achieve the goals you set yourself last week?</p>
                        <div class="week_form_row">
                            <div class="row">
                                <?php 
                                    $check_progress = @$_COOKIE['check_progress'];
                                    $check_progress = json_decode(stripslashes($check_progress));
                                ?>
                                <div class="col-6">
                                    <label class="wlm-radio" for="check-in-yes">
                                        <input type="radio" name="answer" id="check-in-yes" value="yes" <?php if (isset($check_progress->type) && $check_progress->type == 'yes'){echo "checked";} ?>>
                                        <span class="wlm-radio-check"></span>
                                        I achieved my goals
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="wlm-radio" for="check-in-no">
                                        <input type="radio" name="answer" id="check-in-no" value="no" <?php if (isset($check_progress->type) && $check_progress->type == 'no'){echo "checked";} ?>>
                                        <span class="wlm-radio-check"></span>
                                        I didn't achieve my goals
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="week_form_row">
                            <div class="row">
                                <div class="col-12" id="check-in-response">
                                    <?php 
                                        $i_achieved_my_goals = get_field('i_achieved_my_goals');
                                        if (isset($i_achieved_my_goals) && !empty($i_achieved_my_goals)):  
                                    ?>
                                        <p class="push--bottom check-in-yes" style="display: <?php if (isset($check_progress->type) && $check_progress->type == 'yes'){echo "block";}else{ echo "none"; } ?>;">
                                        <?= $i_achieved_my_goals; ?>
                                        </p>
                                    <?php endif; ?>
                                    <?php 
                                        $i_didnt_achieve_my_goals = get_field('i_didnt_achieve_my_goals');
                                        if (isset($i_didnt_achieve_my_goals) && !empty($i_didnt_achieve_my_goals)):  
                                    ?>
                                        <p class="push--bottom check-in-no" style="display: <?php if (isset($check_progress->type) && $check_progress->type == 'no'){echo "block";}else{ echo "none"; } ?>;">
                                        <?= $i_didnt_achieve_my_goals; ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 checkin_btn"> 
                                    <?php if (!isset($check_progress) || $check_progress == NULL): ?>
                                        <button id="checkin-submit" type="submit" class="btn btn--primary btn--icon w-full">Add to journal<span class="icon"><i class="fa fa-chevron-right f-8"></i></span> </button>
                                    <?php else: ?>
                                        <button id="checkin-remove" class="btn btn--primary btn--block btn--icon push--bottom" type="reset"><span class="icon icon-angle-right"></span><span class="visuallyhidden">Please </span>Remove <span class="visuallyhidden">Progress </span>from journal</button>
                                    <?php endif; ?>
                                   
                                </div>
                                <div class="col-6 medium-6">
                                    <a href="<?= home_url('healthy-living/12-week-weight-management-programme/your-weekly-journal/'); ?>" class="btn btn--secondary btn--block btn--icon"><span class="icon icon-angle-right"></span>View <span class="visuallyhidden">your progress in </span>Journal</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>   
</div>