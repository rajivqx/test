function searchToggle() {
    $('.mobile_search').on('click', function() {
        $('.mobile_search_detail').toggle();
        $(this).siblings('.navbar-collapse').removeClass('show');
    });

    $('.navbar-toggler').on('click', function() {
        $(this).parents('header').siblings('.mobile_search_detail').hide();
    });
}

function list_scroll() {
    $('.list_a').on('click', function() {
        $('html, body').animate({ scrollTop: $('.a_detail').offset().top }, 100)
    });
    $('.list_b').on('click', function() {
        $('html, body').animate({ scrollTop: $('.b_detail').offset().top }, 100)
    });
    $('.list_c').on('click', function() {
        $('html, body').animate({ scrollTop: $('.c_detail').offset().top }, 100)
    });
    $('.list_d').on('click', function() {
        $('html, body').animate({ scrollTop: $('.d_detail').offset().top }, 100)
    });
    $('.list_e').on('click', function() {
        $('html, body').animate({ scrollTop: $('.e_detail').offset().top }, 100)
    });
    $('.list_f').on('click', function() {
        $('html, body').animate({ scrollTop: $('.f_detail').offset().top }, 100)
    });
    $('.list_g').on('click', function() {
        $('html, body').animate({ scrollTop: $('.g_detail').offset().top }, 100)
    });
    $('.list_h').on('click', function() {
        $('html, body').animate({ scrollTop: $('.h_detail').offset().top }, 100)
    });
    $('.list_i').on('click', function() {
        $('html, body').animate({ scrollTop: $('.i_detail').offset().top }, 100)
    });
    $('.list_j').on('click', function() {
        $('html, body').animate({ scrollTop: $('.j_detail').offset().top }, 100)
    });
    $('.list_k').on('click', function() {
        $('html, body').animate({ scrollTop: $('.k_detail').offset().top }, 100)
    });
    $('.list_l').on('click', function() {
        $('html, body').animate({ scrollTop: $('.l_detail').offset().top }, 100)
    });
    $('.list_m').on('click', function() {
        $('html, body').animate({ scrollTop: $('.m_detail').offset().top }, 100)
    });
    $('.list_n').on('click', function() {
        $('html, body').animate({ scrollTop: $('.n_detail').offset().top }, 100)
    });
    $('.list_o').on('click', function() {
        $('html, body').animate({ scrollTop: $('.o_detail').offset().top }, 100)
    });
    $('.list_p').on('click', function() {
        $('html, body').animate({ scrollTop: $('.p_detail').offset().top }, 100)
    });
    $('.list_q').on('click', function() {
        $('html, body').animate({ scrollTop: $('.q_detail').offset().top }, 100)
    });
    $('.list_r').on('click', function() {
        $('html, body').animate({ scrollTop: $('.r_detail').offset().top }, 100)
    });
    $('.list_s').on('click', function() {
        $('html, body').animate({ scrollTop: $('.s_detail').offset().top }, 100)
    });
    $('.list_t').on('click', function() {
        $('html, body').animate({ scrollTop: $('.t_detail').offset().top }, 100)
    });
    $('.list_u').on('click', function() {
        $('html, body').animate({ scrollTop: $('.u_detail').offset().top }, 100)
    });
    $('.list_v').on('click', function() {
        $('html, body').animate({ scrollTop: $('.v_detail').offset().top }, 100)
    });
    $('.list_w').on('click', function() {
        $('html, body').animate({ scrollTop: $('.w_detail').offset().top }, 100)
    });
    $('.list_x').on('click', function() {
        $('html, body').animate({ scrollTop: $('.x_detail').offset().top }, 100)
    });
    $('.list_y').on('click', function() {
        $('html, body').animate({ scrollTop: $('.y_detail').offset().top }, 100)
    });
    $('.list_z').on('click', function() {
        $('html, body').animate({ scrollTop: $('.z_detail').offset().top }, 100)
    });

    $('.back_top_button').on('click', function() {
        $('html, body').animate({ scrollTop: $('body').offset().top }, 100)
    });

}

function show_nav_list() {
    $('.plusminus_btn').on('click', function() {
        $('.default_hide').toggleClass('default_show');
        $(this).children('i').toggleClass('fa-minus');
    });

    $('.nav_parent .plusminus_btn').on('click', function() {
        $(this).parent('.nav-item').siblings('.nav_child').toggleClass('default_show');
    });

    $('.default_hide .nav-item').on('click', function() {
        if($(this).siblings().children('.nav-link').hasClass('active')) {
            $(this).siblings().children('.nav-link').removeClass('active');
        };
    });

    $('.navigate_part .nav-item').on('click', function() {
        if($(this).siblings().find('.nav-link').hasClass('active')) {
            $(this).siblings().find('.nav-link').removeClass('active');
        };
    });

    $('.toggler').on('click', function() {
        if($(this).siblings().find('.nav-link').hasClass('active')) {
            $(this).siblings().find('.nav-link').removeClass('active');
        };
    });
}

function nav_btn_toggle() {
    $('.navigate_btn').on('click', function() {
        $('.navigate_container .navigate_part .nav-tabs').toggleClass('show');
        $(this).find('i').toggleClass('fa-minus');
    });
}

function navScrollTop() {
    $(".navigate_container .navigate_part .nav-item .nav-link").each(function() {
        $(this).click(function() {
            if($(window).width() > 767) {
                $('html, body').animate({
                    scrollTop: $("header").offset().top
                }, 100);
            } else {
                $('html, body').animate({
                    scrollTop: $(".detail_container").offset().top
                }, 100);
            }
            
        })
    });
}

function HamburgerClick() {
    $('.hamburger_icon').on('click', function() {
        $('.microsite_overlay').css('display','block');
        $('body').css('overflow','hidden');
        $('.microsite_navigation').css('display','block');
    });

    $('.microsite_overlay').on('click', function() {
        $(this).hide();
        $('body').css('overflow','auto');
        $('.microsite_navigation').css('display','none');
    });

    $('.close_micro').on('click', function() {
        $(this).parents('.microsite_navigation').hide();
        $(this).parents('.microsite_navigation').siblings('.microsite_overlay').hide();
        $('body').css('overflow','auto');
    });

    $('.micro_nav_slide').on('click', function() {
        var singleClone = $(this).siblings('.micro_nav_slide_list');
        var copiedData = singleClone.clone();
        copiedData.appendTo('.micro_nav_slide_list_container');
        $(this).parents('.microsite_nav_list').siblings('.micro_nav_slide_list_container').css({'right':'0px'});
    });

    $('.micro_nav_slide_list_back').on('click', function() {
        $(this).siblings('.micro_nav_slide_list').delay(700).queue(function() {
            $(this).remove();
        });

        $(this).parents('.micro_nav_slide_list_container').css({'right':'-800px'});
    });
}

function Prev_btn() {
    $('.prev_btn').on('click', function() {
        $('html, body').animate({
            scrollTop: $(".detail_container").offset().top
        }, 100);

        $(this).parents('.tab-pane').removeClass('active show');
        $(this).parents('.tab-pane').prev('.tab-pane').addClass('active show');
    });
}

function Next_btn() {
    $('.next_btn').on('click', function() {
        $('html, body').animate({
            scrollTop: $(".detail_container").offset().top
        }, 100);

        $(this).parents('.tab-pane').removeClass('active show');
        $(this).parents('.tab-pane').next('.tab-pane').addClass('active show');
    });
}

function Prev_Next() {
    $('.next_btn').each(function() {
        $(this).on('click', function() {
            var nextBtnId = $(this).parents('.tab-pane').attr('id');
            var idArray = nextBtnId.split('_');
            var addDynamicId = ('#Tab'+idArray[1]);
            
            $(addDynamicId).removeClass('active');
            $(addDynamicId).parent('.nav-item').next('.nav-item').children('.nav-link').addClass('active');
        });
    });

    $('.prev_btn').each(function() {
        $(this).on('click', function() {
            var nextBtnId = $(this).parents('.tab-pane').attr('id');
            var idArray = nextBtnId.split('_');
            var addDynamicId = ('#Tab'+idArray[1]);
            
            $(addDynamicId).removeClass('active');
            $(addDynamicId).parent('.nav-item').prev('.nav-item').children('.nav-link').addClass('active');
        });
    });
}

function formQuestion() {
    $('.shg_form textarea').blur(function() {
        var textAreaValue = $(this).val();
        var textAreaId = $(this).attr('id');
        var IdArray = textAreaId.split("_");
        var prependId = ('#graphicQuestion'+IdArray[1]);

        $(prependId).prepend(textAreaValue);
    });
}

function feedbackForm() {
    $('.feedback_btn').on('click', function() {
        $(this).siblings('.week_feedback_container').toggleClass('show_form');
        $(this).find('.icon i').toggleClass('fa-chevron-down');
    });
}

function heightSwap() {
    $('.height_swapper').on('click', function(e) {
        e.preventDefault();
        $(this).text(($(this).text() == 'CM') ? 'FIT & IN' : 'CM').fadeIn();
        $('.bmi_height_ft').toggleClass('height_show')
        $('.bmi_height_cm').toggleClass('height_show');
    });

    $('.weight_swapper').on('click', function(e) {
        e.preventDefault();
        $(this).text(($(this).text() == 'KG') ? 'ST & LBS' : 'KG').fadeIn();
        $('.bmi_weight_lbs').toggleClass('weight_show')
        $('.bmi_weight_kg').toggleClass('weight_show');
    });

    $('.ask_question').on('click', function(e) {
        e.preventDefault();
        $(this).parents('.row').siblings('.ask_quesAnswer').toggleClass('showAnswer');
    });

   

  // ------------------------------------------------
    $('#bmi-reset').on('click', function(e) {
        e.preventDefault();
        $('.week_form :input').val('');
        $('.week_form option:first').prop('selected', true);
        $('.week_form :checkbox').prop('checked', false);
    });

    let convertToCm = (feet, inches) => {
        return Math.round((feet / 0.032808) + (inches / 0.393700)); 
    }

    let convertToKg = (stone, pounds) => {
        return Math.round((stone / 0.15747) + (pounds / 2.2046)); 
    }

    function calculateBmi(weight, height) {
        var height = height / 100;
        var bmi = weight / (height * height);
        return bmi;
    }

    let MESSAGES = {
        changeToCM : "Change to Centimeters",
        changeToFT : "Change to Feet & Inches",
        changeToKG : "Change to Kilograms",
        changeToST : "Change to Stone & Pounds",
        IEError : 'Please ensure all fields are filled out prior to trying to submit this form.',
        Age : "We can only provide BMI scores for people aged 18 and over. If you're under 18 and concerned about your weight, speak to a health professional for advice.",
        BMI : 'Your BMI is'
    }

    let ID = {
        IEerror : 'bmi-error',
        UserBMI : 'bmi-result',
        UserBMIMessage : 'bmi-result-message',
        IError : 'goals-error',
        Form: 'goals-form',
    }

    // IE validation
    let formValidation = () => {

        var ethnicity = $('#Ethnicity').val();

        if ($('.bmi_height_cm.height_show #Centimeters').length) {
            var height = $('.height_show #Centimeters').val();
        } else {
            var heightFT = $('.height_show #wgt-ft').val();
            var heightIN = $('.height_show #wgt-in').val();
            var height = convertToCm(heightFT, heightIN);
        }

        if ($('.bmi_weight_kg.weight_show #wgt-kg').length) {
            var weight = $('.bmi_weight_kg.weight_show #wgt-kg').val();
        } else {
            var weightST = $('.weight_show #wgt-st').val();
            var weightPO = $('.weight_show #wgt-po').val();
            var weight = convertToKg(weightST, weightPO)
        }

        if (!(heightFT !== "") || !(heightIN !== "") || !(height !== "") || !(weightST !== "") || !(weight !== "") || !(weightPO !== "") || !(ethnicity !== "Please Select")) {
            document.getElementById(ID.IEerror).innerHTML = '<p class="red push--bottom">' + MESSAGES.IEError + '</p>';
        } else {        
            document.getElementById(ID.IEerror).innerHTML = '';
            formCalculations(height,weight);
        }
        return false;
    };

    function formCalculations(heightCM,weightKG) {
        if (jQuery("#age").prop("checked")) {
            jQuery("#bmi-error").text('');
 
            let cmMtr = heightCM / 100;
            let cmSq = cmMtr * cmMtr;
            let BMI = weightKG / cmSq;

            let data = JSON.parse(document.getElementById("ethnic-data").textContent);

            var ethnicity = $('#Ethnicity').val();

            // Determine related message
            var bmiResult = Math.round(BMI);
            let bmiResultLabel = '';
            let bmiResultMessage = '';

            for(var i = 0; i < data.length; i++) {
                if(data[i].Name == ethnicity) {
                    var ethnicity = data[i]; 
                    let bmiResultLabel1 = '';
                    let bmiResultMessage1 = '';
                    for(var x = 0; x < ethnicity.Range.length; x++) {
                        if(bmiResult >= ethnicity.Range[x].From && bmiResult <= ethnicity.Range[x].To) {
                            bmiResultLabel1 = ethnicity.Range[x].Status;
                            bmiResultMessage1 = ethnicity.Range[x].Message;
                        }
                    }
                    bmiResultLabel = bmiResultLabel1;
                    bmiResultMessage = bmiResultMessage1;
                }
            }

            document.getElementById(ID.UserBMI).innerHTML = '<h3 class="mega bold">' + MESSAGES.BMI + ' <span id="bmi-animate" class="primary-color">' + BMI.toFixed(2) + '</span></h3><p class="push--bottom bold">' + bmiResultLabel + "</p>";
            let newBmiResultMessage = bmiResultMessage;
            document.getElementById(ID.UserBMIMessage).innerHTML = newBmiResultMessage;

            jQuery("#bmi-form").hide();
            jQuery("#bmi-resultcontainer").show();
            jQuery("#bmi-submit").hide();
            jQuery("#bmi-addjounal").show();
            jQuery("#bmi-viewjournal").show();
            jQuery("#bmi-reset").hide();

        } else {
           jQuery("#bmi-error").append('<p class="red push--bottom">' + MESSAGES.Age + '</p>'); 
        }
    }

    $('#bmi-submit').on('click', function(e) {
        e.preventDefault();
        formValidation();
    });

    $('#bmi-startover').on('click', function(e) {
        e.preventDefault();
        $('.week_form :input').val('');
        $('.week_form option:first').prop('selected', true);
        $('.week_form :checkbox').prop('checked', false);
        jQuery("#bmi-form").show();
        jQuery("#bmi-resultcontainer").hide();
        jQuery("#bmi-submit").show();
        jQuery("#bmi-addjounal").hide();
        jQuery("#bmi-viewjournal").hide();
        jQuery("#bmi-reset").show();
    });

    $('#bmi-addjounal').on('click', function(e) {
        e.preventDefault();
        jQuery("#bmi-removejounal").show();
        jQuery("#bmi-addjounal").hide();

        var resultcontainers = $('.bmi-resultcontainers').html();
        let newData = {content: encodeURIComponent(resultcontainers)};
        let dataString = JSON.stringify(newData);
        $.cookie('bmi_result', dataString,{ expires: 30, path: '/' });
        let storedDataString = $.cookie('bmi_result');

    });
    $('#bmi-removejounal').on('click', function(e) {
        e.preventDefault();
        jQuery("#bmi-addjounal").show();
        jQuery("#bmi-removejounal").hide();
    });


  // ------------------------------------------------


    jQuery('#check-in-yes').change(function() {
        $('.check-in-yes').show()
        $('.check-in-no').hide()
    });
    jQuery('#check-in-no').change(function() {
        $('.check-in-no').show()
        $('.check-in-yes').hide()
    });

    $(document).on('click','#checkin-submit',function(e){
        e.preventDefault();
        jQuery("#checkin-remove").show();
        jQuery("#checkin-submit").hide();

        if ($('#check-in-yes').is(':checked') || $('#check-in-no').is(':checked')) {

            if ($('#check-in-yes').is(':checked')){
                var content = $('p.push--bottom.check-in-yes').html();
                var types = 'yes';
            }else{
                var content = $('p.push--bottom.check-in-no').html();
                var types = 'no';
            }

            $('#checkin-remove').remove();
            $('.checkin_btn').append(`<button id="checkin-remove" class="btn btn--primary btn--block btn--icon push--bottom" type="reset"><span class="icon icon-angle-right"></span><span class="visuallyhidden">Please </span>Remove <span class="visuallyhidden">Progress </span>from journal</button>`);


            let newData = { type: types, content: encodeURIComponent(content)};

            let dataString = JSON.stringify(newData);
            $.cookie('check_progress', dataString,{ expires: 30, path: '/' });
            let storedDataString = $.cookie('check_progress');

        } else {
           $('#check-in-no').prop('checked', true);
            $('.check-in-no').show()
            $('.check-in-yes').hide()
        }

        if ($('#check-in-yes').is(':checked')) {
          $('#check-in-no').prop('disabled', true);
        } else {
          $('#check-in-no').prop('disabled', false);
        }
        
        if ($('#check-in-no').is(':checked')) {
          $('#check-in-yes').prop('disabled', true);
        } else {
          $('#check-in-yes').prop('disabled', false);
        }

    });
    $(document).on('click','#checkin-remove',function(e){
        e.preventDefault();
        jQuery("#checkin-remove").hide();
        jQuery("#checkin-submit").show();
        $('#check-in-no').prop('disabled', false);
        $('#check-in-yes').prop('disabled', false);
        $('#check-in-yes, #check-in-no').prop('checked', false);
        $('.check-in-no').hide()
        $('.check-in-yes').hide()

        $('#checkin-submit').remove();
        $('.checkin_btn').append(` <button id="checkin-submit" type="submit" class="btn btn--primary btn--icon w-full">Add to journal<span class="icon"><i class="fa fa-chevron-right f-8"></i></span> </button>`);

        let newData = null;
        let dataString = JSON.stringify(newData);
        $.cookie('check_progress', dataString,{ expires: 30, path: '/' });
    });



    // -----------------------------------------
     
    $(document).on('click','#goals-reset',function(e){
        $('#goal1').val('');
        $('#goal2').val('');
        $('#goal3').val('');
        $('#goals-submit').show()
        $('#goals-reset').hide()
        $('#goals-error').empty()
         $('#goals-reset').remove();
        $('.goals_btn').append(`<button id="goals-submit" class="btn btn--primary btn--block btn--icon push--bottom hide" type="submit"><span class="icon icon-angle-right"></span> Add<span class="visuallyhidden"> Goals</span> to journal </button> `);
        let newData = null;
        let dataString = JSON.stringify(newData);
        $.cookie('goals', dataString,{ expires: 30, path: '/' });
        let storedDataString = $.cookie('goals');

    });
    $(document).on('click','#goals-submit',function(e){ 
        e.preventDefault();
    
        let goal1 = $('#goal1').val();
        let goal2 = $('#goal2').val();
        let goal3 = $('#goal3').val();
        $('#goals-reset').remove();
        $('.goals_btn').append(`<button id="goals-reset" class="btn btn--primary btn--block btn--icon push--bottom" type="reset"> <span class="icon icon-angle-right"></span>  Remove<span class="visuallyhidden"> Goals</span>  from journal</button>`);
        if (goal3 != '' && goal2 != '' && goal1 !='') {

            let newData = { goal1: goal1, goal2: goal2, goal3: goal3};
            let dataString = JSON.stringify(newData);
            $.cookie('goals', dataString,{ expires: 30, path: '/' });
            let storedDataString = $.cookie('goals');

            $('#goals-submit').hide()
            $('#goals-reset').show()
            $('#goals-error').empty()
        }else{
            if (goal1 == '') { $('#goal1').focus(); }
            if (goal1 != '' && goal2 == '') { $('#goal2').focus(); }
            if (goal1 != '' && goal2 != '' && goal3 == '') { $('#goal3').focus(); }
            $('#goals-error').empty()
            $('#goals-error').append('<p class="red push--bottom">You must add enter your 3 weekly goals.</p>')
        }
    });
}

jQuery(document).ready(function() {
    searchToggle();
    list_scroll();
    show_nav_list();
    nav_btn_toggle();
    navScrollTop();
    HamburgerClick();
    Prev_btn();
    Next_btn();
    Prev_Next();
    formQuestion();
    feedbackForm();
    heightSwap();
})