<div class="row ">
    <div class="col-sm-12 col-lg-9 lgtranslate">
        <div class="push--ends translationpush">
            <p class="nhsuk-body-s nhsuk-u-secondary-text-color no-margin">
                Last updated:
                <br>
                <?php  the_date('d F Y'); ?>
            </p>
        </div>
    <?php //get_sidebar('breadcrumb-bottom');?>
        <?php
        if (!empty(get_sidebar('feedback-form-transalation'))) {
        if(get_field('feedback_disabled')[0] !="yes"){
        get_sidebar('feedback-form-transalation'); 
        } }
        ?>
        </div>
</div>