<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script type="text/javascript">
$(function(){
  $("form#feedbackForm").validate({
    rules:{
      "email":{
        required: true,
        email: true
      }, 
      "message": "required"
    },
    messages:{
      email: {
      required: "'Email' should not be empty",
      email: "Please enter a valid email address.",
     },
     message: {
      required: "'Message' should not be empty"
    }
  
    },
    submitHandler: function(form){  
     var frm = new FormData();
     var data = jQuery('#feedbackForm').serializeArray();
      jQuery.each(data,function(key,input){
        frm.append(input.name,input.value);
      });
      frm.append('action','feedback_form');
      //formData.append('pDataID',pDataID);
      $.ajax({
        url:"<?php echo admin_url('admin-ajax.php');?>",
         type: 'post',
         data: frm,
         contentType: false,
         processData: false,
         //crossDomain:true,
         beforeSend: function(){
            $('#feedback-submit').html('Processing...');
            //$(window).scrollTop(5);
          },
          complete: function(){
            $('#feedback-submit').html('Send feedback');
          },
        success: function(response){
            var getData = JSON.parse(response);
            console.log(response);
            if(getData.status ==true){
                $("#feedback-message").show();
                $("#feedbackForm").hide();
                $("#feedbackForm")[0].reset()
                //location.reload();
            }else{
              //$("#feedback-message").show();
              alert(getData.message);
            }
            console.log(response);     
        },
         error: function(response){
          console.log(response)
         }
     });
     return false;
      //form.submit();

    }
  });
});
</script>

