<?php
/**
 * The template for displaying archive-illnesses pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nhsinform
 */

get_header();?>
<!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->
    <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                       <?php if(have_posts()):?>
						<?php
						    //post_type_archive_title('',false);
							the_archive_title( '<h1>', '</h1>');
							the_archive_description( '<p>', '</p>');
						else :
							get_template_part( 'template-parts/content', 'none' );
						endif;?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->
        <?php 
        $term     = get_queried_object(); 
        $getSlug    = $term->slug;
        if($getSlug == "palliative-care" ||$getSlug == "health-rights"):
            get_template_part( 'template-parts/care_type', 'palliative-care' );?>
       <?php else :?>
        <?php get_template_part( 'template-parts/care_type', 'default');?>
       <?php endif;?>
<?php 
get_footer();
