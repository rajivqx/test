<div class="genesis-custom-block <?php block_field('className'); ?>">
<div class="panel-component soft">
<?php
$attachment_id = block_value( 'media' );
$url = wp_get_attachment_url( $attachment_id );
$attachment_meta = wp_prepare_attachment_for_js($attachment_id);
$bytes = $attachment_meta['filesizeInBytes'];
$format = $attachment_meta['subtype'];
$formatb = block_value( 'format' );
if(empty($formatb)){
    $format = strtoupper($format);
} else {
    $format = $formatb;
}
$otherversion = block_field('other');

?>
        <div class="row push--top">
            <div class="col small-12">
                <h3 class="mega bold primary-color">
                <?php block_field( 'name' ); ?>
        </h3>
                <div class="beta editor push--ends">
            <p><?php block_field( 'description' ); ?></p>
        </div>        
        <div class="cf">
                <a class="btn btn--primary btn--icon push--bottom pull-right" href="<?php echo $url; ?>">
                    <?php block_field('buttontext'); ?>
                <span class="visuallyhidden"> - this will open / download a Media document</span>
                <span class="icon icon-download"></span>
                 </a>
        </div>
            </div>
        </div>
        <div class="row">
            <dl class="col-sm-12 col-md6 gutt contact__item">
                <dt class="contact__title">
                    Size
                </dt>
                <dd class="contact__desc">

                    <?php echo number_format($bytes); ?> bytes

                </dd>
            </dl>
            <dl class="col-sm-12 col-md6 gutt contact__item">
                <dt class="contact__title">
                    Language
                </dt>
                <dd class="contact__desc">
                <?php block_field( 'language' ); ?>
                </dd>
            </dl>
            <dl class="col-sm-12 col-md6 gutt contact__item">
                <dt class="contact__title">
                    Format
                </dt>
                <dd class="contact__desc">
                    <?php echo $format;?>
                </dd>
            </dl>
            <?php if(!empty($otherversion)) { ?>
            <dl class="col-sm-12 col-md6 gutt contact__item">
            <dt class="contact__title">
                    Other versions
            </dt>
            <dd class="contact__desc">
            <?php block_field('other'); ?>
            </dd>
            </dl>    
            <?php } ?>       
        </div>
    </div>
</div>