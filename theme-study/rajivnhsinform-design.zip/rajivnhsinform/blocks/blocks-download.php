<div class="genesis-custom-block <?php block_field('className'); ?>">
<h3><?php block_field('document-name' ); ?></h3>
<p><?php block_field('description'); ?></p>ss
</div>