<div class="genesis-custom-block <?php block_field('className'); ?>">
        <div class="iframe-Wrapper">
                <iframe class="responsive-iframe" src="https://www.youtube.com/embed/<?php block_field( 'youtube-id' ); ?>" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                </iframe>
        </div>       
</div>