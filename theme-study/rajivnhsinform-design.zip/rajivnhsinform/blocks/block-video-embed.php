<div class="genesis-custom-block <?php block_field('className'); ?>">
<div class="panel-component soft soft-half--top">
		<h3 class="block alpha bold push-half--bottom">
            <?php block_field( 'title' ); ?>
		</h3>
		<div class="videotext">
            <?php block_field( 'intro-text' ); ?>
		</div>
        <div class="iframe-Wrapper">
                <iframe class="responsive-iframe" src="https://www.youtube.com/embed/<?php block_field( 'youtube-video-id' ); ?>" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="">
                </iframe>
        </div>       
</div>
</div>