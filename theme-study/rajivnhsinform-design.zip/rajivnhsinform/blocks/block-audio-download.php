<div class="genesis-custom-block <?php block_field('className'); ?>">
        <div class="panel-component soft soft-half--top">
        <h3 class="block alpha bold push-half--bottom">
            <?php block_field('audio-title'); ?>
        </h3>
        <iframe width="<?php block_field('iframe-width'); ?>" height="<?php block_field('iframe-height'); ?>" src="<?php block_field('iframe-audio-url'); ?>"></iframe>
        <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
        <?php block_field('Link1'); ?> . <?php block_field('Link2'); ?>
        </div>
    </div>
</div>