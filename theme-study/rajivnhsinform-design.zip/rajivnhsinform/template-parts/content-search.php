<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nhsinform
 */

?>
<div class="col-lg-3 col-sm-12 mb-4 filter_tab">
 

    </div>
    <div class="col-lg-9 col-sm-12 mb-4 panel-content ">
        <div class="row">
            <div class="col-sm-12">
				<h1 class="push-half--bottom nhsuk-heading-m">
					<?php
						/* translators: %s: search query. */
						printf( esc_html__( 'Search Results for: %s', 'nhsinform' ), '<span>' . get_search_query() . '</span>' );
					?>
				</h1>
				<div class="js-tabs tabs tabs--search">

					<div class="tabs__nav">
						<a href="/search?tab=inform&amp;q=dentist&amp;locpt=55.378051%2C-3.435973" role="tab" class="tabs__nav-link js-tabs__link active" title="Click here to view NHS inform results.">
							  results found
				   	 	</a>
				   	 	<a href="/search?tab=nsd&amp;q=dentist&amp;locpt=55.378051%2C-3.435973" role="tab" class="tabs__nav-link js-tabs__link active" title="Click here to view SSD results.">
				   	 		View Services
				   	 	</a>
					</div>
					<div class="tabs__section active">

						<ol class="search__results" id="local-results">
				<?php
							/* Start the Loop */
							while ( have_posts() ) :
								the_post(); ?>
				<li class="search__item">
					<?php
						if ( is_singular() ) :
							the_title( '<h1 class="search__title nhsuk-heading-m">', '</h1>' );
						else :
							the_title( '<h2 class="search__title nhsuk-heading-m"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
						endif;
					?>
					<!-- <php the_excerpt(); ?> -->
						 <?php
$content = the_excerpt(); 
?>

				</li>
				<?php endwhile; ?>
				</ol>

				<?php the_posts_navigation();
?>

				</div>
			</div>
		</div>
    </div>
</div>
<style type="text/css">
	.tabs--search .tabs__nav-link.active {
	    border-color: #ccc;
	    border-bottom: 1px solid #fff;
	}
	.tabs--search .tabs__nav-link {
	    padding: 0 23px;
	    width: auto;
	}
	.tabs--search .tabs__nav-link {
    color: #03759b;
    font-weight: 700;
    float: left;
    margin: 0;
    padding: 0 12px;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    background: #fff;
    border-top: 1px solid #fff;
    border-left: 1px solid #fff;
    border-right: 1px solid #fff;
    border-bottom: 1px solid #ccc;
    z-index: 2;
}

.tabs--search .tabs__section {
    border: 1px solid #ccc;
    padding: 24px;
    -webkit-border-radius: 0 0 3px 3px;
    border-radius: 0 0 3px 3px;
    margin-top: -1px;
    z-index: 1;
}
.tabs--search .tabs__nav {
    position: relative;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar;
    z-index: 50;
    margin: 0;
    display: flex;
}
</style>
