<?php 
        $term       = get_queried_object(); 
        // print_r($term);
        // die();
        // $getSlug    = $term->slug;
        $getName    = $term->name;
        $getDescription    = $term->description;
        
    
        // $parent_id    = $term->parent;
        // if($parent_id == 362):
        // // server 362, local 359 
        //     get_template_part( 'template-parts/readysteadybaby', 'pregnancy' );
        // elseif($parent_id == 363) :
        // // server 36, local 360 

        // get_template_part( 'template-parts/readysteadybaby', 'labourbirth' );
        // else :
        // get_template_part( 'template-parts/readysteadybaby', 'earlyparenthood' );
        // endif;

        ?>



<!-- Pannel Wrapper Section HTML Start -->
<section class="pannel_wrapper microsite_wrapper birth">
        <div class="container">
            <div class="pannel_wrapper_container microsite_wrapper_container">
                <div class="row">
                    <div class="col-md-10">
                        <h1><?php echo $getName;?></h1>
                        <p><?php echo $getDescription;?></p>
                    </div>
                    <div class="col-md-2 d-none d-md-block d-lg-block">
                       <img src="<?php echo get_template_directory_uri();?>/assets/images/rsbicon2babe.png" alt="">
                    </div>
                </div>
                <div class="row">
                    

                    <?php

                    $term_Data  = get_queried_object();
                        $args = array(
                        'post_type' => 'ready-steady-baby',
                        'posts_per_page' => -1,
                        'orderby' => 'title',
                        'order'   => 'ASC',
                        'tax_query' => array(             
                            array(
                                'taxonomy' => 'ready_categories',
                                'field' => 'slug',
                                'terms' =>  $term_Data->slug,
                            ),
                        )
                    );

                    $query = new WP_Query($args);
                    if($query->have_posts()){
                    while($query->have_posts()){
                        $query->the_post(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo esc_url( get_permalink()); ?>" class="pannel_module">
                            <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                                <?php the_excerpt();?>
                            </a>
                        </div>
                    <?php
                        }
                    }
                    wp_reset_postdata();
                    ?>


                    <!-- <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Ectopic pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>When a fertilised egg develops outside the womb</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Health conditions before pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>Managing pre-existing health conditions during pregnancy</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Health conditions that develop during pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>Managing health conditions that develop during pregnancy</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Miscarriage <i class="fa-solid fa-angle-right"></i></h3>
                            <p>When you lose your baby before 24 weeks</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Pre-eclampsia <i class="fa-solid fa-angle-right"></i></h3>
                            <p>A complication of pregnancy that primarily affects your blood pressure</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>When pregnancy goes wrong <i class="fa-solid fa-angle-right"></i></h3>
                            <p>What can cause the loss of a baby and where to get support if this happens to you</p>
                        </a>
                    </div> -->
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Wrapper Section HTML Start -->