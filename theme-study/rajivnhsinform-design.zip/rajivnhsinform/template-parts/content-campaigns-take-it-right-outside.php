<div class="take-it-right-ids">
<?php if(get_field('campaign_introduction')):?>
    <div class="nhsuk-section nhssf-content-section bg-grey padding-48">
        <div class="container">
            <div class="row row1">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                            <h2><?php the_field('campaign_introduction');?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif;?>

<?php if(have_rows('content_list') ):?>
    <?php $i= 1;
        while(have_rows('content_list')): the_row();?>
        <div class="nhsuk-section nhssf-content-section<?php echo ($i%2==0) ? ' bg-grey':'';?>">
            <div class="container">
                <div class="row row1">
                    <div class="col-sm-12 section__content">
                        <div class="nhsuk-u-reading-width">
                                <?php if(get_sub_field('heading')):?>
                                   <h2><?php the_sub_field('heading');?></h2>
                                <?php endif;?>
                                    <div class="editor">
                                    <?php if(get_sub_field('content_image')):
                                      $getImage = get_sub_field('content_image');
                                    ?>
                                    <p style="margin-bottom: -31px;"><img src="<?php echo $getImage['url'];?>" alt="<?php echo $getImage['alt'];?>" alt="<?php echo $getImage['title'];?>" width="100%"></p>
                                <?php endif;?>       
                                <?php if(get_sub_field('content')): ?>
                                    <div class="panel-component push--ends" style="border-top: 2px solid #004785; background-color: #e6e6e6;">
                                    <div class="editor">
                                        <?php the_sub_field('content');?>
                                    </div>
                                   <?php if(get_sub_field('button_text') && get_sub_field('button_url')): ?> 
                                      <a href="<?php echo home_url(get_sub_field('button_url'));?>" class="btn btn--primary btn--icon push--ends pull-right">
                                        <?php the_sub_field('button_text');?>
                                        <span class="icon">
                                            <i class="fa fa-chevron-right f-8" style="font-size: 0.8rem; padding: 8px"></i>
                                        </span>
                                     </a>
                                    <?php endif;?>
                                </div>
                            <?php endif;?>
                             </div>

                             <?php if(get_sub_field('video_title') || get_sub_field('video_url')):?>
                                <div class="panel-component soft soft-half--top">
                                    <h3 class="block alpha bold push-half--bottom">
                                        <?php the_sub_field('video_title');?>
                                        <!-- <a class="print-only delta" href="https://www.youtube.com/watch?v=OJaNZcgcvVc"></a> -->
                                    </h3>
                                    <div class="editor"></div>
                                    <?php if(get_sub_field('video_url')){ ?>
                                    <div class="iframe-Wrapper">
                                        <iframe class="responsive-iframe" src="<?php echo get_sub_field('video_url');?>" title="Second Hand Smoke Lingering Video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" id="ytplayer-OJaNZcgcvVc" data-gtm-yt-inspected-7="true"></iframe>
                                     </div>
                                 <?php } ?>
                                </div>
                               <?php endif;?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $i++; endwhile;?>
 <?php endif;?>
</div>
    <!-- <div class="nhsuk-section nhssf-content-section bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                        <h2>It moves</h2>
                <div class="editor">
                <p style="margin-bottom: -31px;"><img src="./images/room-dining.jpg" alt="" width="100%"></p>
            <div class="panel-component push--ends" style="border-top: 2px solid #004785; background-color: #e6e6e6;">
            <div class="editor">
            <p>The harmful chemicals creep from room to room, waiting for your child to breathe them in.</p>
            <ul>
            <li>Second-hand smoke contains more than 4,000 toxic chemicals. The particles are smaller than dust and drift easily as you move through the house and open doors.</li>
            <li>Smoking near or leaning out of an open window doesn’t protect your family. Second-hand smoke drifts all through your house. Wherever your child is, they’ll breathe in the harmful chemicals.</li>
            <li>Children inhale twice as much household dust as adults because they breathe faster. They will breathe more of the toxic chemicals in your second-hand smoke.</li>
            </ul>
            </div>
            <a href="/healthy-living/stopping-smoking/reasons-to-stop/second-hand-smoke" target="_blank" class="btn btn--primary btn--icon push--ends pull-right">Know the facts about second-hand smoke <span class="icon">
                <i class="fa fa-chevron-right f-8" style="font-size: 0.8rem; padding: 8px"></i>
            </span> </a></div>
            </div>

                  <div class="panel-component soft soft-half--top">
                        <h3 class="block alpha bold push-half--bottom">
                            Is it ever ok for you to smoke indoors?
                            <a class="print-only delta" href="https://www.youtube.com/watch?v=OJaNZcgcvVc"></a>
                        </h3>
                        <div class="editor">
                        </div>
                        <div class="iframe-Wrapper">
                            <iframe class="responsive-iframe" src="https://www.youtube.com/embed/OJaNZcgcvVc?rel=0&amp;showinfo=0&amp;enablejsapi=1&amp;origin=https:%2F%2Fwww.nhsinform.scot" title="Second Hand Smoke Lingering Video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" id="ytplayer-OJaNZcgcvVc" data-gtm-yt-inspected-7="true"></iframe>
                 </div>
                </div> 

               </div>
            </div>
        </div>
    </div>
</div> -->

<!--<div class="nhsuk-section nhssf-content-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                            <h2>
                                It lingers
                            </h2>
<div class="editor">
    <p style="margin-bottom: -31px;"><img src="./images/room-living.jpg" alt="" width="100%"></p>
<div class="panel-component push--ends" style="border-top: 2px solid #004785; background-color: #e6e6e6;">
<div class="editor">
<p>Second-hand smoke lingers for up to 5 hours after your last cigarette.</p>
<ul>
<li>Even if you smoke when they're at school or out playing, second-hand smoke will still be around, waiting for your kids to breathe it in when they get home.</li>
<li>Candles, air fresheners and purifiers might hide the smell of smoke, but they can't get rid of the harmful toxins.</li>
<li>Second-hand smoke can trigger an asthma attack. In children who have asthma already, it can make attacks more severe, and more frequent.</li>
<li>Ask someone you trust to watch the kids for 5 minutes while you pop out for a cigarette. You could return the favour.</li>
</ul>
</div>
<a href="/self-help-guides/second-hand-smoke-your-smoke-free-tips" target="_blank" class="btn btn--primary btn--icon push--ends pull-right">Find out how to make your home smoke-free
    <span class="icon">
        <i class="fa fa-chevron-right f-8" style="font-size: 0.8rem; padding: 8px"></i>
</span>
 </a></div>
</div>
</div>
                </div>
            </div>
        </div>
    </div>

    <div class="nhsuk-section nhssf-content-section bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                            <h2>
                                It puts kids at risk
                            </h2>
<div class="editor">
    <p style="margin-bottom: -31px;"><img src="./images/room-hallway.jpg" alt="" width="100%"></p>
<div class="panel-component push--ends" style="border-top: 2px solid #004785; background-color: #e6e6e6;">
<div class="editor">
<p>Kids breathe faster than adults.</p>
<ul>
<li>Children are especially vulnerable to the toxins in second-hand smoke because their airways are smaller and they breathe faster.</li>
<li>Children of all ages are at risk because their lungs and immune systems aren't fully developed until they are teenagers.</li>
<li>Could you put your shoes and umbrella by the door? And find somewhere comfortable to smoke outside?</li>
</ul>
</div>
<a href="/healthy-living/stopping-smoking/reasons-to-stop/second-hand-smoke" target="_blank" class="btn btn--primary btn--icon push--ends pull-right">Know the facts about second-hand smoke <span class="icon">
    <i class="fa fa-chevron-right f-8" style="font-size: 0.8rem; padding: 8px"></i>
</span> </a></div>
</div>



                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="nhsuk-section nhssf-content-section ">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                            <h2>
                                Kids breathe faster
                            </h2>
<div class="editor">
    <p style="margin-bottom: -31px;"><img src="./images/room-bed.jpg" alt="" width="100%"></p>
<div class="panel-component push--ends" style="border-top: 2px solid #004785; background-color: #e6e6e6;">
<div class="editor">
<p>Because your child breathes faster than you, they’ll breathe more of those harmful chemicals.</p>
<ul>
<li>No matter what you do, if you smoke indoors, the harmful chemicals from your second-hand smoke will hang around for hours doing real harm to your kids and increasing their risk of illness.</li>
<li>Don't let anyone smoke indoors, ask them to go outside, and tell them you're keeping your home smoke-free for your kids.</li>
<li>You can choose whether your child breathes second-hand smoke or clean air.</li>
</ul>
</div>
<a href="/healthy-living/stopping-smoking/reasons-to-stop/second-hand-smoke" target="_blank" class="btn btn--primary btn--icon push--ends pull-right">Know the facts about second-hand smoke 
    <span class="icon">
        <i class="fa fa-chevron-right f-8" style="font-size: 0.8rem; padding: 8px"></i>
    </span>
</a></div>
</div>
 </div>
    </div>
    </div>
    </div>
    </div>-->

<?php if(get_field('bottom_content_title') || get_field('bottom_content_heading') || get_field('bottom_content_summary') || get_field('bottom_video_url') || get_field('bottom_content')):?>
<div class="nhsuk-section nhssf-content-section  bg-grey">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 section__content">
                <div class="nhsuk-u-reading-width">
                <h2><?php the_field('bottom_content_title');?></h2>
        <div class="panel-component soft soft-half--top">
            <h3 class="block alpha bold push-half--bottom">
               <?php the_field('bottom_content_heading');?>
            </h3>
            <div class="editor">
                <p><?php the_field('bottom_content_summary');?></p>
            </div>
            
            <?php if(get_field('bottom_video_url')){ ?>
                <div class="iframe-Wrapper">
                    <iframe class="responsive-iframe" src="<?php echo get_field('bottom_video_url');?>" title="Scottish Government Smoking in Cars TV Ad (2016)" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" id="ytplayer-OJaNZcgcvVc" data-gtm-yt-inspected-7="true"></iframe>
                 </div>
            <?php } ?> 
        </div>
        <?php if(get_field('bottom_content')){ ?>
        <div class="editor">
            <?php the_field('bottom_content');?>
            
        </div>
    <?php } ?> 
    </div>
</div>
</div>
</div>
</div>
<?php endif;?>