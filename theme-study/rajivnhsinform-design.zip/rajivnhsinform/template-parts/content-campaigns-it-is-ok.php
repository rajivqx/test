<div class="its-ok-ids">
<?php if(get_field('campaign_introduction')):?>
    <div class="nhsuk-section nhssf-content-section bg-grey padding-48">
        <div class="container">
            <div class="row row1">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                            <h2>
                                <?php the_field('campaign_introduction');?>
                            </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif;?>
<?php if(have_rows('asking_questions_list')):?>
<div class="nhsuk-section nhssf-content-section">
<div class="container">
    <div class="row row1">
        <div class="col-sm-12 section__content">
    <?php 
    $i=1;
    while(have_rows('asking_questions_list')): the_row();
    if($i==1){ ?>
        <div class="nhsuk-u-reading-width">
        <h2><?php the_sub_field('heading');?></h2>
        <div class="editor">
            <?php the_sub_field('content');?>
        </div>
     <?php }else{
       if(get_sub_field('heading')){ ?> 
        <div class="nhsuk-warning-callout">
            <h3 class="nhsuk-warning-callout__label"><?php the_sub_field('heading');?></h3>
            <?php the_sub_field('content');?>
        </div>
        <?php }else{ ?>
         <div class="editor">
             <?php the_sub_field('content');?>
        </div>
       <?php } ?>
    <?php } $i++;endwhile;?>

            </div>
        </div>
    </div>
</div>
</div>

<?php endif;?>

<?php if(have_rows('appointment_section_content')):?>
<div class="nhsuk-section nhssf-content-section bg-grey">
<div class="container">
<div class="row row1">
    <div class="col-sm-12 section__content">
        <div class="nhsuk-u-reading-width">
         <?php $j=1;
            while(have_rows('appointment_section_content')): the_row();
            if($j==1){ ?>
            <?php if(get_sub_field('heading')): ?>    
                <h2><?php the_sub_field('heading');?></h2>
           <?php endif;?>
            <div class="editor">
                <p><?php the_sub_field('content');?></p>
            </div>
        <?php }; $j++;endwhile;?>    
               
    <div class="panel-component soft">
        <div class="row row1 push--top">
            <div class="col-sm-12 p-4">
            <?php $j=1;
            while(have_rows('appointment_section_content')): the_row();
            if($j==2){ ?>
                <h3 class="mega bold primary-color">
                <?php the_sub_field('heading');?></h3>
            <div class="beta editor push--ends">
                <?php the_sub_field('content');?>
            </div> 
            <?php }; $j++;endwhile;?> 

            <?php 
            if(get_field('button_text') && get_field('download_file')){ ?> 
             <div class="cf">
                <a class="btn btn--primary btn--icon push--bottom pull-right" href="<?php echo get_field('download_file');?>"><?php echo get_field('button_text');?>
                    <span class="visuallyhidden"> - This will open / download a Media document</span>
                    <span class="icon">
                        <i class="fa fa-download" aria-hidden="true"></i>
                    </span>
                </a>
             </div>
            <?php } ?>
        </div>

        </div>


        <?php if(have_rows('download_item_list')):?>
            <div class="row row1">
                <?php 
                while(have_rows('download_item_list')): the_row();?>
                <dl class="col-sm-12 col-md-6 contact__item p-4">
                    <dt class="contact__title">
                        <?php echo get_sub_field('title');?>
                    </dt>
                    <dd class="contact__desc">
                        <?php echo get_sub_field('description');?>
                    </dd>
                </dl>
                <?php endwhile;?>
            </div>
        <?php endif;?>   

    </div> 
        <?php if(get_field('video_heading') && get_field('video_url')): ?> 
        <details class="nhsuk-details">
            <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-0" aria-expanded="false">
                <span class="nhsuk-details__summary-text">
                    <?php the_field('video_heading');?>
                </span>
            </summary>
            <div class="nhsuk-details__text" id="details-content-0" aria-hidden="true">
                   <div class="iframe-Wrapper">
                    <p><iframe class="responsive-iframe" src="<?php echo get_field('video_url');?>" title="<?php echo get_field('video_title');?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" data-gtm-yt-inspected-7="true"></iframe>
                    </p>
                   </div>
            </div>
        </details>
        <?php endif;?> 

    </div>
    </div>
</div>
</div>
</div>
<?php endif;?>

 <?php if(get_field('other_language_heading') || get_field('other_language_list')):?> 
    <div class="nhsuk-section nhssf-content-section padding-48">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                        <?php if(get_field('other_language_heading')):?>
                            <h2>
                                <?php the_field('other_language_heading');?>
                            </h2>
                        <?php endif;?>
                        <div class="editor">
                            <?php the_field('other_language_list');?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif;?>

<?php if(get_field('important_information_heading') || get_field('important_information_content') || have_rows('important_information_download_list')):?> 

<div class="nhsuk-section nhssf-content-section bg-grey">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 section__content">
                <div class="nhsuk-u-reading-width">
                    <?php if(get_field('important_information_heading')):?>
                        <h2><?php the_field('important_information_heading');?></h2>
                     <?php endif;?>   
    <div class="editor">
        <?php the_field('important_information_content');?>
    </div>
 <?php while(have_rows('important_information_download_list')): the_row();?>
    <div class="panel-component soft">
        <div class="row push--top">
            <div class="col-sm-12">

            <?php if(get_sub_field('download_heading')):?>
            <h3 class="mega bold primary-color">
                <?php the_sub_field('download_heading');?>
            </h3>
            <?php endif;?>
        <div class="beta editor push--ends">
            
        </div> 

        <?php if(get_sub_field('download_button_text') && get_sub_field('download_button_url')):?> 
        <div class="cf">
                    <a class="btn btn--primary btn--icon push--bottom pull-right" href="<?php echo get_sub_field('download_button_url');?>">
                <?php the_sub_field('download_button_text');?>
                <span class="visuallyhidden"> - this will open / download a Media document</span>
                  <span class="icon">
                        <i class="fa fa-download" aria-hidden="true"></i>
                        
                    </span>
            </a>
        </div>
         <?php endif;?>
        </div>
    </div>
    
        <?php if(have_rows('download_information_list')):?>
        <div class="row">
         <?php while(have_rows('download_information_list')): the_row();?>
            <dl class="col col-sm-12 col-md-6 contact__item">
                <dt class="contact__title">
                    <?php the_sub_field('title');?>
                </dt>
                <dd class="contact__desc">
                    <?php the_sub_field('content');?>
                </dd>
            </dl>
        <?php endwhile;?>
        </div>
       <?php endif;?>
    </div>
  <?php endwhile;?>             
      </div>
        </div>
    </div>
</div>
</div>
<?php endif;?>

<?php if(get_field('important_information_other_languages_heading') && get_field('important_information_other_languages_content')):?> 
<div class="nhsuk-section nhssf-content-section">
<div class="container">
<div class="row">
<div class="col-sm-12 section__content">
    <div class="nhsuk-u-reading-width">
        <?php if(get_field('important_information_other_languages_heading')):?>
            <h2><?php the_field('important_information_other_languages_heading');?></h2>
        <?php endif;?>
            <div class="editor">
                <?php the_field('important_information_other_languages_content');?>
            </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php endif;?>

<?php if(get_field('campaign_resources_heading') && get_field('campaign_resources_content')):?> 
<div class="nhsuk-section nhssf-content-section bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 section__content">
                    <div class="nhsuk-u-reading-width">
                <?php if(get_field('campaign_resources_heading')):?>        
                     <h2><?php the_field('campaign_resources_heading');?></h2>
                <?php endif;?>     
                <div class="editor">
                   <?php the_field('campaign_resources_content');?>
                </div>
                 </div>
                </div>
            </div>
        </div>
    </div>
  <?php endif;?>
</div>
