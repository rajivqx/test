<!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
               <div class="row">
                <?php
                    //$custom_terms = get_terms('illness_type');
                	$term_Data  = get_queried_object();
                        $args = array(
                        'post_type' => 'tests-and-treatments',
                        'posts_per_page' => -1,
                        'orderby'           =>  'name',
                        'order'             =>  'ASC',
                        'tax_query' => array(             
                            array(
                                'taxonomy' => 'tests',
                                'field' => 'slug',
                                'terms' =>  $term_Data->slug, // or the category name e.g. Germany
                            ),
                        )
                    );
 
                    $query = new WP_Query($args);
                    if($query->have_posts()){
                    while($query->have_posts()){
                        $query->the_post(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo esc_url( get_permalink()); ?>" class="pannel_module">
                            <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                                <?php the_excerpt();?>
                            </a>
                        </div>
                    <?php
                        }
                    }
                    wp_reset_postdata();
                    ?>
                    
                </div>
            </div>
        </div>
    </section>