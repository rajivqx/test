<!-- Pannel Wrapper Section HTML Start -->
<section class="pannel_wrapper">
  <div class="container">
    <div class="pannel_wrapper_container">
      <div class="row">
      <?php
            $term_Data  = get_queried_object(); 
            $term_id = $term_Data->term_id;
            $taxonomy_name = $term_Data->slug;
            //$custom_terms = get_terms('illness_type');
            $args = array(
                'post_type' => 'healthy-living',
                'posts_per_page' => -1,
                'tax_query' => array(             
                    array(
                        'taxonomy' => 'health_type',
                        'field' => 'slug',
                        'terms' =>  $term_Data->slug, // or the category name e.g. Germany
						'include_children' => false
                    ),
                )
            );

        $query = new WP_Query($args);
        if($query->have_posts()){
        while($query->have_posts()){
          
         $query->the_post();
         if(get_field('redirect_to_content',get_the_ID())){
          $get_permalink = get_field('redirect_to_content',get_the_ID());
          $get_permalink = home_url($get_permalink);
          }  else{
          $get_permalink = get_the_permalink();
          }
         ?>

        <div class="col-lg-4 col-md-6 col-sm-12">
          <a href="<?php echo $get_permalink;?>"
            class="pannel_module panel-min-130 panel-min-130">
            <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                <?php the_excerpt();?>
          </a>
        </div>
         <?php
                }
                wp_reset_postdata();
            }

            //$term_id = 10;
            $taxonomy_name = 'health_type';
            $termchildren = get_term_children( $term_id, $taxonomy_name);
            foreach($termchildren as $child){
                $term = get_term_by( 'id', $child,$taxonomy_name);

            //echo '<li><a href="' . get_term_link( $child, $taxonomy_name ) . '">' . $term->name . '</a></li>';
            ?>

        <div class="col-sm-12 mb-0">
          <div class="panel-display">
            <h2 class="panel-text"><?php echo $term->name;?></h2>
          </div>
        </div>
        <?php 
                $args2 = array(
                    'post_type' => 'healthy-living',
                    'posts_per_page' => -1,
                    'tax_query' => array(             
                        array(
                            'taxonomy' => 'health_type',
                            'field' => 'slug',
                            'terms' =>  $term->slug, // or the category name e.g. Germany
                        ),
                    )
                );

            $query2 = new WP_Query($args2);
            if($query2->have_posts()){
            while($query2->have_posts()){
                $query2->the_post(); 
                if(get_field('redirect_to_content',get_the_ID())){
                $get_permalink = get_field('redirect_to_content',get_the_ID());
                $get_permalink = home_url($get_permalink);
                }  else{
                $get_permalink = get_the_permalink();
                }
                ?>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <a href="<?php echo $get_permalink;?>" class="pannel_module panel-min-130">
            <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i>
            </h3>
            <?php the_excerpt();?>
          </a>
        </div>
        <?php  }
              wp_reset_postdata();
            }    
          } 
    ?> 
      </div>
    </div>
  </div>
</section>
<!-- Pannel Wrapper Section HTML Start -->
