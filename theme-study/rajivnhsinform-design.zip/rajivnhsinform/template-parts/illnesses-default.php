<!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
               <div class="row">
                <?php
                    //$custom_terms = get_terms('illness_type');
                	$term_Data  = get_queried_object();
                        $args = array(
                        'post_type' => 'illnesses',
                        'posts_per_page' => -1,
                        'tax_query' => array(             
                            array(
                                'taxonomy' => 'illness_type',
                                'field' => 'slug',
                                'terms' =>  $term_Data->slug, // or the category name e.g. Germany
                            ),
                        )
                    );

                    $query = new WP_Query($args);
                    if($query->have_posts()){
                    while($query->have_posts()){
                        $query->the_post(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo esc_url( get_permalink()); ?>" class="pannel_module">
                            <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                                <?php the_excerpt();?>
                            </a>
                        </div>
                    <?php
                        }
                    }
                    wp_reset_postdata();
                    ?>

                    <?php if($term_Data->slug == 'mental-health'){?>
                        <div class="col-sm-12 mb-0" id="mental-health-self-help-guides">
                          <div class="panel-display">
                            <h2 class="panel-text"> Mental health self-help guides</h2>
                          </div>
                        </div>

                          <?php 
                            $args = array(
                                'post_type' => 'mental-health-shg',
                                'posts_per_page'   => -1,
                                'post_status' =>'publish'

                            );
                            $mental_query = new WP_Query( $args );?>

                             <?php if ( $mental_query->have_posts() ) {
                        while ( $mental_query->have_posts() ) {
                            $mental_query->the_post();
                            $short_description = get_field('subtext', $mental_query->post->ID );
                        ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo get_the_permalink($mental_query->post->ID);?>" class="pannel_module">
                    <h3> <?php echo get_the_title($mental_query->post->ID);?> <i class="fa-solid fa-angle-right"></i></h3>
                        <?php if(!empty($short_description)){
                            echo '<p>'.$short_description.'</p>';
                        } ?>
                        </a>
                    </div>
                <?php } }?>

                    <?php } ?>
                    
                </div>
            </div>
        </div>
    </section>