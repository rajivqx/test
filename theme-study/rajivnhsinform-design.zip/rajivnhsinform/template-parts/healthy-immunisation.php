<!-- Pannel Wrapper Section HTML Start -->
<section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                     
              <?php
                       $terms = get_terms( 'health_type', array( 'parent' => '70','hide_empty' => false ) );
                       foreach($terms as $term) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                    <a href="<?php echo get_term_link( $term->slug, 'health_type' );?>" class="pannel_module">
                      <h3><?php echo $term->name;?> <i class="fa-solid fa-angle-right"></i></h3>
                        <p><?php echo get_field('summary',$term->taxonomy.'_'.$term->term_id);?></p> 
                       </a>
                       </div>
                       <?php } ?>
                       <div class="col-lg-4 col-md-6 col-sm-12">
                      <a href="<?php echo get_permalink('7432'); ?>" class="pannel_module">
                      <h3>Your data and personal information <i class="fa-solid fa-angle-right"></i></h3>
                    <p>How your immunisation data is collected, used and protected</p> 
                    </a>
                     </div>   
               
                    
  </div>
    </div>
  </div>
</section>
<!-- Pannel Wrapper Section HTML Start -->
