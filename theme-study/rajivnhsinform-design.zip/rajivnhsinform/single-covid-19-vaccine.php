<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();?>
    <!-- Symptoms Section HTML Start -->
    <div class="bg-white-grey soft--bottom">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                      <!-- Breadcrumb HTML Start -->
                        <?php get_sidebar('breadcrumb');?>
                        <!-- Breadcrumb HTML End -->
                </div>
                <div class="col-lg-9 col-sm-12 mb-4 panel-content guidetabs">
                    <!-- <div class="wrapperNHS panel-content push--bottom push--top"> -->
                    <div class="row">
                        <div class="col col-sm-12">
                            <h1 class="giga bold primary-color push--bottom">
                                <?php the_title();?>
                            </h1>
                        </div>

    <div class="col-sm-12">
      <?php 
        while(have_posts()): the_post();?>
            <?php the_content(); 
                if(comments_open() || get_comments_number()) :
        			//comments_template();
        		endif;?>
        <?php endwhile;?>

    </div>

    <div class="col-sm-12 col-lg-9 soft--ends">

    <?php if(get_field('attribution_logo')):
        $attribution_logo = get_field('attribution_logo'); 
        $imageID  = attachment_url_to_postid($attribution_logo);
        $imageData = wp_get_attachment($imageID);
    ?>
    <div class="row">
        <div class="col-sm-12 soft bg-light-grey-1">
             <img src="<?php echo $attribution_logo;?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
             <?php if(get_field('attributed_to') && get_field('attributed_url')):?>
                 <p class="nhsuk-body-s no-margin">
                    Source:
                     <a href="<?php echo get_field('attributed_url');?>" class="bold" rel="external" target="_blank"><?php the_field('attributed_to');?> <span class="visuallyhidden">- Opens in new browser window</span></a>
                </p>
             <?php endif;?>
        </div>
    </div>
    <?php endif;?>

    <div class="push--ends">
        <p class="nhsuk-body-s nhsuk-u-secondary-text-color no-margin">
            Last updated:
            <br>
            <?php  the_modified_date('d F Y'); ?>
        </p>
    </div>
        <?php get_sidebar('breadcrumb-bottom');?>
            <?php
                if(get_field('feedback_disabled')[0] !="yes"){
                        get_sidebar('feedback-form'); 
                } 

            ?>
      </div>
    </div>
    </div>
    <div class="col-lg-3 col-sm-12 mb-4">
         <?php get_sidebar();?>
    </div>(
      </div>
    
    </div>
    </div>
    <?php
    get_footer();
    get_sidebar('feedback_js');
    ?>
    
    
