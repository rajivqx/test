<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nhsinform
 */

?>

 <?php if(@get_field('disable_info_for_me')[0] !="yes"){ ?>
    <?= add_sidebar_info(); ?>
    <?php } ?>
    <?php if(have_rows('links1') || have_rows('links')):?>
    <div class="panel-content panel-content--half push--bottom">

    <?php if(have_rows('links1')):?>
        <div class="push--bottom">
        <h3 class="gamma bold primary-color push-half--bottom">
            Also on NHS inform
        </h3>
        <div class="overline bg-primary-color push-half--ends"></div>
            <ul class="nhsuk-list list-style-none">
                <?php while(have_rows('links1')): the_row();?>
                  <li>
                    <?php
                    $related_link1 = get_sub_field('related_link1');
                    if($related_link1){ ?>
                       <a href="<?php echo $related_link1->permalink;?>" target="_self">
                        <?php echo $related_link1->post_title;?>
                      </a>
                    <?php }else{ ?>
                        <a href="<?php echo site_url(get_sub_field('related_link2'));?>" target="_self"><?php the_sub_field('related_link_name');?>
                      </a>
                   <?php } ?>
                  </li>
                <?php endwhile;?>   
            </ul>
        </div>
    <?php endif;?>
    <?php if(have_rows('links')):?>
        <div class="push--bottom">
            <h3 class="gamma bold primary-color push-half--bottom">
                Other health sites
            </h3>
            <div class="overline bg-primary-color push-half--ends"></div>
                <ul class="nhsuk-list list-style-none">
                  <?php while(have_rows('links')): the_row();?>
                      <li>
                           <a href="<?php echo get_sub_field('related_link');?>" target="_self"><?php the_sub_field('related_link_name');?></a>
                      </li>
                  <?php endwhile;?>
                </ul>
        </div>
     <?php endif;?>

</div>
<?php endif;?>
<?php if(get_field('web_chat_disabled')[0] !="yes"){ ?>
    <div class="panel-content panel-content--half push--bottom text-center pc-alter">
        <button class="btn--clean border-none" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
            <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
        </button>
    </div>
<?php } ?>


<?php if(get_field('hide_from_search')[0] !="yes"): ?>
<div class="panel-component">
    <?php 
        $search_status = get_field('search_status'); 
            if (isset($search_status) && !empty($search_status) && $search_status == 'Yes'): 
            $service_name = get_field('service_name');
            $search_header = get_field('search_header');
            $search_filter_code = get_field('search_filter_code');
            if (!empty($search_filter_code)) {
                 $filter = $search_filter_code;
            }else{
                $filter = null;
            }
            $url =strtolower($service_name);
            $url = str_replace('&','',$url);
            $url = str_replace(' ','-',$url);
            $main_url = home_url('scotlands-service-directory').'/'.$url;
        ?>
        <div class="ssd_search-form">
        <h3 class="bold push--bottom"><?= $search_header ?></h3>
        <label>Enter a place or postcode</label>
            
        <?php  add_search_from($main_url,$filter); ?>
        </div>
    <?php endif; ?>
    <!-- <form class="search-results form relative js-location" action="/scotlands-service-directory/health-and-wellbeing-services/" method="GET">
        <input type="hidden" name="locpt" id="locpt" class="js-locpt" value="">
        <input type="hidden" name="svctype" id="svctype" value="04">
        <label class="beta" for="q">Enter a place or postcode</label>
        <div class="relative">
            <input id="q" name="q" class="search-results__input search-results__input-geo js-geolocation__input" aria-autocomplete="list" type="search" autocomplete="off">
            <button type="button" class="search-results__geo js-geolocation">
                <span class="visuallyhidden">Near me</span>
                <span class="icon-location"></span>
            </button>
            <button type="submit" class="search-results__submit btn btn--green">
                <span class="visuallyhidden">Search Place / Postcode</span>
                <i class="fa fa-search"></i>
            </button>
        </div>
    </form> -->
</div>
<?php endif;?>