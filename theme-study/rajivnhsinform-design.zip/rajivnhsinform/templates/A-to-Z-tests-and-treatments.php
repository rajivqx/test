<?php 
/* 
Template Name: A To Z Tests And Treatments
*/
get_header(); ?>
 <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->
    <!-- Breadcrumb HTML Start -->
    <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->

    <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
        <?php if(have_posts()): 
            while(have_posts()): the_post(); ?>
                <h1><?php the_title();?></h1>
                    <?php the_content();?>
            <?php endwhile; ?>
            <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Pannel Intro Section HTML End -->
    <?php if(have_rows('a_to_z_list')):?>
    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <?php 
                 $aToVAl = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
                    while(have_rows('a_to_z_list')): the_row();
                       $posts_array[] = strtolower(get_sub_field('heading'));
                    endwhile; 
                    array_unique($posts_array);
                ?>
                <!-- A to Z listing Start-->
                <ul class="a_z_listing">
             <?php 
                foreach($aToVAl as $az){ 
                    if(in_array(strtolower($az),$posts_array)){ ?>
                     <li><a class="list_<?php echo strtolower($az);?>" href="#<?php echo strtoupper($az);?>"><?php echo $az;?></a></li>
                    <?php }else{ ?>
                        <li><a><?php echo $az;?></a></li>
                    <?php } ?>                            
                                    
                    <?php } ?>
                </ul>

                <!-- A to Z listing End-->
            <?php while(have_rows('a_to_z_list')): the_row(); ?>
                 <?php
                    $pages = get_sub_field('pages');
                    if($pages):?>
                <!-- A to Z listing Detail Indivisual Start-->
                <div class="az_list_indivisual <?php echo strtolower(get_sub_field('heading'));?>_detail">
                    <h2><?php echo strtoupper(get_sub_field('heading'));?></h2>
                    <ul>
                       <?php foreach($pages as $post): setup_postdata($post);?>
                            <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
                        <?php endforeach; wp_reset_postdata();?>
                    </ul>
                    <button type="button" class="back_top_button">
                        <i class="fa-solid fa-angle-up"></i> Back to top</button>
                <?php endif;?>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>
    <!-- Pannel Wrapper Section HTML Start -->
  <?php endif;?>
<?php get_footer(); ?>