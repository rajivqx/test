<?php 
/* 
Template Name: Home Page
*/
get_header();?>
<!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->
  <?php if( get_field('banner_section_image_url') || get_field('banner_section_title') || get_field('banner_section_content')): ?>
    <!--Banner Section HTML Start-->
   <div class="mainHomePage">
    <section class="nhsuk-hero nhsuk-hero--image nhsuk-hero--image-description"
        style="background-image: url('<?php echo get_field('banner_section_image_url');?>');">
        <?php if(get_field('banner_section_title') || get_field('banner_section_content')): ?>
        <div class="nhsuk-hero__overlay">
            <div class="container"> 
                <div class="nhsuk-hero-content nhsuk-hero-content--blue">
                    <h1><?php the_field('banner_section_title'); ?></h1>
                    <p><?php the_field('banner_section_content'); ?></p>
                    <span class="nhsuk-hero__arrow nhsuk-hero-content--blue" aria-hidden="true"></span>
                </div>
            </div>
        </div>
        <?php endif;?>
    </section>
    <!--Banner Section HTML End-->
    <?php endif; ?>
<?php if(have_rows('two_column_content_section')):?>
    <!-- Symptoms Section HTML Start -->
    <section class="symptoms_section">
        <div class="container">
            <div class="row">
            <?php 
            while(have_rows('two_column_content_section')): the_row();?>
                <div class="col-md-6">
                    <h2><?php the_sub_field('content_title');?></h2>
                    <p><?php the_sub_field('content');?></p>
            <?php  if( get_sub_field('button_url') && get_sub_field('button_text')): ?>
                    <a class="nhsuk-action-link__link" target="_self" href="<?php the_sub_field('button_url');?>">
                        <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M0 0h24v24H0z" fill="none"></path>
                            <path
                                d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z">
                            </path>
                        </svg>
                        <span class="nhsuk-action-link__text">
                            <?php the_sub_field('button_text');?>
                        </span>
                    </a>
            <?php endif;?>        
                </div>
            <?php endwhile;?>    
            </div>
        </div>
    </section>
    <!-- Symptoms Section HTML End -->
    <?php endif;?>
    <?php if(have_rows('left_service_list') || have_rows('right_service_list')):?>
    <!-- Find the Service Section HTML Start -->
    <section class="find_service_section">
        <div class="container">
            <h2><?php the_field('services_content_title');?></h2>
            <div class="row">
                <?php if(have_rows('left_service_list')):?>
                    <div class="col-md-6">
                        <?php while(have_rows('left_service_list')): the_row();?>
                            <a href="<?php the_sub_field('service_url');?>" class="nhsuk-action-group__link">
                            <?php the_sub_field('service_title');?><i class="fa-solid fa-angle-right"></i></a>
                        <?php endwhile;?>    
                    </div>
                <?php endif;?>
                <?php if(have_rows('right_service_list')):?>
                    <div class="col-md-6">
                        <?php while(have_rows('right_service_list')): the_row();?>
                            <a href="<?php the_sub_field('service_url');?>" class="nhsuk-action-group__link">
                                <?php the_sub_field('service_title');?><i class="fa-solid fa-angle-right"></i></a>
                        <?php endwhile;?>    
                    </div>
                <?php endif;?>
            </div>
        </div>
    </section>
    <!-- Find the Service Section HTML End -->
    <?php endif;?>

    <?php if(have_rows('covid_content_list') || get_field('covid_section_title') || get_field('covid_section_content')):?>
    <!-- Corona Section HTML Start -->
    <section class="corona_section">
        <div class="container">
        <?php if(have_rows('coronavirus')):?>
            <div class="row">
                <?php while(have_rows('coronavirus')): the_row();?>
                <div class="col-md-6">
                     <h2><?php the_sub_field('covid_section_title');?></h2>
                    <?php the_sub_field('covid_section_content');?>
                       <?php if(have_rows('covid_content_list')):?>
                        <?php while(have_rows('covid_content_list')): the_row();?>
                          <a href="<?php the_sub_field('covid_link_url');?>" class="nhsuk-action-group__link"><?php the_sub_field('covid_link_text');?> <i class="fa-solid fa-angle-right"></i></a>
                       <?php endwhile;?>  
                    <?php endif;?> 
                </div>
                 <?php endwhile;?>  
            </div>
        <?php endif;?>    
        </div>
    </section>
    <!-- Corona Section HTML Start -->
    <?php endif;?>

<?php if(have_rows('bottom_two_column_section') ):?>
    <!-- Two Block Section HTML Start -->
    <section class="Two_block_section">
        <div class="container">
            <div class="row">
            <?php while(have_rows('bottom_two_column_section')): the_row();?>
                <div class="col-md-6">
                     <?php the_sub_field('two_column_section_content');?>
                    <div class="implinks">
                         <?php the_sub_field('two_column_section_action_links');?>
                    </div>

                <?php  if(get_sub_field('bottom_section_left_button_text') && get_sub_field('bottom_section_left_button_url')): ?>
                    <a class="nhsuk-action-link__link" target="_self" href="<?php echo get_sub_field('bottom_section_left_button_url');?>">
                        <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M0 0h24v24H0z" fill="none"></path>
                            <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z">
                            </path>
                        </svg>

                        <span class="nhsuk-action-link__text"> 
                            <?php the_sub_field('bottom_section_left_button_text');?>
                        </span>
                    </a>
                   <?php endif;?> 
                </div>
               <?php endwhile;?>

            </div>
        </div>
    </section>
  <?php endif;?>
	
<?php if(get_field('mind_to_mind_content_title') || get_field('mind_to_mind_content') || get_field('iframe_url')):?>   
<section class="Mind_TO_Mind  bg-grey">
 <div class="container">
  <div class="row section__content">
       <?php if(get_field('mind_to_mind_content_title')):?>
		      <h2><?php the_field('mind_to_mind_content_title');?></h2>
         <?php endif;?> 
       <?php if(get_field('mind_to_mind_content')):?>
		<div class="col-md-6">
			<div class="editor">
				<?php the_field('mind_to_mind_content');?>
			</div>
		</div>
       <?php endif;?>  
       <?php if(get_field('iframe_url')):?>
		<div class="col-md-6">
		   <div class="iframe-Wrapper">
			<iframe class="responsive-iframe" src="<?php echo get_field('iframe_url');?>"></iframe>
		  </div>
		</div>
    <?php endif;?>

	</div>
</div>
</section>
<?php endif;?>

<?php
$single_column_panel = get_field('single_column_panel');
if($single_column_panel):?>
    <!-- Three Block Section HTML Start -->
    <section class="Three_block_section bg_white">
        <div class="container">
            <div class="row">
                <?php foreach($single_column_panel as $post): setup_postdata($post);?>
                <div class="col-md-4">
                    <a href="<?php the_permalink();?>" class="card">
                    <?php if(has_post_thumbnail(get_the_ID())): 
                     $image = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID() ), 'home-page-thumb' ); 
                     $imageID  = attachment_url_to_postid(@$image[0]);
                     $imageData = wp_get_attachment($imageID);
                    ?>
                    <img src="<?php echo @$image[0];?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
                    <?php endif;?>    
                        <div class="card-body">
                            <h3><?php the_title();?> <i class="fa-solid fa-angle-right"></i></h3>
                            <?php the_excerpt();?>
                        </div>
                    </a>
                </div>
               <?php endforeach;?>
            </div>
        </div>
    </section>
 
    <?php wp_reset_postdata(); ?>
 <?php endif; ?>

 </div>  
<?php get_footer(); ?>