<?php 
/* 
Template Name:Tests And Treatments
*/
get_header(); ?>

    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->

    <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <h1><?php the_title();?></h1>
                     <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata();?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->

    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                            <?php $pageID = '1553';
                            $postCcontent = get_post($pageID);?>
                            <a href="<?php echo esc_url( get_permalink($pageID)); ?>" class="pannel_module">
                            <h3><?php echo get_the_title($pageID); ?> <i class="fa-solid fa-angle-right"></i></h3>
                                <p>
                                    <?php echo $postCcontent->post_content;?>
                                </p>
                            </a>
                    </div>
                 <?php
                  //$custom_terms = get_terms('tests');
                  $custom_terms = get_terms('tests',array(
                    'parent'=>0
                  ));
                  foreach($custom_terms as $custom_term) {
                      wp_reset_query();
                      $args = array(
                        'post_type' => 'tests-and-treatments',
                        'posts_per_page' => -1,
                        'orderby'           =>  'name',
                        'order'             =>  'ASC',
                          'tax_query' => array(
                              array(
                                  'taxonomy' => 'tests',
                                  'field' => 'slug',
                                  'terms' => $custom_term->slug,
                              ),
                          ),
                       );
                   $query = new WP_Query($args);
                   if($query->have_posts()){ ?>    
                    <div class="col-lg-4 col-md-6 col-sm-12">
                    <a href="<?php echo get_term_link( $custom_term->slug, 'tests' );?>" class="pannel_module">
                        <h3><?php echo $custom_term->name;?> <i class="fa-solid fa-angle-right"></i></h3>
                        <p><?php echo get_field('summary',$custom_term->taxonomy.'_'.$custom_term->term_id);?></p> 
                        </a>
                    </div>
                    <?php }
                     } 
                    ?>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Wrapper Section HTML Start -->
<?php get_footer(); ?>