<?php 
/* 
Template Name: Translations
*/


get_header('inner'); ?>


    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

  

    <nav class="breadcrumb_section transalationb" aria-label="breadcrumb">
        <div class="container">
            <div class="col-sm-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><?php get_sidebar('breadcrumb');?></li>
               
            </ol>
        </div>
    </div>
    </nav>
    <div class="micro-baby transalation" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/diversity5.jpg')">
      <div class="wrapper">
        <div class="row">
          <div class="container">
            <div class="col-sm-12 col-md-8 col-lg-7">
              <div class="ready-title-steady">
                <h1 class="no-margin clr">Other languages and formats</h1>
                <p class="ready-title-steady-font">
                  Health information in different languages and formats -
                  including BSL, Easy Read and translations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

 <div class="readySteady-wrapper transalation" id="readySteadyID" >   
    <?php
                  $custom_terms = get_terms('languages',array(
                    'parent'=>0
                  ));
                    foreach($custom_terms as $ckey=> $custom_term) {
                        if($ckey=='0'){
                            $color = 'green';
                            $id = '15421';
                        }else{
                            $color = 'deep';
                            $id = '15428';
                        }
    ?>

          <!-- Symptoms Section HTML Start -->
          <div class="readySteadyLanding bg-ready-bc-<?php echo $color; ?>" id="<?php echo $id; ?>">
        <div class="wrapper">
          <div class="row p3">
            <div class="col-sm-12 col-md-9 panel-content-ready m-18">
              <div class="panel-bg-line">
                <h2 class="panel-text"><?php echo $custom_term->name; ?> </h2>
              </div>
              <div class="cf js-equal-height row">
                <!-- Child Item -->
                    <?php 
                        $terms = get_terms( 'languages', array( 'parent' => $custom_term->term_id, 'orderby' => 'slug', 'hide_empty' => false ) );
                        foreach($terms as $term) { 
                            ?>    
                <div class="col-lg-4 col-md-6 col-sm-12 mb-36">
                  <a
                    href="<?php echo get_term_link( $term->slug, 'languages' );?>"
                    class="pannel_module panel-min-130 panel-min-130">
                    <h3 class="module__title-ready">
                    <?php echo $term->name;?>
                      <i class="fa-solid fa-angle-right"></i>
                    </h3>
                    <p> <?php echo get_field('summary','languages'.'_'.$term->term_id);?></p> 
                  </a>
                </div>
                <?php } ?>


                <!-- Child Item -->
              </div>
            </div>



              <?php if($ckey=='0'){ ?>        
            <div class="col-md-3 show-for-medium-up p-18 readyRightAlign">
              <img
                class="microsite__landing-image"
                src="<?php echo get_template_directory_uri();?>/assets/images/languagesicon-01.png"
                alt="Languages Icon 01"
                data-id="14652"
                data-type="png"
              />
            </div>
            <?php } else { ?>
            <div class="col-md-3 show-for-medium-up p-18 readyRightAlign">
            <img
              class="microsite__landing-image"
              src="<?php echo get_template_directory_uri();?>/assets/images/formatsicon4-01.png"
              alt="Formats Icon 4 01"
              data-id="14652"
              data-type="png"
            />
          </div>

           <?php  } ?>
          </div>
        </div>
      </div>

      <?php } ?>


</div>
   <!-- Symptoms Section HTML End -->
    <!-- Footer HTML Start -->
    <script>
        jQuery(document).ready(function () {
                var lspan = $('#breadcrumbs span span').children().length; 
                       if(lspan===1){
                        $("#breadcrumbs span span:eq(0)").addClass("laste");
                        $("#breadcrumbs span span:last-child").remove();
                       }
    });
    </script>

<?php get_footer(); ?>