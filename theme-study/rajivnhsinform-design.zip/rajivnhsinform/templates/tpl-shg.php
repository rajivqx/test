<?php
/**
 * Template Name: SHG Listing Template
 * 
 */
get_header();
?>
 <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section shg-listing" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo home_url();?>">Home</a></li>
                
            </ol>
        </div>
    </nav>

     <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h1><?php the_title();?></h1>
                    
                </div>
            </div>
        </div>
    </section>
    <?php 
$args = array(
    'post_type' => 'self-help-guides',
    'posts_per_page'   => -1,
    'post_status' =>'publish'
);
$the_query = new WP_Query( $args );
?>

    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                    <?php if ( $the_query->have_posts() ) {
                        while ( $the_query->have_posts() ) {
                            $the_query->the_post();
                            $short_description = get_field('short_description', $the_query->post->ID );
                        ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo get_the_permalink($the_query->post->ID);?>" class="pannel_module">
                    <h3> <?php echo get_the_title($the_query->post->ID);?> <i class="fa-solid fa-angle-right"></i></h3>
                        <?php if(!empty($short_description)){
                            echo '<p>'.$short_description.'</p>';
                        } ?>
                        </a>
                    </div>
                <?php } }?>

                <div class="col-sm-12 mb-0" id="mental-health-self-help-guides">
                        <div class="panel-display">
                           <h2 class="panel-text"> Mental health self-help guides  </h2>
                         </div>
                </div>
                        <?php 
                            $args = array(
                                'post_type' => 'mental-health-shg',
                                'posts_per_page'   => -1,
                                'post_status' =>'publish'
                            );
                            $mental_query = new WP_Query( $args );?>

                             <?php if ( $mental_query->have_posts() ) {
                        while ( $mental_query->have_posts() ) {
                            $mental_query->the_post();
                            $short_description = get_field('subtext', $mental_query->post->ID );
                        ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo get_the_permalink($mental_query->post->ID);?>" class="pannel_module">
                    <h3> <?php echo get_the_title($mental_query->post->ID);?> <i class="fa-solid fa-angle-right"></i></h3>
                        <?php if(!empty($short_description)){
                            echo '<p>'.$short_description.'</p>';
                        } ?>
                        </a>
                    </div>
                <?php } }?>
                   
                </div>
            </div>
        </div>
    </section>


  <style type="text/css">
      .shg-listing .breadcrumb li a{
            color:#03759b;
            margin-left: 23px;
      }
      .shg-listing .breadcrumb li a:hover{
            color:#049bcd;
      }

      .shg-listing .breadcrumb li a:focus{
            color:#049bcd;
      }

  </style>
   
<?php get_footer();?>
