<?php 
/* 
Template Name: Scotland Service Directory
*/
get_header(); 
$page_id = get_the_ID();
?>
<div class="homeSSDID">
<?php get_sidebar('ssd_breadcrumbs');?>
<section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                  <h1><?php the_title(); ?></h1>
                     <div id="articleHeader"></div>
						<?php $description = get_field('description',$page_id);
							   echo isset($description) ? '<p>'.$description.'</p>':"";
							?>
         </div>
       </div>
     </div>
    </section>
</div>
<?php //if (have_posts()) : while (have_posts()) : the_post(); ?>
	
<?php //echo do_shortcode ("[servicetypes id=01 key='065671d43cfa4e38b9788f2aba0c356a']");?>

<?php echo do_shortcode ("[allservices key='065671d43cfa4e38b9788f2aba0c356a']");?>

	<?php //endwhile; ?>
	<?php //endif; ?>

<?php get_footer(); ?>