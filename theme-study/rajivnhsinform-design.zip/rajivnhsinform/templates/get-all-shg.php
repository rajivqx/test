<?php 
function SHG_admin_footer_function(){
if(is_admin()){
    $id = isset($_GET[ 'post' ]) ? $_GET[ 'post' ] : '' ;

    if(!empty($id)){
      $post_type = get_post_type( $id);
    }
    else {
    $post_type = isset($_GET[ 'post_type' ]) ? $_GET[ 'post_type' ] : '' ;
     }
    

    if($post_type == 'self-help-guides' || $post_type == 'symptoms-self-guides'){
         $meta_key1 = 'shg-service-id';
         $meta_value1 = get_post_meta( $id, $meta_key1, true );
      

  ?>
 <!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>-->
<script type="text/javascript">
	
	var workingDomain = "https://nhs24-shgapi-live.azurewebsites.net/";
  var nodevalue = "<?php echo $meta_value1;?>";
jQuery.ajax({


                      url: workingDomain + "umbraco/surface/SHG/getProtocolListJSONP/",
                      //data: t,
                      jsonpCallback: "getProtocolList",
                      dataType: "jsonp",
                      success: function (t) {
                      	//alert(t.protocolList[0]['nodeID']);

                      	jQuery( t.protocolList ).each(function( index, element ) {
                      		 var nodeID = t.protocolList[index]['nodeID'];
                      		 var protocolName = t.protocolList[index]['protocolName'];
                           var selected = (nodeID == nodevalue ? "selected" : "");

                      		 //alert(nodeID);
                      		 //alert(protocolName);
                      	jQuery('.nhs-shg-services').append("<option value='"+nodeID+"' "+selected+">"+protocolName+"</option>");

                      	});

                          //e.shgTitle(t.title), e.shgContent(t.content), e.ProtocolList(t.protocolList), e.groupProtocols(), equalheight(".page-block");
                      },
                      error: function (e, t, o) {
                      	//alert('fail');
                          401 === e.status && ajaxerror(e);
                      },
                  });
</script>
<?php } }
}
add_action('admin_footer', 'SHG_admin_footer_function');
/* Fire our meta box setup function on the post editor screen. */
add_action( 'load-post.php', 'shg_post_meta_boxes_setup' );
add_action( 'load-post-new.php', 'shg_post_meta_boxes_setup' );

/* Meta box setup function. */
function shg_post_meta_boxes_setup() {

  /* Add meta boxes on the 'add_meta_boxes' hook. */
  add_action( 'add_meta_boxes', 'shg_add_post_meta_boxes' );
  /* Save post meta on the 'save_post' hook. */
add_action( 'save_post', 'shg_save_post_service_meta', 10, 2 );
}

/* Create one or more meta boxes to be displayed on the post editor screen. */
function shg_add_post_meta_boxes() {

  add_meta_box(
    'shg-post-class',      // Unique ID
    esc_html__( 'Self Help Guide Picker', 'example' ),    // Title
    'get_shg_services_meta_box',   // Callback function
    array('self-help-guides', 'symptoms-self-guides'),         // Admin page (or post type)
    'normal',         // Context
    'default'         // Priority
  );
}

/* Display the post meta box. */
function get_shg_services_meta_box( $post ) { ?>

  <?php wp_nonce_field( basename( __FILE__ ), 'shg_services_nonce' ); ?>

  <p>
    <label for="smashing-post-class"><?php _e( "Select Self Help Guide", 'example' ); ?></label>
    <br />
     <select name="shg_services" class="nhs-shg-services">
     	<option>Select</option>
     </select>
  </p>

<?php }

/* Save the meta box’s post metadata. */
function shg_save_post_service_meta( $post_id, $post ) {

	$post_type = get_post_type_object( $post->post_type );

	  /* Check if the current user has permission to edit the post. */
  if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
    return $post_id;
  
   $new_meta_value = ( isset( $_POST['shg_services'] ) ? sanitize_html_class( $_POST['shg_services'] ) : "" );

   $meta_key = 'shg-service-id';
    $meta_value = get_post_meta( $post_id, $meta_key, true );

    if ( $new_meta_value && '' == $meta_value )
    add_post_meta( $post_id, $meta_key, $new_meta_value, true );

   elseif ( $new_meta_value && $new_meta_value != $meta_value )
    update_post_meta( $post_id, $meta_key, $new_meta_value );

 
}

?>