<?php 
/* 
Template Name: Healthy Living
*/
get_header(); ?>
<!-- Mobile Search HTML Start -->
<form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/'));?>">Home</a></li>
                <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
            </ol>
        </div>
    </nav>
    <!-- Breadcrumb HTML End -->
    <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <h1><?php the_title();?></h1>
                     <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata();?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->

    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                 <?php
                  $custom_terms = get_terms('health_type',array(
                    'parent'=>0,'hide_empty' => false
                  ));
                  foreach($custom_terms as $custom_term) {
                   ?>    
                    <div class="col-lg-4 col-md-6 col-sm-12">
                    <?php 
                    if($custom_term->term_id=='78'){ ?>
                        <a href="<?php echo home_url(); ?>/healthy-living/12-week-weight-management-programme" class="pannel_module">
                   <?php } elseif($custom_term->term_id=='75'){ ?>
                        <a href="<?php echo home_url(); ?>/ready-steady-baby/" class="pannel_module">
                   <?php } else { ?>
                        <a href="<?php echo get_term_link( $custom_term->slug, 'health_type' );?>" class="pannel_module">
                   <?php }
                    ?>
                        <h3><?php echo $custom_term->name;?> <i class="fa-solid fa-angle-right"></i></h3>
                        <p><?php echo get_field('summary',$custom_term->taxonomy.'_'.$custom_term->term_id);?></p> 
                        </ooaa>
                    </div>
                    <?php 
                     } 
                    ?>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Wrapper Section HTML Start -->
<?php //get_sidebar(); ?>
<?php get_footer(); ?>