<?php 
/* 
Template Name: Winter Vaccines
*/

$wc_section_1=get_field('wc_section_1');
$wc_section_2=get_field('wc_section_2');
$wc_section_3=get_field('wc_section_3');
$wc_section_4=get_field('wc_section_4');
$wc_section_5=get_field('wc_section_5');
$wc_section_6=get_field('wc_section_6');
$wc_section_7=get_field('wc_section_7');
$wc_section_8=get_field('wc_section_8');
$wc_section_9=get_field('wc_section_9');
$wc_section_10=get_field('wc_section_10');
$wc_section_11=get_field('wc_section_11');
$wc_section_12=get_field('wc_section_12');




get_header(); ?>




    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!--Alert Section HTML Start-->
    <section class="alert alert--newwarning alert--global ">
        <div class="container">
           <p><span>Information about&nbsp;</span><a data-id="22182" href="/illnesses-and-conditions/infections-and-poisoning/streptococcus-a-strep-a/" title="Streptococcus A (strep A)">Streptococcus A (Strep A)</a><span><span>&nbsp;</span>and<span>&nbsp;</span></span><a data-id="22189" href="/illnesses-and-conditions/infections-and-poisoning/scarlet-fever/" title="Scarlet fever">scarlet fever</a></p>
        </div>
    </section>

    <nav class="breadcrumb_section" aria-label="breadcrumb">
        <div class="container">
            
            <?php get_sidebar('breadcrumb');?>
               
            
        </div>
    </nav>
    
    <!--Alert Section HTML End-->

    <!--Banner Section HTML Start-->
    <section class="nhsuk-hero nhsuk-hero--image nhsuk-hero--image-description"
        style="background-image: url('<?php echo $wc_section_1['banner']['url'] ?>')">

        <div class="nhsuk-hero__overlay">
            <div class="container">
                <div class="nhsuk-hero-content nhsuk-hero-content--blue">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <h1><?php the_title();?></h1>
                     <?php the_content(); ?>
                    <?php endwhile; wp_reset_postdata();?>
                    <?php endif; ?>
                    <span class="nhsuk-hero__arrow nhsuk-hero-content--blue" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </section>

    
    <!--Banner Section HTML End-->

    <!-- Symptoms Section HTML Start -->
    <div class="col-sm-12 section-Alignment-start bg-grey">
        <div class="container">
             <div class="row">
                <h2>
                    <?php echo $wc_section_2['heading'] ?>        
                </h2>
    
            </div>
        </div>
    </div>


    <div class="col-sm-12 section-Alignment bg-white">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mb-4">
                    <h2>
                    <?php echo $wc_section_3['heading'] ?> 
                    </h2>
                    <div>
                    <?php echo $wc_section_3['description'] ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-sm-12 section-Alignment bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mb-4">
                    <h2>
                    <?php echo $wc_section_4['heading_1'] ?>
                    </h2>
                    <div class="editor">
                    <p><?php echo $wc_section_4['description_1'] ?> </p>                   
                </div>

                    <div class="self-help-guide">
                        <h2 class="section-title" style="margin-top:25px;">Self-help guide</h2>
            <div id="shg-container" class="row">
                <input type="hidden" id="userGUID" value="7b2e0162-3250-482b-aed7-fb10ec07bd1f">
                <input type="hidden" id="protocolID" value="6761">
            
                <div class="col-md-12">
                   
                    <div data-bind="visible: Questions().length > 0" style="">
                        
                        <div data-bind="attr: { 'class': CurrentQuestionType() == 4 ? 'panel panel-' + CurrentQuestion().endPoint().endPointLayoutColour : 'panel panel-info' }" class="panel panel-info">
                            <div class="panel-heading">
                                <h2 class="h2" data-bind="text: ProtocolName"><?php echo $wc_section_4['heading_2'] ?></h2>
                           
                            </div>
                            <div class="panel-body">
                                <div class="question-container" data-bind="with: CurrentQuestion">
                                  
                                    <div data-bind="html: protocol().questionShared">
                                    <?php echo $wc_section_4['description_2'] ?> 
                                    </div>
                                   
                                </div>
                            </div>
                            <div class="panel-footer">
                                <div class="buttons" style="height:60px; margin-top:10px;">
                                    <button class="btn btn-info pull-left" data-bind="click: $root.previous, visible: !$root.hidePrevious()" style="display: none;"><i class="glyphicon glyphicon-arrow-left"></i> Previous</button>
                                    <button class="btn btn-info pull-right" data-bind="click: $root.next, visible: !$root.hideNext(), css: { disabled: $root.disableNext() == true }"><span data-bind="text: $root.showStatement() ? 'Start guide' : 'Next'"><?php echo $wc_section_4['button_text'] ?></span> <i class="glyphicon glyphicon-arrow-right"></i></button>
                                </div>
                            </div>
                        </div>
                        <div id="ReviewAnswers" class="modal fade in" data-bind="showModal: $root.openDialog()">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-bind="click: $root.closeDialog" data-dismiss="modal" aria-hidden="true">×</button>
                                        <h4>Review my answers</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div data-bind="foreach: $root.Questions">
                                            <div data-bind="'if': nodeType() == 5">
                                                <h2 data-bind="text: protocol().protocolName">Winter vaccines</h2>
                                                <div data-bind="html: protocol().questionTop"></div>
                                                <p data-bind="'if': $root.Exceptions().length > 0">
                                                    You told us your credentials were:
                                                </p>
                                                <div data-bind="foreach: $root.Exceptions">
                                                    <span data-bind="text: title">Age</span>: <span data-bind="text: selectedLookup"></span>
                                                    <br>
                                                </div>
                                                <div data-bind="html: protocol().questionBottom"></div>
                                                <hr>
                                            </div>
                                            <div data-bind="visible: nodeType() != 4 &amp;&amp; nodeType() != 5" style="display: none;">
                                                <p data-bind="html: questionTop"></p>
                                                <p data-bind="html: questionShared"></p>
                                                <p><b>You said: </b> <span data-bind="text: answerText() == '' ? 'None' : answerText">None</span></p>
                                                <p data-bind="html: questionBottom"></p>
                                                <hr>
                                            </div>
                                            <div data-bind="'if': nodeType() == 4"></div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <a class="btn btn-default" data-bind="click: $root.closeDialog">Close</a>
                                        <a class="btn btn-info" data-bind="visible: $root.canDownload() == false, click: $root.createPDF">Keep a copy</a>
                                        <a class="btn btn-success" target="_blank" data-bind="visible: $root.canDownload() == true, attr: { href: $root.PDFLink }" href="" style="display: none;">View PDF</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    
    <div class="col-sm-12 section-Alignment bg-white">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mb-4">
                    <h2>
                    <?php echo $wc_section_5['heading_1'] ?>
                    </h2>
                    <div class="editor">
                        <p><?php echo $wc_section_5['description_1'] ?></p>
                    </div>
                    <div class="nhsuk-action-link">
                        <a class="nhsuk-action-link__link" target="_self" href="<?php echo $wc_section_5['link_text'] ?>">
                            <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
                            </svg>
                            <span class="nhsuk-action-link__text"><?php echo $wc_section_5['link_text'] ?></span>
                        </a>
                    </div>

                    <div class="editor">
                    <?php echo $wc_section_5['description_2'] ?>
                    </div>

                    <div class="alert alert--info">
                        <span class="icon icon-info-circled"></span>
        
                <p>
                    </p><h3><?php echo $wc_section_5['heading_2'] ?></h3></p>
                    <?php echo $wc_section_5['description_3'] ?>
            </div>

            <div class="editor">
            <?php echo $wc_section_5['description_4'] ?>
            </div>

                </div>
            </div>
        </div>
    </div>
    

    <div class="col-sm-12 section-Alignment bg-grey">
        <div class="container">
           <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                    <a href="<?php echo $wc_section_6['vaccine_1_link'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                        <h3><?php echo $wc_section_6['vaccine_1'] ?>  <i class="fa-solid fa-angle-right"></i> </h3>
                        <p>   <?php echo $wc_section_6['vaccine_1_description'] ?>
                        </p>
                    </a>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                    <a href="<?php echo $wc_section_6['vaccine_1_link'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                        <h3><?php echo $wc_section_6['vaccine_2'] ?> <i class="fa-solid fa-angle-right"></i> </h3>
                        <p> 
                        <?php echo $wc_section_6['vaccine_2_description'] ?>
                        </p>
                    </a>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                    <a href="<?php echo $wc_section_6['vaccine_1_link'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                        <h3><?php echo $wc_section_6['vaccine_3'] ?> <i class="fa-solid fa-angle-right"></i> </h3>
                        <p> <?php echo $wc_section_6['vaccine_3_description'] ?></p>
                    </a>
                </div>

            </div>
        </div>
    </div>


    <div class="col-sm-12 mt-4 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mb-4">
                    <div class="editor">
                        <h2 id="help"><?php echo $wc_section_7['heading'] ?></h2>
                    </div>
                    <div class="row ">
                        <div class="iframe-Wrapper">
                            <iframe class="responsive-iframe" src="<?php echo $wc_section_7['video_link'] ?>" title="How to book your winter vaccine appointment online" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" data-gtm-yt-inspected-7="true"></iframe>
                         </div>
                          </div>

                </div>
            </div>
        </div>
    </div>


    <div class="col-sm-12  bg-white">
            <div class="container">
                <div class="row">
				<div class="nhsuk-grid-column-full nhsuk-section__content">
                        
    <details class="nhsuk-details nhsuk-expander">
        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-0" aria-expanded="false">
            <span class="nhsuk-details__summary-text">
            <?php echo $wc_section_7['accordion_1_title'] ?>
            </span>
        </summary>
        <div class="nhsuk-details__text" id="details-content-0" aria-hidden="true">
        <?php echo $wc_section_7['accordion_1_description'] ?>
        </div>
    </details>
               
    <details class="nhsuk-details nhsuk-expander">
        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-1" aria-expanded="false">
            <span class="nhsuk-details__summary-text">
            <?php echo $wc_section_7['accordion_2_title'] ?>
            </span>
        </summary>
        <div class="nhsuk-details__text" id="details-content-1" aria-hidden="true">
            <?php echo $wc_section_7['accordion_2_description'] ?>        
        </div>
    </details>

    <details class="nhsuk-details nhsuk-expander">
        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-2" aria-expanded="false">
            <span class="nhsuk-details__summary-text">
            <?php echo $wc_section_7['accordion_3_title'] ?>
            </span>
        </summary>
        <div class="nhsuk-details__text" id="details-content-2" aria-hidden="true">
        <?php echo $wc_section_7['accordion_3_description'] ?>
        </div>
    </details>
        
    <details class="nhsuk-details nhsuk-expander">
        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-3" aria-expanded="false">
            <span class="nhsuk-details__summary-text">
            <?php echo $wc_section_7['accordion_4_title'] ?>            
            </span>
        </summary>
        <div class="nhsuk-details__text" id="details-content-3" aria-hidden="true">
             <?php echo $wc_section_7['accordion_4_description'] ?>
        </div>
    </details>

                </div>
				 </div>
            </div>
        </div>


        


        
        <div class="col-sm-12 section-Alignment mt-4 mb-4 bg-grey">
          
            <div class="container ">
                <div class="row">
                    <div class="col-sm-12 mt-4 mb-4">
                        <div class="editor">
                            <h2 id="help"><?php echo $wc_section_8['heading'] ?></h2>
                        </div>
                        <div class="row ">
                            <div class="iframe-Wrapper">
                                <iframe class="responsive-iframe" src="<?php echo $wc_section_8['video_url'] ?>" title="How to book your winter vaccine appointment online" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" data-gtm-yt-inspected-7="true"></iframe>
                             </div>
                              </div>
    
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12 mt-4 mb-4 bg-white">
            <div class="container ">
                <div class="row">
                    <div class="col-sm-12 mt-4 mb-4">
                        <div class="editor">
                            <h2 id="help"><?php echo $wc_section_9['heading'] ?></h2>
                        </div>

                        <div class="editor">
                            <?php echo $wc_section_9['description'] ?>
                        </div>
                        
                        <div class="row ">
                            <div class="iframe-Wrapper">
                                <iframe class="responsive-iframe" src="<?php echo $wc_section_9['video_url'] ?>" title="How to book your winter vaccine appointment online" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" data-gtm-yt-inspected-7="true"></iframe>
                             </div>
                              </div>
    
                    </div>
                </div>
            </div>
        </div>


        <div class="col-sm-12 section-Alignment bg-grey">
            <div class="container">
               <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_10['block_1_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3><?php echo $wc_section_10['block_1_heading'] ?><i class="fa-solid fa-angle-right"></i> </h3>
                            <p>   <?php echo $wc_section_10['block_1_description'] ?> </p>
                        </a>
                    </div>
    
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_10['block_2_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3><?php echo $wc_section_10['block_2_heading'] ?> <i class="fa-solid fa-angle-right"></i> </h3>
                            <p> 
                               
                            <?php echo $wc_section_10['block_2_description'] ?>
                            </p>
                        </a>
                    </div>
    
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_10['block_3_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3> <?php echo $wc_section_10['block_3_heading'] ?><i class="fa-solid fa-angle-right"></i> </h3>
                            <p> <?php echo $wc_section_10['block_3_description'] ?></p>
                        </a>
                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_10['block_4_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3><?php echo $wc_section_10['block_4_heading'] ?><i class="fa-solid fa-angle-right"></i> </h3>
                            <p> <?php echo $wc_section_10['block_4_description'] ?></p>
                        </a>
                    </div>

    
                </div>
            </div>
        </div>



        <div class="col-sm-12 section-Alignment bg-white">
            <div class="container">
               <div class="row">
                <h2>
                <?php echo $wc_section_11['heading'] ?>
                </h2>

                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_11['block_1_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3><?php echo $wc_section_11['block_1_heading'] ?>  <i class="fa-solid fa-angle-right"></i> </h3>
                            <p>  <?php echo $wc_section_11['block_1_description'] ?>  </p>
                        </a>
                    </div>
    
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_11['block_2_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3><?php echo $wc_section_11['block_2_heading'] ?> <i class="fa-solid fa-angle-right"></i> </h3>
                            <p> 
                            <?php echo $wc_section_11['block_2_description'] ?> 
                      
                            </p>
                        </a>
                    </div>
    
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_11['block_3_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3> <?php echo $wc_section_11['block_3_heading'] ?>  <i class="fa-solid fa-angle-right"></i> </h3>
                            <p> <?php echo $wc_section_11['block_3_description'] ?> </p>
                        </a>
                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <a href="<?php echo $wc_section_11['block_4_url'] ?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                            <h3><?php echo $wc_section_11['block_4_heading'] ?>  <i class="fa-solid fa-angle-right"></i> </h3>
                            <p> 
                            <?php echo $wc_section_11['block_4_description'] ?> 
                            </p>
                        </a>
                    </div>

    
                </div>
            </div>
        </div>


        <div class="col-sm-12 section-Alignment mt-4  bg-grey">
            <div class="container">
                <div class="row ">
                    <h2>
                    <?php echo $wc_section_12['heading'] ?> 
                    </h2>
                    <div class="col-sm-12 mt-4 mb-4">
                        
                        <div class="row ">
                            <div class="iframe-Wrapper">
                                <iframe class="responsive-iframe" src="<?php echo $wc_section_12['video_url'] ?>"  title="COVID-19 &amp; Flu Vaccines Explainer Video - Full Length" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" id="widget2" data-gtm-yt-inspected-2559837_374="true" data-gtm-yt-inspected-7="true"></iframe>
                                                            
                            </div>
                              </div>

                              <div class="editor mt-4">
                              <?php echo $wc_section_12['description_1'] ?> 
                            </div>


                            
                                            
                        <details class="nhsuk-details nhsuk-expander">
                            <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-0" aria-expanded="false">
                                <span class="nhsuk-details__summary-text">
                                <?php echo $wc_section_12['tab_title'] ?> 
                                </span>
                            </summary>
                            <div class="nhsuk-details__text" id="details-content-0" aria-hidden="true">
                            <?php echo $wc_section_12['tab_description'] ?>
                            </div>
                        </details>

                        <div class="editor">
                        <?php echo $wc_section_12['description_2'] ?> 
                        </div>

    
                    </div>
                   
                </div>
            </div>

            

        </div>
        <div style="background-image: url('<?php echo $wc_section_1['banner']['url'] ?>')" class="col-sm-12 winter-Vaccine-image">
            <img class="image-panel__overlay" >
         </div>
        

        


    <!-- Symptoms Section HTML End -->

    <!-- Footer HTML Start -->
    <?php get_footer(); ?>