<?php 
/* 
Template Name: HIV PrEP
*/
get_header(); ?>
    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
        <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->






   <?php 
$banner = get_field('Banner_Content_Manage');
$panel = get_field('panel_options_hiv');
   if($banner['header_banner_image_hiv']):?>
    <!--Banner Section HTML Start-->
    <section class="nhsuk-hero nhsuk-hero--image nhsuk-hero--image-description"  style="background-image: url('<?php echo $banner['header_banner_image_hiv'];?>')">
    <div class="nhsuk-hero__overlay">
            <div class="container">
                <div class="nhsuk-hero-content nhsuk-hero-content--blue minWidthPanel">
                    <?php if($banner['header_banner_title_hiv']):?>
                        <h1><?php echo $banner['header_banner_title_hiv'];?></h1>
                    <?php endif;?>
                   <?php if($banner['header_banner_summary_hiv']):?> 
                     <p><?php echo $banner['header_banner_summary_hiv']; ?></p>
                   <?php endif;?> 
                    <span class="nhsuk-hero__arrow nhsuk-hero-content--blue" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </section>
    <?php if($banner['header_banner_text_hiv']):?> 
    <div class="col-sm-12 full-grey-strip">
        <div class="container">
             <div class="grid-column-full section__content">
                    <h2>
                    <?php echo $banner['header_banner_text_hiv'];?>
                    </h2>
            </div>
         </div>
    </div>
    <?php endif;?> 
    <?php endif;?>

    <div class="col-sm-12 section-Alignment bg-white">
        <div class="container">
          <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                <?php if($panel['panel_1_left_content_hiv']):?> 
					<div class="editor">
                    <?php echo $panel['panel_1_left_content_hiv'];?>
                    </div>	
                    <?php endif;?> 
                </div>
                <?php if($panel['panel1content_url']['link_text_hiv_panel1']):?> 
                <div class="nhsuk-action-link">
                    <a class="nhsuk-action-link__link" target="_self" href="<?php echo $panel['panel1content_url']['link_url_content1'];?>">
                        <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M0 0h24v24H0z" fill="none"></path>
                            <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
                        </svg>
                        <span class="nhsuk-action-link__text"><?php echo $panel['panel1content_url']['link_text_hiv_panel1'];?>
                    </a>
                </div>
                <?php endif;?> 
                <?php if($panel['panel_1_right_image_hiv']):?> 
                 <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <div class="nhs-two-column-panel__wrapper__item--media">
                        <img src="<?php echo $panel['panel_1_right_image_hiv'];?>" alt="white tub of pills that says PrEP on the front" data-id="20428" data-type="png">
                     </div>
                </div>
                <?php endif;?> 

               </div>
        </div>
    </div>

    <div class="col-sm-12 section-Alignment bg-grey">
        <div class="container">
          <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                <?php if($panel['panel2_left_image_hiv']):?> 
                    <div class="nhs-two-column-panel__wrapper__item--media">
                        <img src="<?php echo $panel['panel2_left_image_hiv'];?>" alt="guys kissing" data-id="20427" data-type="png">
                    </div>
                    <?php endif;?> 

                </div>

                 <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                 <?php if($panel['panel_1_left_content_hiv']):?> 
                    <div class="editor">
                    <?php echo $panel['panel_2_right_content_hiv'];?>
                    </div>
                    <?php endif;?> 
	
                </div>

               </div>
        </div>
    </div>

    <div class="col-sm-12 section-Alignment bg-white">
        <div class="container">
          <div class="row">

          <?php if($panel['panel_3_content_hiv']):?> 

                <div class="col-sm-12 mb-4">
                <?php echo $panel['panel_3_content_hiv'];?>
                    <?php if($panel['panel3content_url']['link_text_hiv_panel3']):?> 
                <div class="nhsuk-action-link">
                    <a class="nhsuk-action-link__link" target="_self" href="<?php echo $panel['panel3content_url']['link_url_content3'];?>">
                        <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M0 0h24v24H0z" fill="none"></path>
                            <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
                        </svg>
                        <span class="nhsuk-action-link__text"><?php echo $panel['panel3content_url']['link_text_hiv_panel3'];?></span>
                    </a>
                </div>
                <?php endif;?> 

                </div>
                <?php endif;?> 

               </div>
        </div>
    </div>


 <!-- Symptoms Section HTML End -->
<?php get_footer(); ?>