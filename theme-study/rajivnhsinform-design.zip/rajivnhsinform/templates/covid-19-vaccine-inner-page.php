<?php 
/* 
Template Name: Covid-19 Vaccine Inner Page
*/
get_header();?>

    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

   <!-- Breadcrumb HTML Start -->
   <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->
    <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                <?php if(have_posts()) : while(have_posts()) : the_post(); ?>
                    <h1><?php the_title();?></h1>
                     <?php the_content(); ?>
                     <?php endwhile; wp_reset_postdata();?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Pannel Intro Section HTML End -->
<?php if(have_rows('content_list')):?>
    <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                   <?php 
                    while(have_rows('content_list')): the_row();?>
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <a href="<?php echo get_sub_field('link_to_content');?>" class="pannel_module">
                            <?php if(get_sub_field('heading')):?>
                                <h3><?php the_sub_field('heading');?> <i class="fa-solid fa-angle-right"></i></h3>
                            <?php endif;?>
                            <?php if(get_sub_field('summary')):?>
                                <p><?php the_sub_field('summary');?></p> 
                            <?php endif;?>  
                          </a>
                        </div>
                    <?php endwhile;?>                    
                </div>
            </div>
        </div>
    </section>
<?php endif;?>
<!-- Pannel Wrapper Section HTML Start -->
<?php get_footer();?>