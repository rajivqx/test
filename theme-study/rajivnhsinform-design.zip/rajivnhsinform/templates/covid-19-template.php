<?php 
/* 
Template Name: Covid-19
*/
get_header(); ?>
    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
        <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->

   <?php if(get_field('header_banner_image')):?>
    <!--Banner Section HTML Start-->
    <section class="nhsuk-hero nhsuk-hero--image nhsuk-hero--image-description" style="background-image:url('<?php echo get_field('header_banner_image');?>')">
        <div class="nhsuk-hero__overlay">

        <?php if(get_field('header_banner_title') || get_field('header_banner_summary')):?>
            <div class="container">
                <div class="nhsuk-hero-content nhsuk-hero-content--blue">
                    <?php if(get_field('header_banner_title')):?>
                        <h1><?php the_field('header_banner_title');?></h1>
                    <?php endif;?>
                   <?php if(get_field('header_banner_summary')):?> 
                     <p><?php the_field('header_banner_summary');?></p>
                   <?php endif;?> 
                    <span class="nhsuk-hero__arrow nhsuk-hero-content--blue" aria-hidden="true"></span>
                </div>
            </div>
        <?php endif;?>

        </div>
    </section>
    <?php endif;?>
        
    <!--Banner Section HTML End-->
<?php if(have_rows('content_list')):?>
     <?php 
     $bgColor = 0;
     while(have_rows('content_list')): the_row();?>
    <!-- Symptoms Section HTML Start -->
        <div class="col-sm-12 section-Alignment-start <?php echo ($bgColor%2 == 0) ? 'bg-grey': 'bg-white';?>">
            <div class="container">
            <?php if(get_sub_field('title')):?> <h2><?php the_sub_field('title');?></h2><?php endif;?>    
            <div class="row">
            <?php
                $title_itemList = get_sub_field('title_itemList');
                if($title_itemList): 
                    foreach($title_itemList as $post):    
                        setup_postdata($post);
                            if(get_field('redirect_documets')){
                                 $get_permalink = get_field('redirect_documets');
                                }else{
                                 $get_permalink = get_the_permalink();
                               }
                            ?>
                            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                                <a href="<?php echo $get_permalink;?>" class="pannel_module panel-min-130 panel-min-130 covid-19">
                                    <h3><?php the_title();?>  <i class="fa-solid fa-angle-right"></i> </h3>
                                    <p><?php the_excerpt();?> </p>
                                </a>
                            </div>
                        <?php endforeach;?>
                      <?php wp_reset_postdata(); ?>
                <?php endif;?>
                </div>
            </div>
        </div>
    <?php $bgColor++;endwhile;endif;?>
    <?php if(get_field('bottom_image')):?>
        <div class="col-sm-12 image-panel mt-0" style="background-image: url('<?php echo get_field('bottom_image');?>')">
        </div>
<?php endif;?>
 <!-- Symptoms Section HTML End -->
<?php get_footer(); ?>