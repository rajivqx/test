<?php
/**
 * Template Name: Symptoms SHG Template
 * 
 */
get_header();
?>

 <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section shg-listing" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo home_url();?>">Home</a></li>
                
            </ol>
        </div>
    </nav>

      <!-- Pannel Intro Section HTML Start -->
    <section class="pannel_intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h1><?php the_title();?></h1>
                    <p class="mb-0">Work through a self-help guide for depression that uses cognitive behavioural therapy (CBT).</p>
                    
                </div>
            </div>
        </div>
    </section>

      <!-- Pannel Wrapper Section HTML Start -->
    <section class="pannel_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                	<div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="<?php echo home_url();?>/symptoms-and-self-help/self-help-guides/" class="pannel_module">
                    <h3> Self-help guides <i class="fa-solid fa-angle-right"></i></h3>
                        <p>Search for self-help guides by name and check your symptoms</p>                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer();?>