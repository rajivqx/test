<?php 
/* 
Template Name:Mind To Mind
*/
get_header();?>
    <!-- Mobile Search HTML Start -->
    <div class="mindtoMindHome">
    <?php if(get_field('show_leave_this_site_button')){ ?>
      <div class="sars-leave">
        <button class="sars-leave__button" id="show_leave_this_site_button" onclick="pageRedirect('https:google.com')">
            Leave this site
        </button>
    </div>
  <?php } ?>
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
      <?php get_sidebar('breadcrumb');?>
    <!-- Breadcrumb HTML End -->

<?php if(have_posts()):?>
  <?php if(get_field('header_banner_image')):?>
    <div class="col-sm-12 hero-image">
      <img class="hero-image-text" src="<?php the_field('header_banner_image');?>">
    </div>
  <?php endif;?>  

<div class="col-sm-12 full-grey-strip">
  <div class="container">
        <?php while(have_posts()): the_post();
         $getID = get_the_ID();?>
          <div class="grid-column-full section__content">
              <h2><?php the_content();?></h2>
          </div>
      <?php endwhile;?>
    </div>
</div>
 
<?php
  $args = array(
      'post_type'      => 'page',
      'posts_per_page' => -1,
      'post_parent'    => $getID,
      'order'          => 'ASC',
      'post_status'    => 'publish',
      'orderby'        => 'date'
  );
$parent = new WP_Query( $args);
if($parent->have_posts()):
  $getAllPost = [];
    while($parent->have_posts()) :$parent->the_post();
      if(has_post_thumbnail(get_the_ID())): 
      $images = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()),'home-page-thumb');
      $image = @$images[0];
      $imageID = get_post_thumbnail_id(get_the_ID());
      else:
      $image = '';
      endif;   
      $getAllPost[get_the_ID()]['id']        = get_the_ID();
      $getAllPost[get_the_ID()]['title']     = get_the_title();
      $getAllPost[get_the_ID()]['excerpt']   = get_the_excerpt();
      $getAllPost[get_the_ID()]['permalink'] = get_the_permalink();
      $getAllPost[get_the_ID()]['image']     = $image;
      $getAllPost[get_the_ID()]['imageID']   = $imageID;
    endwhile;
  $chunks  = array_chunk($getAllPost,2,true);
  $k=0;
  foreach ($chunks as $chunk){ ?>
<div class="col-sm-12 <?php if($k%2 == '0'){ echo 'full-white-strip';}else{ echo 'full-grey-strip';}?>">
    <div class="container">
      <div class="row section__content-p">
         <?php 
           foreach($chunk as $res){ 
            $imageID    = "";
            $imageData  = "";
            $imageID    = attachment_url_to_postid($res['image']);
            $imageData  = wp_get_attachment($res['imageID']);
            //echo $res['image'];
            //print_r($imageData);
            ?>
            <div class="col-sm-6">
                <a class="mind-module" href="<?php echo (get_field('link_to_content',$res['id']) ) ?  get_field('link_to_content',$res['id']) : $res['permalink'];?>">
                   <?php if($res['image'] !=''){ ?>
                    <div>
                        <img src="<?php echo $res['image'];?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
                    </div>
                  <?php } ?>  
                    <h3 class="mind-module-title"><?php echo $res['title'];?></h3>
                    <div class="mind-module-description">
                        <?php echo $res['excerpt'];?>
                    </div>
                </a>
            </div>
          <?php 
        } ?>  
        </div>
      </div>
</div>
<?php 
  $k++;
    }
endif;
?>

<?php if(get_field('bottom_video_url',$getID)):?>
<div class="col-sm-12 full-white-strip">
    <div class="container">
        <div class="row section__content">
        <div class="iframe-Wrapper">
                <iframe class="responsive-iframe" src="<?php the_field('bottom_video_url',$getID);?>"></iframe>
          </div>
          </div>
      </div>
</div>
<?php endif;?>

<?php if(get_field('bottom_banner_image',$getID)):
   $imageID  = attachment_url_to_postid(get_field('bottom_banner_image',$getID));
   $imageData = wp_get_attachment($imageID);
  ?>
    <div class="col-sm-12 image-panel">
        <img class="image-panel__overlay" src="<?php the_field('bottom_banner_image',$getID);?>" alt="<?php echo $imageData['alt'];?>" title="<?php echo $imageData['title'];?>">
    </div>
 <?php endif;?> 

  <?php endif;?> 
</div>
<!-- Footer Links -->
<?php get_footer();?>