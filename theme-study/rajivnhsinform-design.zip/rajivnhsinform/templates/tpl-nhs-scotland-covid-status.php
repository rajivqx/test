<?php 
/* 
Template Name: NHS Scotland Covid Status
*/
get_header();
$pg_id = get_the_ID();
 ?>

 <nav class="breadcrumb_section" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>

            </ol>
        </div>
    </nav>
<?php $bg_image = get_field('banner_background_image', $pg_id);
      $img_url = isset($bg_image) ? $bg_image:"";
?>
    <!--Banner Section HTML Start-->
    <div class="nhsuk-hero nhsuk-hero--image nhsuk-hero--image-description   text-left--medium"
        style="background-image: url('<?php echo $img_url;?>?anchor=center&amp;mode=crop&amp;width=1000&amp;height=500&amp;rnd=133110930280000000');">
        <div class="col-sm-12">
            <div class="container">
                <div class="row">
                  <?php if ( have_rows('top_banner_content') ) :
                   while( have_rows( 'top_banner_content') ) : the_row(); 
                   	$heading = get_sub_field('heading');
                   	$app_store_button_link = get_sub_field('app_store_button_link');
                   	$google_play_button_link = get_sub_field('google_play_button_link');
                   	$summery_text = get_sub_field('summery-text');
                   	$link_text = get_sub_field('link_text');
                   	$read_more_text = isset($link_text) ? $link_text:"";
                   	$link_url = get_sub_field('link_url');
                   	$read_more_link = isset($link_url) ? home_url().$link_url:"";

                   	?>
                        <div class="nhsuk-hero-content nhsuk-hero-content--blue">
                        	<?php if(!empty($heading)){
                            echo '<h1 class="nhsuk-u-margin-bottom-3">'.$heading.'</h1>';
                        	} ?>
                            <div class="nhs-inform-app-download">
                                <a href="<?php echo $app_store_button_link;?>"
                                    class="nhs-inform-app-download__ios">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/AppStore.svg">
                                </a>
                                <a href="<?php echo $google_play_button_link;?>"
                                    class="nhs-inform-app-download__android">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/GooglePlay.svg">
                                </a>
                            </div>
                            <?php echo '<p>'.$summery_text .'<br>
                           <a class="scotland-covid-status-link"
                                    href="'.$read_more_link.'"
                                    title="COVID Status: Common questions">'.$read_more_text.'</a>
                            </p>';
                            ?>
                            <span class="nhsuk-hero__arrow nhsuk-hero-content--blue" aria-hidden="true"></span>
                        </div>
                        <?php endwhile;
						 endif; ?>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="nhs-scotland-covid-wrapper" id="scotlandCovidStatusID">
    	<div class="col-sm-12 section-Alignment-start bg-grey">
        <div class="container">
            <div class="row">
                <div class="nhsuk-u-reading-width">
                	<?php $banner_bottom_text = get_field('banner_bottom_text', $pg_id);
                	if(!empty($banner_bottom_text)){
                      echo '<h2>'.$banner_bottom_text.'</h2>';
                	}
                    ?>
                </div>
            </div>
        </div>
    </div>

 <!-- Symptoms Section HTML Start -->
    <div class="col-sm-12 section-Alignment-start bg-white">
        <div class="container">

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <div class="editor">
                    	<?php $covid_status_heading = get_field('covid_status_heading', $pg_id);
                    	 $covid_status_description = get_field('covid_status_description', $pg_id);
                    	 $covid_status_right_side_image = get_field('covid_status_right_side_image', $pg_id);
                    	 $covid_faq = get_field('covid_faq', $pg_id);
                    	 $covid_alert_box = get_field('covid_alert_box', $pg_id);

                    	
                        echo '<h2>'.$covid_status_heading.'</h2>';
                        echo  $covid_status_description;
                        
                        ?>
                    </div>
                    
                    

                    <!--<div class="editor">
                        <p>If you can’t use the app or download a copy, you can phone the COVID Status Helpline on 0345
                            034 2456. The helpline is open from 10am to 6pm Monday to Friday, 10am to 1pm on Saturday
                            and closed on Sunday. Give yourself plenty of time to get your paper copy before you need
                            it.</p>
                        <p>If you're a resident in Scotland and have been vaccinated in an approved country, <a
                                href="https://www.nhsinform.scot/covid-19-vaccine/request-an-update-to-your-vaccination-record/"
                                data-gc-link="https://www.nhsinform.scot/covid-19-vaccine/request-an-update-to-your-vaccination-record/">you
                                can have your COVID Status updated to include this information</a>.</p>
                    </div>-->
                   <?php if(!empty($covid_faq)){
                   		foreach ($covid_faq as $value) {
                   		
                   	?>
                    <details class="nhsuk-details">
                    	<?php if(!empty($value['question_heading'])){?>
                        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-0"
                            aria-expanded="false">
                            <span class="nhsuk-details__summary-text">
                                <?php echo $value['question_heading'];?>
                            </span>
                        </summary>
                    <?php } ?>

                    <?php if(!empty($value['answer_text'])){?>
                        <div class="nhsuk-details__text" id="details-content-0" aria-hidden="true">
                        		<?php echo $value['answer_text'];?>
                            <!--<p>You can download a copy of your COVID Status online by <a
                                    href="https://vacs.nhs.scot/csp?id=csm_login" title="Log in">logging in</a> using
                                your unique username and password.</p>
                            <p>Your username can be found in your coronavirus vaccination appointment letter. You can
                                use this to register and create your own password.</p>
                            <p>If you have never received a unique username, you can sign up for one by using the '<a
                                    href="https://vacs.nhs.scot/csp?id=recover_username"
                                    title="Recover username">recover username</a>' option.</p>
                            <p>If you have lost or forgotten your username or password, you can create new ones by
                                selecting the '<a href="https://vacs.nhs.scot/csp?id=recover_username"
                                    title="Recover username">recover username</a>' or '<a
                                    href="https://vacs.nhs.scot/$pwd_reset.do?sysparm_url=ss_default"
                                    title="Forgotten password"><span>forgotten your password</span></a>' options.</p>
                            <p>Once you have signed in, you should select 'vaccination status' which will allow you to view or download a copy of your COVID Status.</p>-->
                        </div>
                        <?php } ?>
                    </details>
                <?php } } ?>

                    <!--<details class="nhsuk-details">
                        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-1"
                            aria-expanded="false">
                            <span class="nhsuk-details__summary-text">
                                Will my booster dose be shown on my COVID Status?
                            </span>
                        </summary>
                        <div class="nhsuk-details__text" id="details-content-1" aria-hidden="true">
                            <p>All your doses will show on the COVID Status app.</p>
                            <p>Paper copies will only show your last 2 doses.</p>
                        </div>
                    </details>


                    <details class="nhsuk-details">
                        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-2"
                            aria-expanded="false">
                            <span class="nhsuk-details__summary-text">
                                What if my information is wrong?
                            </span>
                        </summary>
                        <div class="nhsuk-details__text" id="details-content-2" aria-hidden="true">
                            <p>If any information on your COVID Status is wrong, you should phone the COVID Status
                                Helpline on 0345 034 2456.</p>
                            <p>You do not need middle name(s) for international travel.</p>
                            <p>If your address on your status is out of date you can still use it for international
                                travel, as long as your name and date of birth are correct.</p>
                        </div>
                    </details>-->



                </div>


                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <div class="nhs-two-column-panel__wrapper__item--media">
                    	<?php if(!empty($covid_status_right_side_image['url'])){?>
                        <img src="<?php echo $covid_status_right_side_image['url'];?>" alt="phone screen listing 2 vaccines" data-id="18466"
                            data-type="png">
                        <?php } ?>
                    </div>

                    
                    <?php if(!empty($covid_alert_box)){?>
                    <div class="alert alert--info">
                        <span class="icon icon-info-circled"></span>
                        <p>
                        </p>
                           <?php echo $covid_alert_box;?>
                        <p></p>
                        <!--<p>
                        </p>
                        <p>If you experience any issues with the app, uninstalling and reinstalling the app will resolve
                            most problems. You’ll have to log in again using the email address and password you used to
                            sign up. You will not need to verify your identity with a selfie again.</p>
                        <p></p>-->
                    </div>
                <?php } ?>

                </div>

            </div>
        </div>
    </div>

  <div class="col-sm-12 section-Alignment-start bg-grey">
        <div class="container">
        	<?php if ( have_rows('covid_status_for_international_travel') ) :
                   while( have_rows( 'covid_status_for_international_travel') ) : the_row();
                   	?>
            <div class="row">
            	 	<?php
                   	$heading = get_sub_field('heading');
                   	$description = get_sub_field('description');
                   	$link_text = get_sub_field('link_text');
                   	$link_url = get_sub_field('link_url');
                   	?>
                <div class="editor">
                	<?php if(!empty($heading)){
                      echo '<h2>'.$heading.'</h2>';
                }

                echo isset($description) ? $description : "";
                ?>
               
                </div>
            </div>
        
    

    <div class="nhsuk-action-link">
    	<?php if(!empty($link_text) && !empty($link_url)){
        echo '<a class="nhsuk-action-link__link" target="_self" href="'.$link_url.'">
            <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M0 0h24v24H0z" fill="none"></path>
                <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
            </svg>
            <span class="nhsuk-action-link__text">'.$link_text.'</span>
        </a>';
    } ?>
    </div>
    <?php endwhile;
			 endif; ?>
</div>
</div>

<div class="col-sm-12 section-Alignment-start bg-white">
    <div class="container">
        <div class="row">
        	<?php if ( have_rows('common_question_block') ) :
                   while( have_rows( 'common_question_block') ) : the_row();
                   	$heading = get_sub_field('heading');
                   	$description = get_sub_field('description');
                   	$link_text = get_sub_field('link_text');
                   	$link_url = get_sub_field('link_url');
                   	$right_side_image = get_sub_field('right_side_image');
                   
            echo '<h2>'.$heading.'</h2>';
            	?>
            <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
               <div class="editor">
               	 <?php echo isset($description) ? $description:"";?>
                        
                    </div>
                        <div class="nhsuk-action-link">
                        	<?php if(!empty($link_text) && !empty($link_url)){
                            echo '<a class="nhsuk-action-link__link" target="_self" href="'.home_url().$link_url.'">
                                <svg class="nhsuk-icon nhsuk-icon__arrow-right-circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                                    <path d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
                                </svg>
                                <span class="nhsuk-action-link__text">'.$link_text.'</span>
                            </a>';
                         } ?>
                        </div>
            </div>
            <?php if(!empty($right_side_image)){?>
            <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                <img src="<?php echo $right_side_image['url'];?>" alt="phone screen with large QR code" data-id="18468" data-type="png">
            </div>
        <?php } ?>
         
        </div>
        <?php endwhile;
			 endif; ?>
    </div>
</div>

<div class="col-sm-12 section-Alignment-start bg-grey">
    <div class="container">
        <div class="row">
        	<?php if ( have_rows('proof_of_recovery_from_coronavirus') ) :
                   while( have_rows( 'proof_of_recovery_from_coronavirus') ) : the_row();
                   	$heading = get_sub_field('heading');
                   	$description = get_sub_field('description');
                   	?>
            <div class="editor">
                <?php echo '<h2>'.$heading.'</h2>';
                echo isset($description) ? $description:"";
                ?>
            <!--<p>If you're travelling internationally and are not fully vaccinated, some countries may accept proof of recovery from coronavirus. This is usually by having a positive PCR test result showing past infection.</p>
            <p>NHS coronavirus testing is no longer available for most people in Scotland. Proof of recovery is also no longer available.</p>
            <p>There may be private companies who offer PCR tests to show proof of past infection. However, as these are private tests they do not go onto NHS records.</p>
            <p>You should&nbsp;<a href="https://www.gov.uk/foreign-travel-advice" title="GOV UK Travel advice">check entry requirements of the country you're travelling to</a></p>-->
            </div>
            <?php endwhile;
			 endif; ?>
        </div>
</div>
</div>

<div class="col-sm-12 section-Alignment bg-white">
    <div class="container">
        
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>Request an update to your vaccination record <i class="fa-solid fa-angle-right"></i> </h3>
                    <p> Add proof of a coronavirus (COVID-19) vaccination from an approved country to your Scottish vaccination record
                    </p>
                </a>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>Information for coronavirus (COVID-19) vaccination clinical trial participants <i class="fa-solid fa-angle-right"></i> </h3>
                    <p> How clinical trial participants can get a record of their vaccination status  </p>
                </a>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>COVID Status: Accessibility statement <i class="fa-solid fa-angle-right"></i> </h3>
                    <p> How accessible the NHS Scotland COVID Status app is	</p>
                </a>
            </div>


            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>COVID Status: NHS Scotland COVID Status app privacy notice<i class="fa-solid fa-angle-right"></i> </h3>
                    <p> How your personal data is processed when using the COVID Status app and how to exercise your rights   </p>
                </a>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>COVID Status: Languages and accessible formats<i class="fa-solid fa-angle-right"></i> </h3>
                    <p> Translated information about NHS Scotland COVID Status </p>
                </a>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>COVID Status: Stakeholders and partners <i class="fa-solid fa-angle-right"></i> </h3>
                    <p> Downloadable campaign assets for the NHS Scotland COVID Status app	</p>
                </a>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <a href="a_to_z_page.html" class="pannel_module panel-min-130 panel-min-130 covid-19">
                    <h3>COVID Status: Cookies policy <i class="fa-solid fa-angle-right"></i> </h3>
                    <p> Cookies policy and terms and conditions for the NHS Scotland COVID Status app
                    </p>
                </a>
            </div>


            

        </div>
    </div>
</div>

 </div>

<?php get_footer(); ?>