<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package nhsinform
 */

get_header();
?>
<main id="maincontent" class="site-main">
	<?php //while ( have_posts()) :the_post();?>
        <div class="panel-intro">
            <div class="wrapper">
                <div class="col small-12 large-8">
                    <nav class="nhsuk-breadcrumb" aria-label="Breadcrumb">
                        <div class="nhsuk-width-container">
                            <ol class="nhsuk-breadcrumb__list">
                                <li class="nhsuk-breadcrumb__item">
                                    <a class="nhsuk-breadcrumb__link" href="?php echo esc_url(home_url('/')); ?>">Home</a>
                                </li>
                            </ol>
                            <p class="nhsuk-breadcrumb__back"><a class="nhsuk-breadcrumb__backlink" href="/">Home</a>
                            </p>
                        </div>
                    </nav>
                    <h1 class="panel-intro__title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'nhsinform' ); ?></h1>
                    <div class="panel-intro__desc nhsuk-body">
                        <p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links in menu?', 'nhsinform' ); 
                        //get_search_form();?>
                        	
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php //endwhile; ?>
    </main>

<?php get_footer();?>
