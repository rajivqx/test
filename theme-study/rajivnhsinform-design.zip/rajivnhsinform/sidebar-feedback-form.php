<div class="no-print push--ends">
    <a onclick ="feedbackFormTongle()" id="dropList" href="javascript:void(0)" class="js-toggle btn btn--icon btn--feedback" role="button" aria-controls="feedback" aria-expanded="true">
                
        How can we improve this page?
          <span class="icon  toggle-off" style="display:none">
                        <i class="fa fa-chevron-up f-8"></i>
                    </span>
                    <span class="icon  toggle-on">
                        <i class="fa fa-chevron-down f-8"></i>
                    </span>
    </a>
    <div id="feedback" class="feedback mystyle">
        <h2 class="primary-color no-margin">
            Help us improve NHS inform
        </h2>
        <div style="display:none;" id="feedback-message" class="alert">
            <!-- Replaced by JS -->
            <h2>Thank You</h2>
            <p>Your feedback has been received</p>
        </div>
         <form method="post" id="feedbackForm">
            <div class="form-row">
                <p class="dark-grey-2">
                    Don’t include personal information e.g. name, location or any personal health conditions.
                </p>
            </div>
            <div class="form-row">
                <label for="Email" class="form-control-label required">
                    Email Address
                </label>
                <input id="Email" name="email" class="form-control" type="text" maxlength="255" autocomplete="off" >
                <span class="block delta dark-grey-2">
                    e.g. you@example.com
                </span>
                <span class="field-validation-error push-half--bottom"></span>
            </div>
            <div class="form-row">
                <label for="Message" class="form-control-label required">
                    Message
                </label>
                <input id="Message" name="message" class="form-control" type="text" maxlength="500" autocomplete="off">
                <span class="block delta dark-grey-2">
                    Maximum of 500 characters
                </span>
                <span class="field-validation-error push-half--bottom"></span>
            </div>
                <div class="form-row form-row--btns">
                    <button id="feedback-submit" type="submit" class="btn btn--primary btn--icon">
                        Send feedback
                        <span class="icon">
                            <i class="fa fa-chevron-right f-8"  style="font-size: 0.8rem; padding: 8px"></i>
                        </span> 
                    </button>
                </div>
            </form>
        </div>
</div>