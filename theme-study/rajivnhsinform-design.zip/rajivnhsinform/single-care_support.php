<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();?>
<!-- Symptoms Section HTML Start -->
<div class="singleCareSupport">
<div class="bg-white-grey soft--bottom leukaemia">
  <div class="container ps-4">
    <div class="row">
      <div class="col-sm-12 singleCareBrdCrumb">
        <!-- Breadcrumb HTML Start -->
        <?php get_sidebar('breadcrumb');?>
        <!-- Breadcrumb HTML End -->
      </div>
      <div class="col-lg-9 col-sm-12 mb-4 panel-content guidetabs">
        <!-- <div class="wrapperNHS panel-content push--bottom push--top"> -->
        <div class="row">
          <div class="col col-sm-12">
            <h1 class="giga bold primary-color push--bottom">
              <?php the_title();?>
            </h1>
          </div>
          <div class="col-sm-12 illnessPart1">
            <?php 
        while(have_posts()): the_post();?>
            <?php the_content(); 
                if(comments_open() || get_comments_number()) :
        			//comments_template();
        		endif;?>
            <?php endwhile;?>
        
            <div class="jsPrevNextContainer js-guide__incremental page-navigation no-print illnessPart1"
            >
              <a
                href="javascript:void(0)"
                rel="previous"
                class="js-guide__incremental--previous nav-incremental-link page-navigation__prev"
                id="previous_page"
                style="display: block"
                onclick="nextPreButton('pre');"
              >
				  <div class="illness-mob-pagination">
					  <div class="title-part">
						  <i class="fa fa-chevron-left" aria-hidden="true"></i>
					  </div>
				  	<div>
						  <div class="nav-incremental__part" id="prePart"></div>
                  <div class="nav-incremental__title" id="prePartText"></div>
					  </div>
					
				  </div>
              
              </a>
              
              <a
                href="javascript:void(0)"
                rel="next"
                class="js-guide__incremental--previous nav-incremental-link page-navigation__next"
                id="next_page"
                style="display: block"
                onclick="nextPreButton('next');">
				  <div class="illness-mob-pagination">
					<div>
						<div class="nav-incremental__part" id="nextPart"></div>
                 	 <div class="nav-incremental__title" id="nextPartText"></div>
					  </div>  
					  <div class="title-part-1">
						  <i class="fa fa-chevron-right" aria-hidden="true"></i>
					  </div>
				  </div>				  
             
              </a>
            </div>
          </div>

          <div class="col-sm-12 col-lg-9 soft--ends illnessPart1">
            <?php if(get_field('attribution_logo')):
                $attribution_logo = get_field('attribution_logo'); 
                $imageID  = attachment_url_to_postid($attribution_logo);
                $imageData = wp_get_attachment($imageID);
            ?>
            <div class="row">
              <div class="col-sm-12 soft bg-light-grey-1">
                <img
                  src="<?php echo $attribution_logo;?>"
                  alt="<?php echo $imageData['alt'];?>"
                  title="<?php echo $imageData['title'];?>"
                />
                <?php if(get_field('attributed_to') && get_field('attributed_url')):?>
                <p class="nhsuk-body-s no-margin">
                  Source:
                  <a
                    href="<?php echo get_field('attributed_url');?>"
                    class="bold"
                    rel="external"
                    target="_blank"
                    ><?php the_field('attributed_to');?>
                    <span class="visuallyhidden"
                      >- Opens in new browser window</span
                    ></a
                  >
                </p>
                <?php endif;?>
              </div>
            </div>
            <?php endif;?>

            <div class="push--ends">
              <p class="nhsuk-body-s nhsuk-u-secondary-text-color no-margin">
                Last updated:
                <br />
                <?php  the_modified_date('d F Y'); ?>
              </p>
            </div>
            <?php get_sidebar('breadcrumb-bottom');?>
            <?php
                if(get_field('feedback_disabled')[0] !="yes"){
                    get_sidebar('feedback-form'); 
                } 
            ?>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-sm-12 mb-4 illnessPart1">
        <?php get_sidebar();?>
      </div>
    </div>
  </div>
</div>
 </div>
<?php
    get_footer();
    get_sidebar('feedback_js');
    get_sidebar('tab-pagination_js');
?>

<style type="text/css">
  .mystyle {
    display: none;
    color: blue;
  }
</style>

<style type="text/css">
  #breadcrumbs span span span span:before {
    background: url("data:image/svg+xml,%3Csvg class='nhsuk-icon nhsuk-icon__chevron-left' xmlns='http://www.w3.org/2000/svg' fill='%23005eb8' height='24' width='24' viewBox='8 0 24 24' aria-hidden='true'%3E%3Cpath d='M8.5 12c0-.3.1-.5.3-.7l5-5c.4-.4 1-.4 1.4 0s.4 1 0 1.4L10.9 12l4.3 4.3c.4.4.4 1 0 1.4s-1 .4-1.4 0l-5-5c-.2-.2-.3-.4-.3-.7z'%3E%3C/path%3E%3C/svg%3E")
      no-repeat;
    content: '';
    display: flex;
    height: 18px;
    left: 0;
    position: relative;
    top: 0;
    width: 10px;
  }
  .wp-embed-responsive .wp-block-embed .wp-block-embed__wrapper:before {
    position: relative;
  }
  .mystyle {
    display: none;
    color: blue;
  }
  .form label.required:after {
    content: ' *';
    color: #a10000;
  }
  .error {
    color: #a10000 !important;
  }
  .bg-light-grey-1 {
    width: 80%;
    margin-left: 10px !important;
  }
  .microsite_wrapper::before {
    height: 180px;
    background-color: #208da0;
  }
  .contact__title,
  .support-service__title {
    color: #666;
    display: block;
    margin: 0;
    font-weight: 300;
    left: -12px;
    position: relative;
  }
  .contact__desc,
  .support-service__desc {
    color: #333;
    display: block;
    margin: 0;
  }
  .contact__desc,
  .support-service__desc {
    color: #333;
    display: block;
    margin: 0;
    left: -12px;
    position: relative;
  }
  .gutt {
    width: 46%;
    margin: 2%;
  }
	
</style>
