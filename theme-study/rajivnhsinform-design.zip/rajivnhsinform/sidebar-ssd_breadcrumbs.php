<nav class="breadcrumb_section" aria-label="breadcrumb">
	<div class="container">
        <?php if(!empty($wp->query_string)){
        		$slug = explode('=', $wp->query_string);
        		//echo '<pre>'; print_r($slug);
        		$service_list_breadcurm_link='';
        		if($slug[0] == 'scotlands-service-directory' && !empty($slug[1])){
        			$service_list_breadcurm_link = home_url().'/'.$slug[0]; 
        		}
        }
        if(!empty($wp->request)){
        	$request_slug = explode('/', $wp->request);
        	if(count($request_slug) ==3 && $request_slug[0]=='scotlands-service-directory' && !empty($slug[1])){
        		switch ($slug[1]) {
			    case "dental-services":
			        $page_name = "Dental services";
			        break;
			    case "gp-practices":
			        $page_name = "GP practice";
			        break;
			    case "health-and-wellbeing-services":
			        $page_name = "Health and wellbeing services";
			        break;
			    case "hospitals":
			        $page_name = "Hospital";
			        break;
			    case "opticians":
			        $page_name = "Opticians";
			        break;
			    case "pharmacies":
			        $page_name = "Pharmacies";
			        break;
			    case "sexual-health-clinics":
			        $page_name = "Sexual health clinics";
			        break;
			    case "aes-and-minor-injuries-units":
			        $page_name = "A&Es and Minor Injuries Units";
			        break;
			  default:
			        $page_name = "";
			}

			$service_detail_breadcurm_link = home_url().'/'.$request_slug[0].'/'.$slug[1];
        	}

        }
        ?>
        <ol id="breadcrumbs" class="breadcrumb">
        	
         <li class="breadcrumb-item"><a href="<?php echo home_url();?>" title="Home">Home</a></li>
     	
<?php if(!empty($service_list_breadcurm_link) && !empty($slug[1])){?>
         <li class="breadcrumb-item"><a href="<?php echo $service_list_breadcurm_link;?>" title="Home"> Scotland's Service Directory</a></li>
         <?php } ?>
<?php if(count($request_slug) ==3 && !empty($service_detail_breadcurm_link) && !empty($slug[1])){?>
<li class="breadcrumb-item"><a href="<?php echo $service_detail_breadcurm_link;?>" title="Home"><?php echo $page_name;?></a></li>
<?php } ?>
        </ol>	
    </div>
</nav>