<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();?>
    <nav class="breadcrumb_section" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo home_url('');?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo home_url('');?>">campaigns</a></li>
               
            </ol>
        </div>
    </nav>
 <?php //get_sidebar('breadcrumb');?>
    <!--Alert Section HTML End-->
    <!--Banner Section HTML Start-->
    <section class="nhsuk-hero nhsuk-hero--image nhsuk-hero--image-description"
        style="background-image: url('<?php echo get_field('campaign_image');?>')">
        <div class="itsOk-wrapper" id="itsOkId">
        <div class="nhsuk-hero__overlay">
            <div class="container">
                <div class="nhsuk-hero-content nhsuk-hero-content--blue">
                    <h1><?php the_title();?></h1>
                        <?php 
                            while(have_posts()): the_post();
                                the_content();
                            endwhile;
                        ?>
                </div>
            </div>
        </div>
    </div>
    </section>
    <?php 
    global $wp;
    if(trim($wp->request) =="campaigns/its-ok-to-ask"){
       get_template_part('template-parts/content','campaigns-it-is-ok');
    }else if(trim($wp->request) =="campaigns/take-it-right-outside"){
       get_template_part('template-parts/content','campaigns-take-it-right-outside');
    }else{
     get_template_part('template-parts/content','campaigns-default');
    } ?>
<?php get_footer();?>

