<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nhsinform
 */

get_header();?>

    <!--Alert Section HTML Start-->
    <section class="alert alert--newwarning alert--global ">
        <div class="container">
            <p><span>Information about&nbsp;</span><a data-id="22182"
                    href="/illnesses-and-conditions/infections-and-poisoning/streptococcus-a-strep-a/"
                    title="Streptococcus A (strep A)">Streptococcus A (Strep
                    A)</a><span><span>&nbsp;</span>and<span>&nbsp;</span></span><a data-id="22189"
                    href="/illnesses-and-conditions/infections-and-poisoning/scarlet-fever/"
                    title="Scarlet fever">scarlet fever</a></p>
        </div>
    </section>

    

    <!--Alert Section HTML End-->

 
    <!--Banner Section HTML End-->

    <!-- Symptoms Section HTML Start -->
    <div class="bg-white-grey soft--bottom">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                      <!-- Breadcrumb HTML Start -->
                        <?php get_sidebar('breadcrumb');?>
                        <!-- Breadcrumb HTML End -->
                </div>

                <div class="col-lg-9 col-sm-12 mb-4 panel-content guidetabs">
                  
                    <!-- <div class="wrapperNHS panel-content push--bottom push--top"> -->
                    <div class="row">
                        <div class="col col-sm-12">
                            <h1 class="giga bold primary-color push--bottom ">
                                <?php the_title();?>
                            </h1>
                        
                            
                        </div>

                    <div class="col-sm-12">
    
                      <?php  while(have_posts()): the_post();?>
                        
                      <?php the_content(); 
                        if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;?>
                
                        <?php endwhile; ?>
                        
                        
                        
                        
                        </div>

                    

                </div>
                


                </div>

                
                <div class="col-lg-3 col-sm-12 mb-4">
                     <?= add_sidebar_info(); ?>

                    <div class="panel-content panel-content--half push--bottom">
                        <div class="push--bottom">
                    <h3 class="gamma bold primary-color push-half--bottom">
                        Also on NHS inform
                    </h3>
                    <div class="overline bg-primary-color push-half--ends"></div>
                    <ul class="nhsuk-list list-style-none">
                            <li>
                                
        
        <a href="/illnesses-and-conditions/muscle-bone-and-joints/conditions/arthritis" rel="" target="_self" data-node-id="5961">
            Arthritis
        </a>
        
                            </li>
                    </ul>
                </div>
                <div class="push--bottom">
                    <h3 class="gamma bold primary-color push-half--bottom">
                        Other health sites
                    </h3>
                    <div class="overline bg-primary-color push-half--ends"></div>
                    <ul class="nhsuk-list list-style-none">
                            <li>
                                
        
        <a href="https://livingmadeeasy.org.uk" rel="external nofollow" target="_self" data-node-id="8892">
            Disabled Living Foundation (DLF)
            <i class="fa-solid fa-up-right-from-square"></i>
        </a>
        
                            </li>
                            <li>
                                
        
        <a href="http://www.ricability.org.uk" rel="external nofollow" target="_self" data-node-id="8893">
            Rica: consumer research charity <i class="fa-solid fa-up-right-from-square"></i>
        </a>
        
                            </li>
                            <li>
                                
        
        <a href="http://www.hcpc-uk.org" rel="external nofollow" target="_self" data-node-id="4943">
            Health &amp; Care Professions Council (HCPC) <i class="fa-solid fa-up-right-from-square"></i>
        </a>
        
                            </li>
                    </ul>
                </div>
        
            </div>


            <div class="panel-content panel-content--half push--bottom text-center pc-alter">
                <button class="btn--clean border-none" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
                    <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
                </button>
            </div>

            <?php if(@get_field('hide_from_search')[0] !="yes"): ?>
<div class="panel-component">
    <?php 
        $search_status = get_field('search_status'); 
            if (isset($search_status) && !empty($search_status) && $search_status == 'Yes'): 
            $service_name = get_field('service_name');
            $search_header = get_field('search_header');
            $search_filter = get_field('search_filter');
            if (!empty($search_filter)) {
                 $filter = $search_filter;
            }else{
                $filter = null;
            }
            $url =strtolower($service_name);
            $url = str_replace('&','',$url);
            $url = str_replace(' ','-',$url);
            $main_url = home_url('scotlands-service-directory').'/'.$url;
        ?>
        <div class="ssd_search-form">
        <h3 class="bold push--bottom"><?= $search_header ?></h3>
        <label>Enter a place or postcode</label>
            
        <?php  add_search_from($main_url,$filter); ?>
        </div>
    <?php endif; ?>
    <!-- <form class="search-results form relative js-location" action="/scotlands-service-directory/health-and-wellbeing-services/" method="GET">
        <input type="hidden" name="locpt" id="locpt" class="js-locpt" value="">
        <input type="hidden" name="svctype" id="svctype" value="04">
        <label class="beta" for="q">Enter a place or postcode</label>
        <div class="relative">
            <input id="q" name="q" class="search-results__input search-results__input-geo js-geolocation__input" aria-autocomplete="list" type="search" autocomplete="off">
            <button type="button" class="search-results__geo js-geolocation">
                <span class="visuallyhidden">Near me</span>
                <span class="icon-location"></span>
            </button>
            <button type="submit" class="search-results__submit btn btn--green">
                <span class="visuallyhidden">Search Place / Postcode</span>
                <i class="fa fa-search"></i>
            </button>
        </div>
    </form> -->
</div>
<?php endif;?>

                <!-- <div class="col-lg-4 col-md-5 col-sm-12 mb-4 bg-white panel-content push--bottom push--top "> -->
                   
                </div>
                

            </div>

        </div>
    </div>

<?php
//get_sidebar();
get_footer();
