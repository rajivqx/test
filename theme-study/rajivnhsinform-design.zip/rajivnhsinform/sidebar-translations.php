
                    <?php if(@get_field('disable_info_for_me')[0] !="yes") { ?>

                        <?php //include(dirname(__FILE__) . "ssd/sidebar_infome.php");

                        //$current_collection = json_encode(array('dataset'=>1,'Id'=>2,'name'=>3));
                        //sideInfo($current_collection);
                        ?>

                        <div class="wrapperNHS panel-content push--bottom panel-content--half text-center translationLeftImg1">
                        <button aria-pressed="false" class="ifmButton remove"><span class="visuallyhidden">Add this page to Info For Me</span></button>
                        </div>
                    <?php } ?>
                    <?php if(@get_field('web_chat_disabled')[0] !="yes" ) { ?>
                        <div class="panel-content panel-content--half push--bottom text-center translationLeftImg2">
                        <button class="btn--clean informBSLbtn" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
                            <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
                        </button>
                    </div>
                    <?php } ?>  