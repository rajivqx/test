<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nhsinform
 */
?>
<?php //global $template; echo basename ($template);?>
<!-- Footer HTML Start -->
    <footer class="footer">
        <div class="container">
            <div class="row border-dotted-bottom">
                <div class="col-sm-12 col-md-10 col-lg-11">
                    <div class="row">
                        <div class="col-sm-12 col-md-2 footer_logo">
                            <?php  
                                if(is_active_sidebar('footer-left-logo')):   
                                    dynamic_sidebar('footer-left-logo'); 
                                endif;
                            ?>
                        </div>
                        <div class="col-sm-12 col-md-10">
                            <h3>NHS inform</h3>
                            <div class="row">
                            <?php 	
                                if(is_active_sidebar('footer-menu')):	
        							dynamic_sidebar('footer-menu'); 
        				 		endif;
        				 	?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-2 col-lg-1 text-end footer_logo2">
                       <?php   
                            if(is_active_sidebar('footer-right-logo')):   
                                dynamic_sidebar('footer-right-logo'); 
                            endif;
                        ?>
                </div>
            </div>
        </div>
        <!-- Footer Links -->
        <?php  
        if(is_active_sidebar('footer-bottom-content')): ?>
        <!-- Copyright Section HTML Start -->
            <div class="copyright_section mt-4">
                <div class="container">
                    <div class="row">
                        <?php dynamic_sidebar('footer-bottom-content');?>
                    </div>
                </div>
            </div>
        <?php endif;?>
        <!-- Copyright Section HTML End -->
    </footer>
    <?php wp_footer();?>
     <script type="text/javascript" src="https://www.browsealoud.com/plus/scripts/3.1.0/ba.js" crossorigin="anonymous" integrity="sha256-VCrJcQdV3IbbIVjmUyF7DnCqBbWD1BcZ/1sda2KWeFc= sha384-k2OQFn+wNFrKjU9HiaHAcHlEvLbfsVfvOnpmKBGWVBrpmGaIleDNHnnCJO4z2Y2H sha512-gxDfysgvGhVPSHDTieJ/8AlcIEjFbF3MdUgZZL2M5GXXDdIXCcX0CpH7Dh6jsHLOLOjRzTFdXASWZtxO+eMgyQ=="></script>
     <script type="text/javascript">
        (function() {
            var globals = document.createElement('script');
            globals.src = 'https://galleryuseastprod.blob.core.windows.net/velaroscripts/20046/globals.js';
            var inline = document.createElement('script');
            inline.src = 'https://eastprodcdn.azureedge.net/bundles/velaro.inline.js';
            var scriptNode = document.getElementsByTagName('script')[0];
            scriptNode.parentNode.insertBefore(globals, scriptNode);
            globals.onload = function() {
                scriptNode.parentNode.insertBefore(inline, scriptNode);
            }
            inline.onload = function() {
				Velaro.Globals.ActiveSite = 20046;
                Velaro.Globals.ActiveGroup = 4564;
                Velaro.Globals.InlineEnabled = false;
                Velaro.Globals.VisitorMonitoringEnabled = false;
                Velaro.Globals.InlinePosition = 0;
            }
        }())
    </script>
 </body>
</html>