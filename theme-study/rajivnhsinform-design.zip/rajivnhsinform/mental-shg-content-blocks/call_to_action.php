 <?php 
 $call_title = get_sub_field('title');
 $call_body = get_sub_field('body');
 $call_to_action_link = get_sub_field('call_to_action_link');

 //echo '<pre>'; print_r($call_to_action_link);

 ?>
 <div class="shg_pannel_component">
 	<?php if(!empty($call_title)){
    	echo '<h3>'.$call_title.'</h3>';
	} 
    if(!empty($call_body)){
    	echo '<p>'.$call_body.'</p>';
	} 

	if(!empty($call_to_action_link)){ 
		$title = isset($call_to_action_link['link_title']) ? $call_to_action_link['link_title']:"";
		$link_url = isset($call_to_action_link['link_url']) ? $call_to_action_link['link_url']:"";
		$target = isset($call_to_action_link['target']) ? $call_to_action_link['target']:"";

		if($target == 'new-tab'){
			$target_value = '_blank';
		}
		else {
			$target_value = '';
		}

		if (filter_var($link_url, FILTER_VALIDATE_URL)) {
		    $url = $link_url;
		} else {
		     $url = home_url().$link_url;
		}

		?>
    <div class="text-end">
        <a class="btn btn--primary btn--icon btn_guide btn--external" href="<?php echo $url;?>" target="<?php echo $target_value;?>" title="Problem solving guide"><?php echo $title;?> <span class="icon"><i class="fa-solid fa-arrow-up-right-from-square"></i></span></a>
    </div>
	 <?php } ?>
</div>