<?php 
$content_editor = get_sub_field('content_editor');
if(!empty($content_editor)){
	echo $content_editor;
}
?>