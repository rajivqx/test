<?php 
$args = wp_parse_args(
    $args,
    array(
        'tab_name' => '',
        'tab_no' => '',
    )
);
$tab_no = $args['tab_no'];
$tabName = $args['tab_name'];
$form_type = get_sub_field('activity_form_type');
$activity_questions = get_sub_field('activity_questions');

if($form_type == 0){ ?>
	<?php if(!empty($activity_questions)){?>
	<form class="shg_form">
		    <?php foreach ($activity_questions as $form_data){
		    	$question =  isset($form_data['question']) ? $form_data['question']:"";
		    	$placeholder =  isset($form_data['example_placeholder_text']) ? $form_data['example_placeholder_text']:"";
		    	$example_answer =  isset($form_data['example_answer']) ? $form_data['example_answer']:"";
		    	
		    	?>
            <div class="form-row">
            	<?php if(!empty($question)){
                echo "<label for='situation1' class='form-label'>".$question."</label>";
            	} ?>
            	
            <textarea maxlength="150" rows="4" class="form-control" id='situation1' placeholder="<?php echo htmlspecialchars($placeholder);?>"></textarea>
               
            </div>
        <?php } ?>
    </form>
<?php } 
}

else if($form_type == 'extended'){ ?>
    <?php if(!empty($activity_questions)){?>
    <form class="shg_form">
            <?php foreach ($activity_questions as $form_data){
                $question =  isset($form_data['question']) ? $form_data['question']:"";
                $placeholder =  isset($form_data['example_placeholder_text']) ? $form_data['example_placeholder_text']:"";
                $example_answer =  isset($form_data['example_answer']) ? $form_data['example_answer']:"";
                
                ?>
            <div class="form-row">
                <?php if(!empty($question)){
                echo "<label for='situation1' class='form-label'>".$question."</label>";
                } ?>
                
            <textarea maxlength="150" rows="4" class="form-control" id='situation1' placeholder="<?php echo htmlspecialchars($placeholder);?>"></textarea>
               
            </div>
        <?php } ?>
    </form>
<?php } 
}

else if($form_type == 'graph_representation'){

 if(!empty($activity_questions)){?>
	<form class="shg_form graph_view">
		    <?php 
		     $j = 1;
		    foreach ($activity_questions as $form_data){
		    	$question =  isset($form_data['question']) ? $form_data['question']:"";
		    	$placeholder =  isset($form_data['example_placeholder_text']) ? $form_data['example_placeholder_text']:"";
		    	$example_answer =  isset($form_data['example_answer']) ? $form_data['example_answer']:"";
		    	
		    	?>
            <div class="form-row">
            	<?php if(!empty($question)){
                echo "<label for='ques_".$j."' class='form-label'>".$question."</label>";
            	} ?>
            	
                <textarea maxlength="150" rows="4" class="form-control" id="ques_<?php echo $j;?>" placeholder="<?php echo htmlspecialchars($placeholder);?>"></textarea>
               
            </div>
        <?php $j++; } ?>
        <div class="form-row">
            <button type="button" class="btn btn--secondary btn--icon btn_guide mb-5" data-bs-toggle="modal" data-bs-target="#InfographicModel">View as infographic <span class="icon"><i class="fa-solid fa-circle-info"></i></span> </button>
        </div>
    </form>
<?php } ?>

 <!-- Popup HTML Start -->
    <div class="modal fade" id="InfographicModel" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="InfographicModelLabel" aria-hidden="true">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="svg_container">
                        <button type="button" class="btn btn--secondary pull-right" data-bs-dismiss="modal" aria-label="Close">Close</button>

                        <svg role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1124 678" xml:space="preserve" width="1124" height="678">
                        <title id="svgTitle"><?php echo $tab_no.'. '. $tabName;?></title>
                        <desc id="svgDescription">Please replace this text with CMS Text string for SVG Description</desc>
                        <g id="Arrows">
                            <g>
                                <path fill="none" stroke="#000000" stroke-width="5" stroke-meterlimit="20" d="M389.1,252.4c2.3-22.9,16.7-107.5,100.8-111.2"></path>
                                <polygon points="398.4,243.1 389.3,250.9 381.5,241.8 380.9,248.9 388.7,258.1 397.8,250.3"><polygon>
                                <polygon points="480.3,150.1 488.5,141.3 479.7,133.2 486.9,132.9 495.7,141.1 487.5,149.8"><polygon>
                            </g>
                            <g>
                                <path fill="none" stroke="#000000" stroke-width="5" stroke-meterlimit="20" d="M1024.4,467.9c-2.4,23.7-18.7,124.6-126.1,127.9"></path>
                                <polygon points="1015.8,475.9 1024.2,469.1 1031.4,477 1032,470.8 1024.8,462.9 1016.4,469.7"></polygon>
                                <polygon points="907.3,588.1 899.6,595.6 907.6,602.9 900.9,603 893,595.8 900.7,588.3"></polygon>
                            </g>
                            <g>
                                <path fill="none" stroke="#000000" stroke-width="5" stroke-meterlimit="20" d="M906.4,133.3c21.2,2.7,106.1,20.3,108.6,130.5"></path>
                                <polygon points="914.1,141.8 907.7,133.4 915.4,126.5 909.4,125.9 901.6,132.9 908.1,141.2"></polygon>
                                <polygon points="1007.5,254.9 1014.9,262.5 1021.8,254.5 1022,261.1 1015.1,269 1007.7,261.6"></polygon>
                            </g>
                            <g>
                                <path fill="none" stroke="#000000" stroke-width="5" stroke-meterlimit="20" d="M489.5,590c-25-3.2-113.9-22.1-117-130.2"></path>
                                <polygon points="479.3,580.3 487.9,589.8 477.2,597.2 485.3,598 496,590.6 487.6,581.1"></polygon>
                                <polygon points="382.6,469.5 372.7,461.2 363.2,470 363,462.7 372.5,454 382.4,462.2"></polygon>
                            </g>
                        </g>
                        <?php 
             $k = 1;
            foreach ($activity_questions as $form_data){
                $question =  isset($form_data['question']) ? $form_data['question']:"";
                        if($k ==1){
                        echo '<g>
                            <rect x="0.7" y="72.1" fill="#ffffff" stroke="#000000" stroke-miterlimit="20" width="350" height="80"></rect>
                            <rect x="10.7" y="79.3" fill="#ffffff" width="330" height="60"></rect> 
                            <text id="graphicQuestion'.$k.'" transform="matrix(1 0 0 1 5.61 87.81)" font-size="14"></text>
                            <rect x="0.2" y="63.6" fill="#00A5B5" width="175" height="8"></rect>
                            <rect x="176.2" y="152.6" fill="#9465A9" width="175" height="8"></rect>
                            <rect x="7.7" y="1.2" fill="#ffffff" width="330" height="53.7"></rect> 
                            <text id="question'.$k.'" transform="matrix(1 0 0 1 7.61 52.81)" font-size="14" font-weight="bold">'.$question.' </text>
                        </g>';
                    }
                    
                    elseif ($k ==2) {
                        
                           
                    echo '<g>
                            <rect x="218.7" y="318.1" fill="#ffffff" stroke="#000000" stroke-miterlimit="20" width="350" height="80"></rect>
                            <rect x="228.7" y="329.1" fill="#ffffff" width="330" height="60"></rect> 
                            <text id="graphicQuestion'.$k.'" transform="matrix(1 0 0 1 223.61 333.81)" font-size="14"></text>
                            <rect x="218.2" y="309.6" fill="#00A5B5" width="175" height="8"></rect>
                            <rect x="394.2" y="398.6" fill="#9465A9" width="175" height="8"></rect>
                            <rect x="225.7" y="279" fill="#ffffff" width="330" height="21.9"></rect> 
                            <text id="question'.$k.'" transform="matrix(1 0 0 1 225.61 298.81)" font-size="14" font-weight="bold">'.$question.'</text>
                        </g>';
                    }
                     elseif ($k ==3) {
                        echo '<g>
                            <rect x="512.7" y="84.1" fill="#ffffff" stroke="#000000" stroke-miterlimit="20" width="350" height="80"></rect>
                            <rect x="522.7" y="91.6" fill="#ffffff" width="330" height="60"></rect> <text id="graphicQuestion'.$k.'" transform="matrix(1 0 0 1 517.61 99.81)" font-size="14"></text>
                            <rect x="512.2" y="75.6" fill="#00A5B5" width="175" height="8"></rect>
                            <rect x="688.2" y="164.6" fill="#9465A9" width="175" height="8"></rect>
                            <rect x="519.7" y="45" fill="#ffffff" width="330" height="21.9"></rect> 
                            <text id="question'.$k.'" transform="matrix(1 0 0 1 519.61 64.81)" font-size="14" font-weight="bold">'.$question.' </text>
                        </g>';
                    }
                     elseif ($k ==4) {
                        echo '<g>
                            <rect x="768.7" y="322.1" fill="#ffffff" stroke="#000000" stroke-miterlimit="20" width="350" height="80"></rect>
                            <rect x="778.7" y="329.6" fill="#ffffff" width="330" height="60"></rect> 
                            <text id="graphicQuestion'.$k.'" transform="matrix(1 0 0 1 773.61 337.81)" font-size="14"></text>
                            <rect x="768.2" y="313.6" fill="#00A5B5" width="175" height="8"></rect>
                            <rect x="944.2" y="402.6" fill="#9465A9" width="175" height="8"></rect>
                            <rect x="775.7" y="283" fill="#ffffff" width="330" height="21.9"></rect> 
                            <text id="question'.$k.'" transform="matrix(1 0 0 1 775.61 302.81)" font-size="14" font-weight="bold">'.$question.'</text>
                        </g>';
                    }
                     elseif ($k ==5) {
                        echo '<g>
                            <rect x="523.7" y="558.1" fill="#ffffff" stroke="#000000" stroke-miterlimit="20" width="350" height="80"></rect>
                            <rect x="533.7" y="565.4" fill="#ffffff" width="330" height="60"></rect> 
                            <text id="graphicQuestion'.$k.'" transform="matrix(1 0 0 1 528.61 573.81)" font-size="14"></text>
                            <rect x="523.2" y="549.6" fill="#00A5B5" width="175" height="8"></rect>
                            <rect x="699.2" y="638.6" fill="#9465A9" width="175" height="8"></rect>
                            <rect x="530.7" y="519" fill="#ffffff" width="330" height="21.9"></rect> 
                            <text id="question'.$k.'" transform="matrix(1 0 0 1 530.61 538.81)" font-size="14" font-weight="bold">'.$question.'</text>
                        </g>';
                    }
                        $k++;
                        } ?>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Popup HTML End -->

<?php }
else if($form_type == 'feedback_loop'){
	 if(!empty($activity_questions)){?>


	<form class="shg_form">
		 
		    <?php 
		    $i =1;
		    $total_count =  count($activity_questions);
            echo '<p><strong>Example</strong></p>';
		    foreach ($activity_questions as $form_data){
		    	$question =  isset($form_data['question']) ? $form_data['question']:"";
		    	$placeholder =  isset($form_data['example_placeholder_text']) ? $form_data['example_placeholder_text']:"";
		    	$example_answer =  isset($form_data['example_answer']) ? $form_data['example_answer']:"";
		    ?>

		    <?php if(empty($placeholder) && !empty($example_answer) && !empty($question)){?>
		    
		    <?php if($i==1 || $i==3){
		    	echo '<div class="shg_section">';
		    }?>
            <div class="form-row">
            	<?php if(!empty($question)){
                echo "<label for='situation1' class='form-label'>".$question."</label>";
            	} 

            	if(empty($placeholder) && !empty($example_answer)){
            		$textarea_readOnly = 'readonly';
            	}
            	else if(!empty($placeholder) && empty($example_answer)){
            		$textarea_readOnly = '';
            	}
            	else {
            		$textarea_readOnly = '';
            	}

            	?>

                <textarea <?php echo $textarea_readOnly;?> maxlength="150" rows="4" class="form-control" id='situation1' placeholder="<?php echo htmlspecialchars($placeholder);?>"><?php echo $example_answer;?></textarea>
               
            </div>
          <?php if($i==1){
		            echo '<div class="shg_only_img_block">
		            <i class="fa-solid fa-angle-down"></i>
		           </div>';
           } ?>
           <?php if($i==2 || $i == $total_count){
           	echo '</div>';
           }
           if($i==2){
           	echo '<div class="shg_only_img_block">
                <img src="'.get_template_directory_uri().'/assets/images/rotate.png" alt="">
            	</div>';
           } 

       } else if(empty($placeholder) && empty($example_answer) && !empty($question)){?>

       	<div class="form-row fill_act_response">
            	<?php if(!empty($question)){
                echo "<label for='respLable_1' class='form-label'>".$question."</label>";
            	} ?>
            	
                <textarea maxlength="150" rows="4" class="form-control" id='fillResp_<?php echo $i;?>' placeholder="<?php echo htmlspecialchars($placeholder);?>"></textarea>
               
            </div>

      <?php }?>


        <?php $i++; 
    } ?>
        
    </form>
<?php }
    
}
else if($form_type == 'feedback_loop_response'){
	if(!empty($activity_questions)){
	?>
		<form class="shg_form activity_response">
			<?php 
		    $i =1;
		    $total_count =  count($activity_questions);
		    foreach ($activity_questions as $form_data){
		    	$question =  isset($form_data['question']) ? $form_data['question']:"";
		    	$placeholder =  isset($form_data['example_placeholder_text']) ? $form_data['example_placeholder_text']:"";
		    	$example_answer =  isset($form_data['example_answer']) ? $form_data['example_answer']:"";

	if(empty($placeholder) && empty($example_answer) && !empty($question)){?>
		   
		<?php if($i==1 || $i==3){
      	 echo '<div class="shg_section response_1">';
      	}
      	 ?>
      	 <?php if(!empty($question)){
            echo '<h3>'.$question.'</h3>';
          } ?>

            <hr>
            <p id="actResp_<?php echo $i;?>"></p>

            <?php if($i==1){
            echo '<div class="shg_only_img_block">
                <i class="fa-solid fa-angle-down"></i>
            </div>';
        	}
            ?>
           

		<?php if($i==2 || $i == $total_count){
           	echo '</div>';
           } 
       
       if($i==2){
        echo '<div class="shg_only_img_block">
            <img src="'.get_template_directory_uri().'/assets/images/rotate.png" alt="">
        </div>';
    	}
         ?>
        
    <?php  } $i++; }  ?>
    </form>
<?php } }
