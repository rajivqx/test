<?php $alert_box_content_block = get_sub_field('alert_box_content_block');?>
<div class="shg_alert shg_alert_info">
        <span class="shg_alert_icon">
            <i class="fa-solid fa-circle-info"></i>
        </span>
        <div>
           <?php if(!empty($alert_box_content_block)){
              echo $alert_box_content_block;
           }?>
        </div>
    </div>