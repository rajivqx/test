<?php
$stackitems_heading = get_sub_field('stackitems_heading'); 
$stack_theme = get_sub_field('stack_theme'); 
$stack_items = get_sub_field('stack_items');
//echo '<pre>'; print_r($stack_items);

if(!empty($stackitems_heading)){
  echo '<h2 class="pt-0 primary-color">'.$stackitems_heading.'</h2>';
}

if($stack_theme == 'default'){

	if(!empty($stack_items)){
	?>

	<div class="shg_block">
      
		<?php foreach($stack_items as $items){

       echo '<div class="shg_block_item">';
         if(!empty($items['heading'])){
         	echo '<h3>'.$items['heading'].'</h3>';
         }

         echo isset($items['list_items']) ? $items['list_items']:"";

       echo '</div>';
   	    } ?>
   </div>
<?php } 
}
else if($stack_theme == 'arrowed'){
	if(!empty($stack_items)){
	?>

	 <div class="shg_block shg_block_arrow">

        <?php foreach($stack_items as $items){

       echo '<div class="shg_block_item">';
         if(!empty($items['heading'])){
         	echo '<h3>'.$items['heading'].'</h3>';
         }

         echo isset($items['list_items']) ? $items['list_items']:"";

       echo '</div>';
   	    } ?>

    </div>
    <?php }
}
else if ($stack_theme == 'two-toned'){
	if(!empty($stack_items)){
	?>
	<div class="shg_block shg_block_twotone">
         <?php foreach($stack_items as $items){

       echo '<div class="shg_block_item">';
         if(!empty($items['heading'])){
         	echo '<h3>'.$items['heading'].'</h3>';
         }

         echo isset($items['list_items']) ? $items['list_items']:"";

       echo '</div>';
   	    } ?>
    </div>
 <?php }
}
?>