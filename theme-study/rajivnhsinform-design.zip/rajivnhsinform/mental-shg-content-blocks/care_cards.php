<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nhsinform
 */
?>

<div class="care_card">
	<?php
	$component_type = get_sub_field('component_type');
	$care_color = isset($component_type['value']) ? $component_type['value']:"";
	$component_title = get_sub_field('component_title');
	$component_contents = get_sub_field('component_contents');
    ?>									
										<?php if(!empty($component_title )){?>
                                        <div class="hero_banner_content <?php echo $care_color;?>">
                                            <h3><?php echo $component_title;?> </h3>
                                            <span class="hero_arrow"></span>
                                        </div>
                                    	<?php } ?>

                                    	<?php if(!empty($component_contents)){?>
                                        <div class="care_card_body">
                                        	<?php echo $component_contents;?>

                                            <!--<p>This self-help guide is intended for people with mild-to-moderate symptoms of depression.</p>
                                            <p>If you're feeling distressed, in a state of despair, suicidal or in need of emotional support you can phone NHS 24 on 111.</p>
                                            <p>For an emergency ambulance phone 999.</p>-->
                                        </div>
                                    <?php } ?>
</div>

	