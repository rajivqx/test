<?php
/**
 * Plugin Name: Gutenberg Block Pattern Example
 * Plugin URI: https://example.com
 * Description: A simple block pattern plugin for Gutenberg.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 */

wp.blocks.registerBlockPattern(
  'my-plugin/simple-pattern', // Pattern slug
  {
    title: 'Simple Pattern', // Pattern title
    description: 'A simple block pattern.', // Pattern description
    categories: ['text'], // Pattern categories
    content: [
      // Pattern content
      [
        'core/heading',
        {
          level: 2,
          content: 'Hello World!'
        }
      ],
      [
        'core/paragraph',
        {
          content: 'This is a simple block pattern.'
        }
      ]
    ]
  }
);
?>