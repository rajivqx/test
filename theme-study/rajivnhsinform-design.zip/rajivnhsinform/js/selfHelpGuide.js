var viewModelSHG;
ko.bindingHandlers.showModal = {
    init: function (e, t) {
        $(e).modal({ backdrop: "static", keyboard: !0, show: !1 });
    },
    update: function (e, t) {
        var o = t();
        ko.utils.unwrapObservable(o) ? ($(e).modal("show"), $("input", e).focus()) : $(e).modal("hide");
    },
};
var workingDomain = "https://nhs24-shgapi-live.azurewebsites.net/",
    url = window.location.href,
    arr = url.split("/"),
    protocol = arr[0],
    trackingGoogleID = "UA-840144-9",
    hotJarAdded = !1,
    injectGT = !1;
function Question() {
    (this.nodeId = ko.observable(0)),
        (this.nodeType = ko.observable(0)),
        (this.questionTop = ko.observable("")),
        (this.questionBottom = ko.observable("")),
        (this.questionShared = ko.observable("")),
        (this.protocol = ko.observable()),
        (this.answers = ko.observable()),
        (this.endPoint = ko.observable()),
        (this.exceptions = ko.observableArray),
        (this.selectedAnswer = ko.observable()),
        (this.selectedAnswers = ko.observableArray([])),
        (this.numberOfAnswers = ko.observable(0)),
        (this.answerText = ko.observable("")),
        (this.belongsToProtocol = ko.observable(""));
}
function Exception(e) {
    (this.id = ko.observable(e.id)), (this.title = ko.observable(e.title)), (this.description = ko.observable(e.description)), (this.lookups = ko.observableArray(e.lookups)), (this.selectedLookup = ko.observable());
}
function SHGViewModel() {
    var e = this;
    (e.ProtocolList = ko.observableArray([])),
        (e.ProtocolName = ko.observable("NHS 24 Self-help guide")),
        (e.Questions = ko.observableArray([])),
        (e.Exceptions = ko.observableArray([])),
        (e.CurrentQuestion = ko.observable()),
        (e.CurrentQuestionType = ko.observable()),
        (e.CurrentSingleAnswer = ko.observable(1e3)),
        (e.CurrentAnswers = ko.observableArray([])),
        (e.AnswerChanged = ko.observable(!1)),
        (e.TimesCalled = ko.observable(0)),
        (e.openDialog = ko.observable(!1)),
        (e.sessionId = ko.observable($("#userGUID").val())),
        (e.hidePrevious = ko.observable(!1)),
        (e.hideNext = ko.observable(!1)),
        (e.groupedProtocols = ko.observableArray([])),
        (e.disableNext = ko.observable(!1)),
        (e.canDownload = ko.observable(!1)),
        (e.PDFLink = ko.observable("")),
        (e.log = ko.observable(!0)),
        (e.shgTitle = ko.observable("")),
        (e.shgContent = ko.observable("")),
        (e.showIntro = ko.observable(!0)),
        (e.showStatement = ko.observable(!1)),
        (e.showExceptions = ko.observable(!1)),
        (e.showReturn = ko.observable(!0)),
        (e.passedUmbracoId = ko.observable(parseInt($("#protocolID").val()))),
        (e.init = function () {
            e.ProtocolList([]),
                e.ProtocolName("NHS 24 Self-help guide"),
                e.Questions([]),
                e.Exceptions([]),
                e.CurrentQuestion(),
                e.CurrentQuestionType(0),
                e.CurrentAnswers([]),
                e.AnswerChanged(!1),
                e.hidePrevious(!0),
                e.hideNext(!1),
                e.canDownload(!1),
                e.showIntro(!1),
                e.showStatement(!0),
                e.showExceptions(!1),
                e.showReturn(!0),
                "false" === e.getParameterByName("log") && e.log(!1);
            var t = { log: e.log() };
            ("" === e.getParameterByName("umbid") || e.TimesCalled() > 0) && 1e3 === e.passedUmbracoId()
                ? $.ajax({
                      url: workingDomain + "umbraco/surface/SHG/getProtocolListJSONP/",
                      data: t,
                      jsonpCallback: "getProtocolList",
                      dataType: "jsonp",
                      success: function (t) {
                          e.shgTitle(t.title), e.shgContent(t.content), e.ProtocolList(t.protocolList), e.groupProtocols(), equalheight(".page-block");
                      },
                      error: function (e, t, o) {
                          401 === e.status && ajaxerror(e);
                      },
                  })
                : 1e3 !== e.passedUmbracoId()
                ? (e.CurrentSingleAnswer(e.passedUmbracoId()), e.showReturn(!1), e.CurrentQuestionType(5), e.TimesCalled(1), e.next())
                : (e.CurrentSingleAnswer(e.getParameterByName("umbid")), e.showReturn(!1), e.CurrentQuestionType(5), e.TimesCalled(1), e.next());
        }),
        (e.groupProtocols = function () {
            var t = [],
                o = [];
            t.push(o);
            for (var n = 0; n < e.ProtocolList().length; n += 1) o.push(e.ProtocolList()[n]), (n + 1) % 2 == 0 && ((o = []), t.push(o));
            e.groupedProtocols(t);
        }),
        (e.getParameterByName = function (e) {
            e = e.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var t = new RegExp("[\\?&]" + e + "=([^&#]*)").exec(location.search);
            return null === t ? "" : decodeURIComponent(t[1].replace(/\+/g, " "));
        }),
        (e.loadProtocol = function (t) {
            var o = { umbID: t.nodeID, exceptions: "", userId: e.sessionId(), log: e.log() };
            $.ajax({
                url: workingDomain + "umbraco/surface/SHG/getQuestion/",
                jsonpCallback: "getQuestion",
                data: o,
                dataType: "jsonp",
                success: function (t) {
                    5 === t.nodeType ? e.setProtocolQuestion(t) : e.setQuestion(t);
                },
                error: function (e, t, o) {
                    401 === e.status && ajaxerror(e);
                },
            });
        }),
        (e.previous = function () {
            var t = e.Questions.indexOf(e.CurrentQuestion());
            !0 === e.hideNext() && 4 !== e.CurrentQuestionType() && e.Questions(e.Questions.splice(0, t)),
                0 !== t &&
                    (e.CurrentQuestionType(e.Questions()[t - 1].nodeType()),
                    e.CurrentQuestion(e.Questions()[t - 1]),
                    5 === e.CurrentQuestionType()
                        ? e.CurrentSingleAnswer(e.CurrentQuestion().protocol().nextNode)
                        : 1 === e.CurrentQuestionType()
                        ? e.CurrentAnswers(e.CurrentQuestion().selectedAnswers())
                        : e.CurrentSingleAnswer(e.CurrentQuestion().selectedAnswer()),
                    t - 1 == 0 && (e.hidePrevious(!0), e.AnswerChanged(!0), e.showStatement(!0), e.showExceptions(!1), e.Questions(e.Questions.splice(0, t)))),
                e.ProtocolName(e.CurrentQuestion().belongsToProtocol()),
                e.hideNext(!1);
        }),
        (e.next = function () {
            if (e.disableNext()) alert("Please answer all questions before continuing.");
            else if (e.showIntro() && e.Questions().length > 0) e.showIntro(!1), e.showStatement(!0);
            else if (e.showStatement() && e.Exceptions().length > 0) e.showStatement(!1), e.showExceptions(!0);
            else if ((e.showStatement() && e.Questions().length > 0 && e.showStatement(!1), e.validateAgeLookup(e.Exceptions())))
                if ((e.hidePrevious(!1), !0 === e.AnswerChanged())) {
                    var t = "",
                        o = 1,
                        n = !1;
                    if (
                        ($.each(e.Exceptions(), function () {
                            void 0 === this.selectedLookup() && (n = !0), (t += this.title() + "$" + this.selectedLookup()), o !== e.Exceptions().length && (t += "|"), o++;
                        }),
                        n)
                    )
                        return e.hidePrevious(!0), void alert("Please answer all questions before continuing.");
                    if (0 === e.CurrentQuestionType() || 2 === e.CurrentQuestionType() || 3 === e.CurrentQuestionType() || 5 === e.CurrentQuestionType()) {
                        var s = 0;
                        5 === e.CurrentQuestionType()
                            ? (s = e.CurrentSingleAnswer())
                            : $.each(e.CurrentQuestion().answers().answersList, function () {
                                  this.id === e.CurrentSingleAnswer() && (s = this.nextNode);
                              });
                        var r = {
                            umbID: s,
                            exceptions: t,
                            userId: e.sessionId(),
                            log: e.log(),
                            currentNodeId: void 0 === e.CurrentQuestion() ? 0 : e.CurrentQuestion().nodeId,
                            currentAnswer: void 0 === e.CurrentQuestion() ? "" : e.CurrentQuestion().answerText,
                        };
                        $.ajax({
                            url: workingDomain + "umbraco/surface/SHG/getQuestion/",
                            jsonpCallback: "getQuestion",
                            data: r,
                            dataType: "jsonp",
                            success: function (t) {
                                !0 === t.error
                                    ? (alert("We're sorry, the protocol or question you have tried to access no longer exists."), e.init())
                                    : 5 === t.nodeType
                                    ? e.setProtocolQuestion(t)
                                    : (doGoogleTracking(t.trackingUrl), e.setQuestion(t));
                            },
                            error: function (e, t, o) {
                                401 === e.status && ajaxerror(e);
                            },
                        });
                    } else if (1 === e.CurrentQuestionType())
                        if (0 === e.CurrentAnswers().length) alert("Please select at least one answer");
                        else {
                            var i = 0;
                            $.each(e.CurrentAnswers(), function (t) {
                                $.each(e.CurrentQuestion().answers().answersList, function () {
                                    this.id === e.CurrentAnswers()[t] && (i += this.score);
                                });
                            }),
                                $.each(e.CurrentQuestion().answers().answerScores, function () {
                                    i >= this.greaterThan && e.CurrentSingleAnswer(this.nextNode);
                                });
                            r = {
                                umbID: e.CurrentSingleAnswer(),
                                exceptions: t,
                                userId: e.sessionId(),
                                log: e.log(),
                                currentNodeId: void 0 === e.CurrentQuestion() ? 0 : e.CurrentQuestion().nodeId,
                                currentAnswer: void 0 === e.CurrentQuestion() ? "" : e.CurrentQuestion().answerText,
                            };
                            $.ajax({
                                url: workingDomain + "umbraco/surface/SHG/getQuestion/",
                                jsonpCallback: "getQuestion",
                                data: r,
                                dataType: "jsonp",
                                success: function (t) {
                                    doGoogleTracking(t.trackingUrl), e.CurrentAnswers([]), 5 === t.nodeType ? e.setProtocolQuestion(t) : e.setQuestion(t);
                                },
                                error: function (e, t, o) {
                                    401 === e.status && ajaxerror(e);
                                },
                            });
                        }
                } else {
                    var a = e.Questions.indexOf(e.CurrentQuestion());
                    a + 1 < e.Questions().length &&
                        (e.CurrentQuestion(e.Questions()[a + 1]),
                        e.ProtocolName(e.Questions()[a + 1].belongsToProtocol()),
                        e.CurrentQuestionType(e.Questions()[a + 1].nodeType()),
                        e.CurrentSingleAnswer(e.CurrentQuestion().selectedAnswer()),
                        e.CurrentAnswers(e.CurrentQuestion().selectedAnswers()),
                        4 === e.CurrentQuestionType()
                            ? (e.logRoute(), e.hideNext(!0))
                            : 5 !== e.CurrentQuestionType() && 1 !== e.CurrentQuestionType()
                            ? ($.each(e.CurrentQuestion().answers().answersList, function () {
                                  0 === this.nextNode ? e.hideNext(!0) : e.hideNext(!1);
                              }),
                              e.hideNext() && alert("This question appears to be broken. Please fix this before it goes live!"))
                            : e.AnswerChanged(!0));
                }
            else alert("The age you have entered is invalid!");
        }),
        e.CurrentSingleAnswer.subscribe(function (t) {
            if (e.Questions().length > 0) {
                var o = e.Questions.indexOf(e.CurrentQuestion());
                0 !== o && e.CurrentQuestion().selectedAnswer() !== t
                    ? (e.Questions(e.Questions.splice(0, o)),
                      e.CurrentQuestion().selectedAnswer(t),
                      void 0 !== e.CurrentQuestion().answers() &&
                          null !== e.CurrentQuestion().answers() &&
                          $.each(e.CurrentQuestion().answers().answersList, function () {
                              this.id === t && e.CurrentQuestion().answerText(this.answerText);
                          }),
                      e.Questions.push(e.CurrentQuestion()),
                      e.AnswerChanged(!0))
                    : 0 === o && e.CurrentQuestion().selectedAnswer() !== t
                    ? (e.Questions.removeAll(),
                      e.CurrentQuestion().selectedAnswer(t),
                      void 0 !== e.CurrentQuestion().answers() &&
                          null !== e.CurrentQuestion().answers() &&
                          $.each(e.CurrentQuestion().answers().answersList, function () {
                              this.id === t && e.CurrentQuestion().answerText(this.answerText);
                          }),
                      e.Questions.push(e.CurrentQuestion()),
                      e.AnswerChanged(!0))
                    : e.AnswerChanged(!1);
            } else e.AnswerChanged(!0);
            e.shouldDisableNext();
        }),
        e.CurrentAnswers.subscribe(function (t) {
            if (e.Questions().length > 0) {
                var o = e.Questions.indexOf(e.CurrentQuestion());
                if (0 !== o && e.CurrentQuestion().numberOfAnswers() !== t.length && t.length > 0) {
                    if ((e.Questions(e.Questions.splice(0, o)), e.CurrentQuestion().selectedAnswers(t), e.CurrentQuestion().numberOfAnswers(t.length), void 0 !== e.CurrentQuestion().answers())) {
                        var n = "";
                        $.each(e.CurrentAnswers(), function (t) {
                            $.each(e.CurrentQuestion().answers().answersList, function () {
                                this.id === e.CurrentAnswers()[t] && (n += this.answerText + ", ");
                            });
                        }),
                            e.CurrentQuestion().answerText(n.substring(0, n.length - 2));
                    }
                    e.Questions.push(e.CurrentQuestion()), e.AnswerChanged(!0);
                } else if (0 === o && e.CurrentQuestion().numberOfAnswers() !== t.length && t.length > 0) {
                    if ((e.Questions.removeAll(), e.CurrentQuestion().selectedAnswers(t), e.Questions.push(e.CurrentQuestion()), e.CurrentQuestion().numberOfAnswers(t.length), void 0 !== e.CurrentQuestion().answers())) {
                        n = "";
                        $.each(e.CurrentAnswers(), function (t) {
                            $.each(e.CurrentQuestion().answers().answersList, function () {
                                this.id === e.CurrentAnswers()[t] && (n += this.answerText + ",");
                            });
                        }),
                            e.CurrentQuestion().answerText(n.substring(0, n.length - 2));
                    }
                    e.AnswerChanged(!0);
                } else if (o + 1 < e.Questions().length && 0 === t.length) {
                    if ((e.Questions(e.Questions.splice(0, o)), e.CurrentQuestion().selectedAnswers(t), e.CurrentQuestion().numberOfAnswers(t.length), void 0 !== e.CurrentQuestion().answers())) {
                        n = "";
                        $.each(e.CurrentAnswers(), function (t) {
                            $.each(e.CurrentQuestion().answers().answersList, function () {
                                this.id === e.CurrentAnswers()[t] && (n += this.answerText + ", ");
                            });
                        }),
                            e.CurrentQuestion().answerText(n.substring(0, n.length - 2));
                    }
                    e.Questions.push(e.CurrentQuestion()), e.AnswerChanged(!0);
                }
            } else e.AnswerChanged(!0);
            e.shouldDisableNext();
        }),
        (e.reviewAnswers = function () {
            e.canDownload(!1), e.openDialog(!0);
        }),
        (e.closeDialog = function () {
            e.canDownload(!1), e.openDialog(!1);
        }),
        (e.setProtocolQuestion = function (t) {
            var o = new Question();
            o.nodeId(t.nodeID),
                o.nodeType(t.nodeType),
                o.protocol(t),
                o.belongsToProtocol(t.protocolName),
                e.ProtocolName(t.protocolName),
                e.Questions.push(o),
                e.CurrentQuestion(o),
                e.CurrentQuestionType(t.nodeType),
                e.CurrentSingleAnswer(t.nextNode),
                $.each(t.exceptions, function (o) {
                    var n = !1;
                    $.each(e.Exceptions(), function () {
                        this.id() === t.exceptions[o].id && (n = !0);
                    }),
                        !1 === n && e.Exceptions.push(new Exception(t.exceptions[o]));
                }),
                0 === t.nextNode ? (e.hideNext(!0), alert("This question appears to be broken. Please fix this before it goes live!")) : e.hideNext(!1),
                1 === e.Questions().length ? e.hidePrevious(!0) : e.hidePrevious(!1),
                e.shouldDisableNext();
        }),
        (e.setQuestion = function (t) {
            var o = new Question();
            o.nodeId(t.nodeID),
                o.nodeType(t.nodeType),
                o.questionTop(t.questionTop),
                o.questionBottom(t.questionBottom),
                o.questionShared(t.questionShared),
                o.protocol(t.protocol),
                o.answers(t.answers),
                o.endPoint(t.endPoint),
                o.exceptions(t.exceptions),
                o.belongsToProtocol(t.belongsToProtocol),
                e.ProtocolName(t.belongsToProtocol),
                e.Questions.push(o),
                e.CurrentQuestion(o),
                e.CurrentQuestionType(t.nodeType),
                3 === o.nodeType() ? e.CurrentSingleAnswer(o.answers().answersList[0].id) : e.CurrentSingleAnswer(1e3),
                4 === o.nodeType()
                    ? (e.logRoute(), e.hideNext(!0))
                    : 1 !== o.nodeType() &&
                      ($.each(t.answers.answersList, function () {
                          0 === this.nextNode ? e.hideNext(!0) : e.hideNext(!1);
                      }),
                      e.hideNext() && alert("This question appears to be broken. Please fix this before it goes live!")),
                e.shouldDisableNext();
        }),
        (e.shouldDisableNext = function () {
            1e3 === e.CurrentSingleAnswer() && 1 !== e.CurrentQuestionType() ? e.disableNext(!0) : e.disableNext(!1);
        }),
        (e.submitLocalServiceInfo = function () {
            !0 === validateInput() && e.concatonateUrl();
        }),
        (e.validateAgeLookup = function (e) {
            var t = !0;
            return (
                $.each(e, function () {
                    if ("Age" === this.title()) {
                        var e = parseInt(this.selectedLookup());
                        (isNaN(e) || this.selectedLookup().toLowerCase().includes("e") || e < 0 || e > 125 || this.selectedLookup().toLowerCase().includes(".")) && (t = !1);
                    }
                }),
                t
            );
        }),
        (e.concatonateUrl = function () {
            $.ajax({
                url: "https://api.postcodes.io/postcodes/" + $("#txtPostTown").val(),
                type: "GET",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (t) {
                    var o = shg_js_object.home_url+"/scotlands-service-directory/" + e.getDataset(e.CurrentQuestion().endPoint().dataset);
                    (o += "?locpt=" + t.result.latitude + "%2C" + t.result.longitude),
                        (o += "&searchTerm=" + $("#txtPostTown").val()),
                        null !== e.CurrentQuestion().endPoint().serviceType &&
                            void 0 !== e.CurrentQuestion().endPoint().serviceType &&
                            "hwb" === e.CurrentQuestion().endPoint().dataset &&
                            (o += "&svctype=" + e.CurrentQuestion().endPoint().serviceType),
                        (window.location.href = o);
                },
                error: function (e, t, o) {
                    alert("Please enter a valid postcode");
                },
            });
        }),
        (e.getDataset = function (e) {
            switch (e) {
                case "hwb":
                    return "health-and-wellbeing-services";
                case "accident-and-emergency":
                    return "aes-and-minor-injuries-units";
                case "dentist":
                    return "dental-services";
                case "gp-practice":
                    return "gp-practices";
                case "hospital":
                    return "hospitals";
                case "optician":
                    return "opticians";
                case "pharmacy":
                    return "pharmacies";
                case "sexual-health-clinic":
                    return "sexual-health-clinics";
                default:
                    return "health-and-wellbeing-services";
            }
        }),
        (e.logRoute = function () {
            var t = "",
                o = 1;
            $.each(e.Questions(), function () {
                (t += this.nodeId()), o !== e.Questions().length && (t += ","), o++;
            });
            var n = "";
            (o = 1),
                $.each(e.Exceptions(), function () {
                    (n += this.title() + "$" + this.selectedLookup()), o !== e.Exceptions().length && (n += "|"), o++;
                });
            var s = { umbRIDs: t, exceptions: n, userId: e.sessionId(), log: e.log() };
            $.ajax({
                url: workingDomain + "umbraco/surface/SHG/logCompletedRoute/",
                data: s,
                dataType: "jsonp",
                jsonpCallback: "logCompletedRoute",
                success: function (e) {
                    null !== e && doGoogleTracking(e.route);
                },
                error: function (e, t, o) {
                    401 === e.status && ajaxerror(e);
                },
            });
        }),
        (e.createPDF = function () {
            var t = "";
            $.each(e.Questions(), function () {
                (t += this.nodeId() + "$" + this.answerText()), 1 !== e.Questions().length && (t += "£");
            });
            const uniqueId = Math.random().toString(36).substr(2, 15);
            //var o = { umbRoute: t, userID: e.sessionId() };
            var o = { umbRoute: t, userID: uniqueId };
            //alert(userID);
            $.ajax({
                url: workingDomain + "umbraco/surface/SHG/createPDFOfRoute/",
                jsonpCallback: "createPDFOfRoute",
                data: o,
                dataType: "jsonp",
                success: function (t) {
                   //alert(t.pdf);
                    e.PDFLink(t.pdf), e.canDownload(!0);
                },
                error: function (e, t, o) {
                    401 === e.status && ajaxerror(e);
                },
            });
        });
}
function getLocation() {
    navigator.geolocation ? navigator.geolocation.getCurrentPosition(setPosition, showError) : alert("Geolocation is not supported by this browser.");
}
function setPosition(e) {
    var t = e.coords.latitude,
        o = e.coords.longitude;
    $("#shg_hddnLat").val(t), $("#shg_hddnLng").val(o);
    var n = new google.maps.LatLng(t, o);
    new google.maps.Geocoder().geocode({ location: n }, function (e, t) {
        if (t === google.maps.GeocoderStatus.OK)
            if (e[0]) for (var o = 0; o < e[0].address_components.length; o++) "postal_code" === e[0].address_components[o].types[0] && $('[id$="txtPostTown"]').val(e[0].address_components[o].long_name);
            else window.alert("No results found");
        else window.alert("Geocoder failed due to: " + t);
    });
}
function showError(e) {
    switch (e.code) {
        case e.PERMISSION_DENIED:
            alert("User denied the request for Geolocation.");
            break;
        case e.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
        case e.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
        case e.UNKNOWN_ERROR:
            alert("An unknown error occurred.");
    }
}
function validateInput() {
    return "" === $("#txtPostTown").val() || void 0 === $("#txtPostTown").val() || "Postcode / Town" === $("#txtPostTown").val()
        ? ($("#txtPostTown").attr("value", ""), $("#txtPostTown").attr("placeholder", "Post code/Town required"), $(".search-compass-home").addClass("requiredinput"), !1)
        : !!valid_postcode($("#txtPostTown").val()) || (alert("Please enter a valid postcode"), !1);
}
function valid_postcode(e) {
    e = e.replace(/\s/g, "");
    return /([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})/i.test(e);
}
function equalheight(e) {
    var t,
        o = 0,
        n = 0,
        s = new Array();
    $(e).each(function () {
        if (((t = $(this)), $(t).height("auto"), (topPostion = t.position().top), n !== topPostion)) {
            for (currentDiv = 0; currentDiv < s.length; currentDiv++) s[currentDiv].height(o);
            (s.length = 0), (n = topPostion), (o = t.height()), s.push(t);
        } else s.push(t), (o = o < t.height() ? t.height() : o);
        for (currentDiv = 0; currentDiv < s.length; currentDiv++) s[currentDiv].height(o);
    });
}
function scrollToAnchor(e) {
    var t = $("a[name = " + e + "]").offset().top;
    $("body,html").animate({ scrollTop: t }, 500);
}
function doGoogleTracking(e) {
    var t, o, n, s, r, i;
    0 == injectGT &&
        ((t = window),
        (o = document),
        (n = "script"),
        (s = "ga"),
        (t.GoogleAnalyticsObject = s),
        (t.ga =
            t.ga ||
            function () {
                (t.ga.q = t.ga.q || []).push(arguments);
            }),
        (t.ga.l = 1 * new Date()),
        (r = o.createElement(n)),
        (i = o.getElementsByTagName(n)[0]),
        (r.async = 1),
        (r.src = "https://www.google-analytics.com/analytics.js"),
        i.parentNode.insertBefore(r, i),
        ga("create", "UA-840144-12", "auto", "SHGTracker"),
        (injectGT = !0)),
        ga("SHGTracker.send", {
            hitType: "pageview",
            page: location.pathname + e,
            hitCallback: function () {
                console.log("GA EVENT: SHG page hit, path = " + location.pathname + e);
            },
        });
}
$(document).ready(function () {
    (viewModelSHG = new SHGViewModel()), ko.applyBindings(viewModelSHG, $("#shg-container")[0]), viewModelSHG.init();
});
