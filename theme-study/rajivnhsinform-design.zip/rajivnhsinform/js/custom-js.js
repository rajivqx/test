/**
 * File custom-j.js.
 *
 * Handles toggling the custom menu for small screens and enables TAB key
 * custom support for dropdown menus.
 */

function HamburgerClick() {
  $('.hamburger_icon').on('click', function () {
    $('.microsite_overlay').css('display', 'block');
    $('body').css('overflow', 'hidden');
    $('.microsite_navigation').css('display', 'block');
  });

  $('.microsite_overlay').on('click', function () {
    $(this).hide();
    $('body').css('overflow', 'auto');
    $('.microsite_navigation').css('display', 'none');
  });

  $('.close_micro').on('click', function () {
    $(this).parents('.microsite_navigation').hide();
    $(this)
      .parents('.microsite_navigation')
      .siblings('.microsite_overlay')
      .hide();
    $('body').css('overflow', 'auto');
  });

  $('.micro_nav_slide').on('click', function () {
    var singleClone = $(this).siblings('.micro_nav_slide_list');
    var copiedData = singleClone.clone();
    // console.log(copiedData);
    copiedData.appendTo('.micro_nav_slide_list_container');
    $(this)
      .parents('.microsite_nav_list')
      .siblings('.micro_nav_slide_list_container')
      .css({ right: '0px' });
  });

  $('.micro_nav_slide_list_back').on('click', function () {
    $(this)
      .siblings('.micro_nav_slide_list')
      .delay(700)
      .queue(function () {
        $(this).remove();
      });

    $(this).parents('.micro_nav_slide_list_container').css({ right: '-800px' });
  });
}
$(document).ready(function () {
  $('ul#menu-footer-menu-1').addClass('nhsuk-list nhsuk-body-s no-margin');
  $('ul#menu-footer-menu-2').addClass('nhsuk-list nhsuk-body-s no-margin');
  $('ul#menu-footer-menu-3').addClass('nhsuk-list nhsuk-body-s no-margin');
  $('ul#menu-footer-menu-4').addClass('nhsuk-list nhsuk-body-s no-margin');
  // Home menu
  $('li.nav-primary__item--home a').addClass('nav-primary__link--home');
  var getHomeTitle = $('li.nav-primary__item--home a').html();
  $('li.nav-primary__item--home a').html(
    '<span class="visuallyhidden">' +
      getHomeTitle +
      ' </span> <span class="icon-home white"></span>'
  );

  HamburgerClick();

  list_scroll();
});

function list_scroll() {
  console.log("testing");
  $('.list_a').on('click', function () {
    $('html, body').animate({ scrollTop: $('.a_detail').offset().top }, 100);
  });
  $('.list_b').on('click', function () {
    $('html, body').animate({ scrollTop: $('.b_detail').offset().top }, 100);
  });
  $('.list_c').on('click', function () {
    $('html, body').animate({ scrollTop: $('.c_detail').offset().top }, 100);
  });
  $('.list_d').on('click', function () {
    $('html, body').animate({ scrollTop: $('.d_detail').offset().top }, 100);
  });
  $('.list_e').on('click', function () {
    $('html, body').animate({ scrollTop: $('.e_detail').offset().top }, 100);
  });
  $('.list_f').on('click', function () {
    $('html, body').animate({ scrollTop: $('.f_detail').offset().top }, 100);
  });
  $('.list_g').on('click', function () {
    $('html, body').animate({ scrollTop: $('.g_detail').offset().top }, 100);
  });
  $('.list_h').on('click', function () {
    $('html, body').animate({ scrollTop: $('.h_detail').offset().top }, 100);
  });
  $('.list_i').on('click', function () {
    $('html, body').animate({ scrollTop: $('.i_detail').offset().top }, 100);
  });
  $('.list_j').on('click', function () {
    $('html, body').animate({ scrollTop: $('.j_detail').offset().top }, 100);
  });
  $('.list_k').on('click', function () {
    $('html, body').animate({ scrollTop: $('.k_detail').offset().top }, 100);
  });
  $('.list_l').on('click', function () {
    $('html, body').animate({ scrollTop: $('.l_detail').offset().top }, 100);
  });
  $('.list_m').on('click', function () {
    $('html, body').animate({ scrollTop: $('.m_detail').offset().top }, 100);
  });
  $('.list_n').on('click', function () {
    $('html, body').animate({ scrollTop: $('.n_detail').offset().top }, 100);
  });
  $('.list_o').on('click', function () {
    $('html, body').animate({ scrollTop: $('.o_detail').offset().top }, 100);
  });
  $('.list_p').on('click', function () {
    $('html, body').animate({ scrollTop: $('.p_detail').offset().top }, 100);
  });
  $('.list_q').on('click', function () {
    $('html, body').animate({ scrollTop: $('.q_detail').offset().top }, 100);
  });
  $('.list_r').on('click', function () {
    $('html, body').animate({ scrollTop: $('.r_detail').offset().top }, 100);
  });
  $('.list_s').on('click', function () {
    $('html, body').animate({ scrollTop: $('.s_detail').offset().top }, 100);
  });
  $('.list_t').on('click', function () {
    $('html, body').animate({ scrollTop: $('.t_detail').offset().top }, 100);
  });
  $('.list_u').on('click', function () {
    $('html, body').animate({ scrollTop: $('.u_detail').offset().top }, 100);
  });
  $('.list_v').on('click', function () {
    $('html, body').animate({ scrollTop: $('.v_detail').offset().top }, 100);
  });
  $('.list_w').on('click', function () {
    $('html, body').animate({ scrollTop: $('.w_detail').offset().top }, 100);
  });
  $('.list_x').on('click', function () {
    $('html, body').animate({ scrollTop: $('.x_detail').offset().top }, 100);
  });
  $('.list_y').on('click', function () {
    $('html, body').animate({ scrollTop: $('.y_detail').offset().top }, 100);
  });
  $('.list_z').on('click', function () {
    $('html, body').animate({ scrollTop: $('.z_detail').offset().top }, 100);
  });

  $('.back_top_button').on('click', function () {
    $('html, body').animate({ scrollTop: $('body').offset().top }, 100);
  });
}


$('#breadcrumbs')
  .find('a')
  .each(function () {
    var dataId = $(this).attr('href');
    $('#yost_custom').append(
      '<li class="breadcrumb-item"><a class="nhsuk-breadcrumb__link" href="' +
        dataId +
        '">' +
        $(this).text() +
        '</a></li>'
    );
    $('#yost_custom-bottom').append(
      '<li class="breadcrumb-item"><a class="nhsuk-breadcrumb__link" href="' +
        dataId +
        '">' +
        $(this).text() +
        '</a></li>'
    );
  });

function feedbackFormTongle() {
  const elementDropList = document.getElementById('dropList');
  const attrs = elementDropList.getAttributeNames().reduce((acc, name) => {
    return { ...acc, [name]: elementDropList.getAttribute(name) };
  }, {});
  if (attrs['aria-expanded'] === 'false') {
    elementDropList.setAttribute('aria-expanded', true);
  } else {
    elementDropList.setAttribute('aria-expanded', false);
  }
  var elementFeedBack = document.getElementById('feedback');
  elementFeedBack.classList.toggle('mystyle');
}

jQuery(document).ready(function () {
  var lspan = $('#breadcrumbs span span').children().length;
  $('#breadcrumbs span span:first-child').remove();
  for (var i = 0; i < lspan; i++) {
    $('#breadcrumbs span span').children().eq(i).hide();
  }
  $('#breadcrumbs span span:last-child').remove();

  $('#breadcrumbs span span:last-child').addClass('laste').show();
  $('#breadcrumbs span span.laste a').show();

  /*
    if (lspan === 5) {
      $('#breadcrumbs span span:first-child').remove();
      $('#breadcrumbs span span').children().eq(0).hide();
      $('#breadcrumbs span span').children().eq(1).hide();
      $('#breadcrumbs span span').children().eq(2).hide();
      $('#breadcrumbs span span:eq(3)').addClass('laste');
      $('#breadcrumbs span span:last-child').remove();
    }
    if (lspan === 4) {
      $('#breadcrumbs span span:first-child').remove();
      $('#breadcrumbs span span').children().eq(0).hide();
      $('#breadcrumbs span span').children().eq(1).hide();
      $('#breadcrumbs span span:eq(2)').addClass('laste');
      $('#breadcrumbs span span:last-child').remove();
    }
    if (lspan === 3) {
      $('#breadcrumbs span span:first-child').remove();
      $('#breadcrumbs span span').children().eq(0).hide();
      $('#breadcrumbs span span:eq(2)').addClass('laste');
      $('#breadcrumbs span span:last-child').remove();
    }
   */
});

//$('#breadcrumbs').remove();

/*$(function() {
        var params = {
            // Request parameters
        };
      
        $.ajax({
            url: "https://nsdfapp1.azure-api.net/nsd/servicetypes/03",
            //url: "https://nsdfapp1.azure-api.net/nsd/services/02",
            beforeSend: function(xhrObj){
                // Request headers
                xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key","aa89c46d0a844f778eab7fdd7af86d6b");
            },
            type: "GET",
            // Request body
            data: "{body}",
        })
        .done(function(data) {
            //alert("success");
        })
        .fail(function() {
            //alert("error");
        });
    });*/
