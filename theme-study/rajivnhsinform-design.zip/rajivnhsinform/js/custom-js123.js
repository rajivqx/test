/**
 * File custom-j.js.
 *
 * Handles toggling the custom menu for small screens and enables TAB key
 * custom support for dropdown menus.
 */

function HamburgerClick() {
  $('.hamburger_icon').on('click', function () {
    $('.microsite_overlay').css('display', 'block');
    $('body').css('overflow', 'hidden');
    $('.microsite_navigation').css('display', 'block');
  });

  $('.microsite_overlay').on('click', function () {
    $(this).hide();
    $('body').css('overflow', 'auto');
    $('.microsite_navigation').css('display', 'none');
  });

  $('.close_micro').on('click', function () {
    $(this).parents('.microsite_navigation').hide();
    $(this)
      .parents('.microsite_navigation')
      .siblings('.microsite_overlay')
      .hide();
    $('body').css('overflow', 'auto');
  });

  $('.micro_nav_slide').on('click', function () {
    var singleClone = $(this).siblings('.micro_nav_slide_list');
    var copiedData = singleClone.clone();
    // console.log(copiedData);
    copiedData.appendTo('.micro_nav_slide_list_container');
    $(this)
      .parents('.microsite_nav_list')
      .siblings('.micro_nav_slide_list_container')
      .css({ right: '0px' });
  });

  $('.micro_nav_slide_list_back').on('click', function () {
    $(this)
      .siblings('.micro_nav_slide_list')
      .delay(700)
      .queue(function () {
        $(this).remove();
      });

    $(this).parents('.micro_nav_slide_list_container').css({ right: '-800px' });
  });
}
$(document).ready(function () {
  $('ul#menu-footer-menu-1').addClass('nhsuk-list nhsuk-body-s no-margin');
  $('ul#menu-footer-menu-2').addClass('nhsuk-list nhsuk-body-s no-margin');
  $('ul#menu-footer-menu-3').addClass('nhsuk-list nhsuk-body-s no-margin');
  $('ul#menu-footer-menu-4').addClass('nhsuk-list nhsuk-body-s no-margin');
  // Home menu
  $('li.nav-primary__item--home a').addClass('nav-primary__link--home');
  var getHomeTitle = $('li.nav-primary__item--home a').html();
  $('li.nav-primary__item--home a').html(
    '<span class="visuallyhidden">' +
      getHomeTitle +
      ' </span> <span class="icon-home white"></span>'
  );

  HamburgerClick();
});

$('#breadcrumbs')
  .find('a')
  .each(function () {
    var dataId = $(this).attr('href');
    $('#yost_custom').append(
      '<li class="breadcrumb-item"><a class="nhsuk-breadcrumb__link" href="' +
        dataId +
        '">' +
        $(this).text() +
        '</a></li>'
    );
    $('#yost_custom-bottom').append(
      '<li class="breadcrumb-item"><a class="nhsuk-breadcrumb__link" href="' +
        dataId +
        '">' +
        $(this).text() +
        '</a></li>'
    );
  });
//$('#breadcrumbs').remove();

/*$(function() {
        var params = {
            // Request parameters
        };
      
        $.ajax({
            url: "https://nsdfapp1.azure-api.net/nsd/servicetypes/03",
            //url: "https://nsdfapp1.azure-api.net/nsd/services/02",
            beforeSend: function(xhrObj){
                // Request headers
                xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key","aa89c46d0a844f778eab7fdd7af86d6b");
            },
            type: "GET",
            // Request body
            data: "{body}",
        })
        .done(function(data) {
            //alert("success");
        })
        .fail(function() {
            //alert("error");
        });
    });*/
