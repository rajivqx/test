 const KEY_CODES = {
        RETURN: 13
    },
    triggerEvents = ['click', 'keydown'];

const load = url => {
    return new Promise(function(resolve, reject) {
        let script = document.createElement('script');
        script.src = url;
        document.head.appendChild(script);
        script.onload = resolve;
        script.onerror = reject;
    });
}

/*
const redirect = (lat = '', long = '') => {
    let url = location.href;
    url = updateQueryStringParameter(url,
            "locpt",
            lat + "," + long);
    url = updateQueryStringParameter(url, "sortby", "_distance");
    url = updateQueryStringParameter(url, "locradius", "5");

    location.href = url;
};
const updateQueryStringParameter = (uri, key, value) => {
    let re = new RegExp("([?&])" + key + "=.*?(&|$)", "i"),
        separator = uri.indexOf('?') !== -1 ? "&" : "?";

    if (uri.match(re)) {
        return uri.replace(re, '$1' + key + "=" + value + '$2');
    }
    else {
        return uri + separator + key + "=" + encodeURIComponent(value);
    }
};
*/
const updateAndSubmit = (lat = '', long = '') => {
    if(!!lat && !!long){
        document.querySelector('.js-locpt').value = `${lat},${long}`;
    }
    document.querySelector('.js-location').submit();
};

const updateAndSubmitHeader = (lat = '', long = '', tab) => {
    if(!!lat && !!long) {
      if (!!tab) {
        document.querySelector('.js-header-tab').value = `${tab}`;
        }
        document.querySelector('.js-header-locpt').value = `${lat},${long}`;
    } else {
      if (!!tab) {
        document.querySelector('.js-header-tab').value = `${tab}`;
      }
    }
    document.querySelector('.js-header-location').submit();
};

const geolocationSuccess = pos => {
    updateAndSubmit(pos.coords.latitude, pos.coords.longitude);
}

const geoLocationError = error => {
    switch (error.code) {
        case error.PERMISSION_DENIED:
            console.warn("User denied the request for Geolocation.");
            showError('Sorry, the geolocation request was denied');
            showError();
            break;
        case error.POSITION_UNAVAILABLE:
            console.warn("Location information is unavailable.");
            showError('Sorry, geolocation information is not available');
            showError();
            break;
        case error.TIMEOUT:
            console.warn("The request to get user location timed out.");
            showError('Sorry, geolocation timed out');
            break;
        case error.UNKNOWN_ERROR:
            console.warn("An unknown error occurred.");
            showError('Sorry, there was an unknown geolocation error');
            break;
    }
};

const showError = error => {
    let messageNode = `<div class="geolocation-message js-geocode-error push-half--top">${error}</div>`;

    if(!!document.querySelector('.js-geocode-error')) return;
    
    document.querySelector('.js-geolocation__input').parentNode.insertAdjacentHTML('afterend', messageNode);
};

const getGeocodedLocationHeader = () => {
    if(document.querySelector('.js-header-geolocation__input').value === ""){
        updateAndSubmitHeader();
    }
    else{
      var tab = 'inform';
    
    if (document.querySelector('.js-header-tab').value != null) {
      tab = document.querySelector('.js-header-tab').value;
    }
      var q = document.querySelector('.js-header-geolocation__input').value;
      var postcode = q.match(/(^|\s+)(([gG][iI][rR] {0,}0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2})($|\s+))/gi)
      
      if (postcode != null) {
        tab = 'nsd';
        q = q.replace(/(^|\s+)(([gG][iI][rR] {0,}0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2})($|\s+))/i," ").replace(/^ */i, "").replace(/ *$/i, "");
        document.querySelector('.js-header-geolocation__input').value = q;
    } else {
      postcode = q;
    }
    
        let geocoder = new window.google.maps.Geocoder();
    
    geocoder.geocode({
                'address': postcode + ', UK'
            }, (res, status) => {
            if (status === window.google.maps.GeocoderStatus.OK) {
        if((54.6332381 <= res[0].geometry.location.lat() && res[0].geometry.location.lat() <= 60.8607515) && (-8.650007200000005 <= res[0].geometry.location.lng() && res[0].geometry.location.lng() <= -0.7246751000000131)) {
          updateAndSubmitHeader(res[0].geometry.location.lat(), res[0].geometry.location.lng(), tab);
        }
        else {
          updateAndSubmitHeader('', '', tab);
        }
            } else {
        updateAndSubmitHeader('', '', tab);
      }
        });
    }
};

const getGeocodedLocation = () => {
    if(document.querySelector('.js-geolocation__input').value === ""){
        updateAndSubmit();
    }
    else{
        let geocoder = new window.google.maps.Geocoder();
                        
        geocoder.geocode({ 
                'address': document.querySelector('.js-geolocation__input').value + ', UK'
            }, (res, status) => {
            if (status === window.google.maps.GeocoderStatus.OK) {
              document.querySelector('.js-geolocation__input').value = "";
                updateAndSubmit(res[0].geometry.location.lat(), res[0].geometry.location.lng());
            } else {
                if(status === window.google.maps.GeocoderStatus.ZERO_RESULTS) {
                    showError('Sorry, we could not find your location');
                }
            }
        });
    }
};

const init = (key) => {
    if(!navigator.geolocation) { 
      [].slice.call(document.querySelectorAll('.js-header-geolocation')).forEach(el => {
        el.classList.add('visuallyhideen');
      });
        [].slice.call(document.querySelectorAll('.js-geolocation')).forEach(el => {
            el.classList.add('visuallyhidden');
        });
        return;
    }


    window.$_GoogleMapsAPILoaded_$ = () => {
        delete window.$_GoogleMapsAPILoaded_$;
    };
 
    load(`//maps.googleapis.com/maps/api/js?callback=$_GoogleMapsAPILoaded_$&key=${key}`);

    //header geolocation btn listener
    let geoBtnHdr = document.querySelector('.js-header-geolocation');
    if(geoBtnHdr){
        triggerEvents.forEach(evt => {
            geoBtnHdr.addEventListener(evt, e => {
                if(!!!e.keyCode || e.keyCode === KEY_CODES.RETURN){
                    document.querySelector('.js-header-geolocation__input').value = "";
                    navigator.geolocation.getCurrentPosition(geolocationSuccess, geoLocationError);
                }
            });
        });
    }

    //geolocation btn listener
    let geoBtn = document.querySelector('.js-geolocation');
    if(geoBtn){
        triggerEvents.forEach(evt => {
            geoBtn.addEventListener(evt, e => {
                if(!!!e.keyCode || e.keyCode === KEY_CODES.RETURN){
                    document.querySelector('.js-geolocation__input').value = "";
                    navigator.geolocation.getCurrentPosition(geolocationSuccess, geoLocationError);
                }
            });
        });
    }

    //header form submission listener
    if(document.querySelector('.js-header-location')){
        document.querySelector('.js-header-location').addEventListener('submit', e => {
            e.preventDefault();
            getGeocodedLocationHeader();
        });
    }

    //form submission listener
    if(document.querySelector('.js-location')){
        document.querySelector('.js-location').addEventListener('submit', e => {
            e.preventDefault();
            getGeocodedLocation();
        });
    }

};


init('AIzaSyBcxJ4JU_Ie4ePFv3yMAcBWSeRgS2xgpg0');
