<?php
/**
 * The template for displaying archive-ready-steady-baby pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nhsinform
 */

get_header();?>



    <div class="microsite_overlay"></div>
    <div class="microsite_navigation">
        <h3>Ready Steady Baby <button class="close_micro"><i class="fa-solid fa-xmark"></i></button></h3>
          

        <nav class="microsite_nav_list">
            <?php  
                wp_nav_menu( array(
                'theme_location' => 'ready_steady_baby_menu',
                // 'menu_class' => 'microsite_nav_list',
                'container'=>false,
                'debth'=>2
                    ) );
           ?>
            <!-- <ul>
                <li>
                    <a href="#">Pregnancy</a>
                    <span class="micro_bg_01 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                        <li><a href="#">Health problems in pregnancy</a></li>
                        <li><a href="#">Looking after yourself and your baby</a></li>
                        <li><a href="#">Preparing for parenthood</a></li>
                        <li><a href="#">Relationships and wellbeing in pregnancy</a></li>
                        <li><a href="#">Your antenatal care</a></li>
                        <li><a href="#">Your baby's development</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Labour and birth</a>
                    <span class="micro_bg_02 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                        <li><a href="#">After the birth</a></li>
                        <li><a href="#">Assisted birth</a></li>
                        <li><a href="#">Getting ready for the birth</a></li>
                        <li><a href="#">Relationships and wellbeing in pregnancy</a></li>
                        <li><a href="#">Giving birth</a></li>
                        <li><a href="#">Labour</a></li>
                        <li><a href="#">Meeting your new baby</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Early parenthood</a>
                    <span class="micro_bg_03 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                    <ul class="micro_nav_slide_list">
                        <li><a href="#">Caring for your new baby</a></li>
                        <li><a href="#">Getting to know your baby</a></li>
                        <li><a href="#">Going home</a></li>
                        <li><a href="#">If your baby's ill</a></li>
                        <li><a href="#">Your growing family</a></li>
                        <li><a href="#">Your wellbeing after the birth</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Other languages and formats</a>
                    <span class="micro_bg_01 micro_nav_slide"><i class="fa-solid fa-chevron-right"></i></span>
                </li>
            </ul> -->
        </nav>
        <div class="micro_nav_slide_list_container">
            <span class="micro_nav_slide_list_back">Back</span>
        </div>
    </div>

    <!-- MicroSite Header HTML Start -->
    <div class="microsite_header">
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <a href="#" class="microsite_title">Ready Steady Baby!</a>
                </div>
                <div class="col-3">
                    <div class="hamburger_icon">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- MicroSite Header HTML End -->

    <!-- Mobile Search HTML Start -->
    <form class="custom_search mobile_search_detail">
        <input class="form-control" type="text" placeholder="Search NHS inform/Services" aria-label="Search">
        <button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <!-- Mobile Search HTML End -->

    <!-- Breadcrumb HTML Start -->
    <nav class="breadcrumb_section microsite_breadcrumb" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><?php get_sidebar('breadcrumb');?></li>
            </ol>
        </div>
    </nav>
    <!-- Breadcrumb HTML End -->

    <!-- Pannel Wrapper Section HTML Start -->
    <!-- <section class="pannel_wrapper microsite_wrapper">
        <div class="container">
            <div class="pannel_wrapper_container microsite_wrapper_container">
                <div class="row">
                    <div class="col-md-10">
                        <h1>Health problems in pregnancy</h1>
                        <p>You might develop some minor ailments during your pregnancy. These are common and are usually harmless to you and your baby. Some people develop more serious conditions which need to be carefully monitored. Your antenatal team will look after you and make sure you and your baby always get the care you need.</p>
                    </div>
                    <div class="col-md-2 d-none d-md-block d-lg-block">
                       <img src="<?php echo get_template_directory_uri();?>/assets/images/pregnancy.png" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="a_to_z_page.html" class="pannel_module">
                            <h3>Common problems in pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>Minor ailments that develop during pregnancy</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Ectopic pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>When a fertilised egg develops outside the womb</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Health conditions before pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>Managing pre-existing health conditions during pregnancy</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Health conditions that develop during pregnancy <i class="fa-solid fa-angle-right"></i></h3>
                            <p>Managing health conditions that develop during pregnancy</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Miscarriage <i class="fa-solid fa-angle-right"></i></h3>
                            <p>When you lose your baby before 24 weeks</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>Pre-eclampsia <i class="fa-solid fa-angle-right"></i></h3>
                            <p>A complication of pregnancy that primarily affects your blood pressure</p>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a href="#" class="pannel_module">
                            <h3>When pregnancy goes wrong <i class="fa-solid fa-angle-right"></i></h3>
                            <p>What can cause the loss of a baby and where to get support if this happens to you</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Pannel Wrapper Section HTML Start -->

    <?php 
        $term       = get_queried_object(); 
        // print_r($term);
        // die();
        // $getSlug    = $term->slug;
        
    
        $parent_id    = $term->parent;
        if($parent_id == 359):
            get_template_part( 'template-parts/readysteadybaby', 'pregnancy' );
        elseif($parent_id == 360) :
        get_template_part( 'template-parts/readysteadybaby', 'labourbirth' );
        else :
        get_template_part( 'template-parts/readysteadybaby', 'earlyparenthood' );
        endif;

        ?>

    <!-- Footer HTML Start -->
    <?php
    get_footer();
    ?>