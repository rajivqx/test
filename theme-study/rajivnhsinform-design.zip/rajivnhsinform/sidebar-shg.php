<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nhsinform
 */

?>
<?php if(have_rows('links1') || have_rows('links')){?>
  <div class="panel-content panel-content--half push--bottom">

    <?php if(have_rows('links1')):?>
        <div class="push--bottom">
        <h3 class="gamma bold primary-color push-half--bottom">
            Also on NHS inform
        </h3>
        <div class="overline bg-primary-color push-half--ends"></div>
            <ul class="nhsuk-list list-style-none">
                <?php while(have_rows('links1')): the_row();?>
                  <li>
                    <?php
                    $related_link1 = get_sub_field('related_link1');
                    if($related_link1){ ?>
                       <a href="<?php echo $related_link1->permalink;?>" target="_self">
                        <?php echo $related_link1->post_title;?>
                      </a>
                    <?php }else{ ?>
                        <a href="<?php echo site_url(get_sub_field('related_link2'));?>" target="_self"><?php the_sub_field('related_link_name');?>
                      </a>
                   <?php } ?>
                  </li>
                <?php endwhile;?>   
            </ul>
        </div>
    <?php endif;?>
    <?php if(have_rows('links')):?>
        <div class="push--bottom">
            <h3 class="gamma bold primary-color push-half--bottom">
                Other health sites
            </h3>
            <div class="overline bg-primary-color push-half--ends"></div>
                <ul class="nhsuk-list list-style-none">
                  <?php while(have_rows('links')): the_row();?>
                      <li>
                           <a href="<?php echo get_sub_field('related_link');?>" target="_self"><?php the_sub_field('related_link_name');?></a>
                      </li>
                  <?php endwhile;?>
                </ul>
        </div>
     <?php endif;?>

</div>
<?php } ?>

    <div class="panel-content panel-content--half push--bottom text-center pc-alter">
        <button class="btn--clean border-none" onclick="Velaro.Engagement.LoadPopoutChat()" onkeydown="Velaro.Engagement.LoadPopoutChat()">
            <img src="https://api-visitor-us-east.velaro.com/20046/4564/button.jpg" alt="NHS Inform Live Support">
        </button>
    </div>



