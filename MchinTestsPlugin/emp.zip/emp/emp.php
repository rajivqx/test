<?php
/*
 * Plugin Name: Custom Employee
 * Description: Custom Employee plugin Description.
 * Version: 1.0
 * Author:Rajiv
 * Plugin URI:
 * Author URI:
 */

register_activation_hook(__FILE__, 'table_creator');
function table_creator()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'ems';
    $sql = "DROP TABLE IF EXISTS $table_name;
            CREATE TABLE $table_name(
            id mediumint(11) NOT NULL AUTO_INCREMENT,
            emp_name varchar (250) NOT NULL,
            gender varchar (250) NOT NULL,
            designation varchar (250) NOT NULL,
            profile_image varchar (250) NOT NULL,
            salary int (20) NOT NULL,
            PRIMARY KEY id(id)
            )$charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}


add_action('admin_menu', 'da_display_esm_menu');
function da_display_esm_menu()
{

    add_menu_page('Employee', 'Employee', 'manage_options', 'emp-list', 'da_ems_list_callback');
    add_submenu_page('emp-list', 'Employee List', 'Employee List', 'manage_options', 'emp-list', 'da_ems_list_callback');
    add_submenu_page('emp-list', 'Add Employee', 'Add Employee', 'manage_options', 'add-emp', 'da_ems_add_callback');
    add_submenu_page(null, 'Update Employee', 'Update Employee', 'manage_options', 'update-emp', 'da_emp_update_call');
    add_submenu_page(null, 'Delete Employee', 'Delete Employee', 'manage_options', 'delete-emp', 'da_emp_delete_call');
  

}

function da_ems_add_callback()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'ems';
    $msg = '';
    if (isset($_REQUEST['submit'])) {

        $wpdb->insert("$table_name", [
            'emp_name' => $_REQUEST['emp_name'],
            'gender' => $_REQUEST['gender'],
            'designation' => $_REQUEST['designation'],
            'profile_image' => $_REQUEST['profile_image'],
            'salary' => $_REQUEST['salary']
        ]);


        if ($wpdb->insert_id > 0) {
            $msg = "Saved Successfully";
        } else {
            $msg = "Failed to save data";
        }
    }



    ?>
    <h4 id="msg"><?php echo $msg; ?></h4>

    <form method="post">

        <p>
            <label>Name</label>
            <input type="text" name="emp_name" placeholder="Enter Name" required>

        </p>
        <p>
            <label>Gender</label>
            <input type="text" name="gender" placeholder="Enter Gender" required>
        </p>
        <p>
            <label>Designation</label>
            <input type="text" name="designation" placeholder="Enter Designation" required>
        </p>
        <p>
            <label>Upload Profile_image</label>
            <input type="file" name="profile_image">
        </p>
        <p>
            <label>Salary</label>
            <input type="text" name="salary" placeholder="Enter Salary" required>
        </p>
        

        <p>
            <button type="submit" name="submit">Submit</button>
        </p>
    </form>
<?php }

function da_emp_shortcode_call()
{ ?>

    <p>
        <label>Shortcode</label>
        <input type="text" value="[employee_list]">
    </p>
<?php }



//[employee_list]
add_shortcode('employee_list', 'da_ems_list_callback');
function da_ems_list_callback()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'ems';
    $employee_list = $wpdb->get_results($wpdb->prepare("select * FROM $table_name", ""), ARRAY_A);
    if (count($employee_list) > 0): ?>
        <div style="margin-top: 40px;">
            <table border="1" cellpadding="10">
                <tr>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Designation</th>
                    <th>Profile Image</th>
                    <th>Salary</th>
                    
                </tr>
                <?php
                foreach ($employee_list as $index => $employee): ?>
                    <tr>
                        
                        <td><?php echo $employee['emp_name']; ?></td>
                        <td><?php echo $employee['gender']; ?></td>
                        <td><?php echo $employee['designation']; ?></td>
                        <td><?php echo $employee['profile Image']; ?></td>
                        <td><?php echo $employee['salary']; ?></td>
                        
                    </tr>
                <?php endforeach; ?>
            </table>

        </div>
    <?php else:echo "<h2>Employee Record Not Found</h2>";endif;
}

