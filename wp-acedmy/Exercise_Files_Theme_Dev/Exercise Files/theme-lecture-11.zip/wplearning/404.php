<?php
/*
* This template is used display not found content
*/
get_header();
?>

        <h1>Hello folks! I am laerning theme development</h1>

<?php 
get_footer();
?>
