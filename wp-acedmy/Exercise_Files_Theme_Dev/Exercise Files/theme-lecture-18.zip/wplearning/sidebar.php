<div class="col-4 col-12-medium">

<?php dynamic_sidebar( 'main-sidebar' ) ?>

</div>