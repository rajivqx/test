<?php
/*
* This template is used display sidebar
*/
?>
<div class="main-sidebar-inner">
    <?php 
        dynamic_sidebar('main-sidebar');
    ?>
</div>

