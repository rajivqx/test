<?php
/*
* Plugin Name: WPacademy Like/Dislike
* Plugin URI: https://wpacademy.pk
* Author: WPacademy.PK
* Author URI: https://wpacademy.pk
* Description: Simple Post Like & Dislike System.
*/

function wpacademy_publish_send_mail(){
    global $post;
    $author = $post->post_author; /* Post author ID. */
    $name = get_the_author_meta( 'display_name', $author );
    $email = get_the_author_meta( 'user_email', $author );
    $title = $post->post_title;
    $permalink = get_permalink( $ID );
    $edit = get_edit_post_link( $ID, '' );
    $to[] = sprintf( '%s <%s>', $name, $email );
    $subject = sprintf( 'Published: %s', $title );
    $message = sprintf ('Congratulations, %s! Your article “%s” has been published.' . "\n\n", $name, $title );
    $message .= sprintf( 'View: %s', $permalink );
    $headers[] = '';
    wp_mail( $to, $subject, $message, $headers );
}
add_action( 'publish_post', 'wpacademy_publish_send_mail' );

function wpacademy_like_filter_example( $words ) {
    return 10;
}
add_filter('excerpt_length', 'wpacademy_like_filter_example');

function wpacademy_like_filter_example_2( $more ) {
    $more = '<a href="'.get_the_permalink().'">More</a>';
    return $more;
}
add_filter('excerpt_more', 'wpacademy_like_filter_example_2');

