<?php 
    function analytics_rewrite_add_var( $vars ) {
        $vars[] = 'scotlands-service-directory';
        return $vars;
    }
    add_filter( 'query_vars', 'analytics_rewrite_add_var' );

    function add_analytic_rewrite_rule() {
        add_rewrite_tag( '%scotlands-service-directory%', '([^&]+)' );
        add_rewrite_rule(
            '^scotlands-service-directory/([^/]*)/?',
            'index.php?scotlands-service-directory=$matches[1]',
            'top'
        );
    }
    add_action('init', 'add_analytic_rewrite_rule');

    function analytics_rewrite_catch() {
        global $wp_query;
        if ( array_key_exists( 'scotlands-service-directory', $wp_query->query_vars ) ) {


            switch ($wp_query->query_vars["scotlands-service-directory"]) {
                case "aes-and-minor-injuries-units":
                   $ser = 1;
                   $name = "aes-and-minor-injuries-units";
                   break;
                case "dental-services":
                    $ser = 1;
                    $name = "dental-services";
                    break;
                case "gp-practices":
                    $ser = 1;
                    $name = "gp-practices";
                    break;
                case "health-and-wellbeing-services":
                    $ser = 1;
                    $name = "health-and-wellbeing-services";
                    break;
                case "hospitals":
                    $ser = 1;
                    $name = "hospitals";
                    break;
                case "opticians":
                    $ser = 1;
                    $name = "opticians";
                    break;
                case "pharmacies":
                    $ser = 1;
                    $name = "pharmacies";
                    break;
                case "sexual-health-clinics":
                    $ser = 1;
                    $name = "sexual-health-clinics";
                    break;
              default:
                $ser = 0;
            }
            if ($ser == 1) {
                global $wp;
                $url= home_url( $wp->request );
                $url = explode("/",$url);
                
                $last_part = array_slice(array_filter($url), -2)[0];
                
                if ( $last_part == $name) {
                    include ( get_stylesheet_directory() . '/ssd/service-details.php');
                    exit;
                }else{
                    include ( get_stylesheet_directory() . '/ssd/service.php');
                    exit;
                }
            }else{
                status_header( 404 );
                nocache_headers();
                include( get_404_template() );
                exit;
            }
        }
    }
    add_action( 'template_redirect', 'analytics_rewrite_catch' );

    function ServiceAllService($data){
        $key = $data['key'];
        global $wp;

        $headers = array(
           "Ocp-Apim-Subscription-Key: $key",
           "Authorization: $key",
        );

        $url = "https://nsdfapp1.azure-api.net/nsd/datasets";
        
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($curl);
        curl_close($curl);
        $collectionJsone = json_decode($resp);
        $temp = $collectionJsone[3];
        $collectionJsone[3] = $collectionJsone[4];
        $collectionJsone[4] = $temp;

        ?>
   
        <!-- <div class="wrapper">
            <div class="col small-12 panel-content ssd-listing">
                <div class="row">
                    <div class="js-equal-height blockgrid-list"> -->
       <section class="pannel_wrapper shgWrapHome">
        <div class="container">
            <div class="pannel_wrapper_container">
                <div class="row">
                    <?php //$collectionJsone = array($collectionJsone[0],$collectionJsone[1],$collectionJsone[2],$collectionJsone[4],$collectionJsone[3],$collectionJsone[5],$collectionJsone[6],$collectionJsone[7],$collectionJsone[8],$collectionJsone[9]);?>
                        <?php foreach ($collectionJsone as $value): ?>
                            <?php if ($value->Name == 'accident-and-emergency'): ?>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/aes-and-minor-injuries-units" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                   <h3>
                                        A&Es and Minor Injuries Units <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                            </div>
                            <?php elseif ($value->Name == 'dentist'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/dental-services" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                    <h3>
                                        <?= $value->FriendlyName; ?> <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                                </div>
                            <?php elseif ($value->Name == 'gp-practice'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/gp-practices" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                    <h3>
                                        GP practices <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                                </div>
                            <?php elseif ($value->Name == 'hwb'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/health-and-wellbeing-services" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                   <h3>
                                        Health and wellbeing services <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                            </div>
                            <?php elseif ($value->Name == 'hospital'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/hospitals" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                   <h3>
                                        Hospitals <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                               </div>
                            <?php elseif ($value->Name == 'optician'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/opticians" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                   <h3>
                                        <?= $value->FriendlyName; ?> <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                                </div>
                            <?php elseif ($value->Name == 'pharmacy'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/pharmacies" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                   <h3>
                                      <?= $value->FriendlyName; ?> <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                                </div> 
                            <?php elseif ($value->Name == 'sexual-health-clinic'):?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                <a href="<?= home_url( $wp->request ) ?>/sexual-health-clinics" class="pannel_module panel-min-130 panel-min-130" style="height: 100px;">
                                   <h3>
                                    <?= $value->FriendlyName; ?> <i class="fa-solid fa-angle-right"></i>
                                    </h3>
                                </a>
                                </div> 
                            <?php endif ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php
    }
    add_shortcode("allservices","ServiceAllService");


$page_title = 'Info For Me';
$page_template = '/ssd/info-for-me.php';

$page_exists = get_page_by_title($page_title);

if (empty($page_exists)) {
    $post_data = array(
        'post_title'   => $page_title,
        'post_content' => 'Info For Me.',
        'post_status'  => 'publish',
        'post_type'    => 'page'
    );
    $page_id = wp_insert_post($post_data);
    update_post_meta($page_id, '_wp_page_template', $page_template);
}


function custom_footer() {
   ?>

<script type="text/javascript">
    jQuery(document).ready(function() {
        let storedDataString = $.cookie('data');
        try {

            let jsonStr = JSON.parse(storedDataString);
            if (jsonStr.length == 0) {
                let dataItems = [];
            }else{

                jQuery('.user_info .nav-link span').text(jsonStr.length);
            } 
        } catch (e) {
          var dataItems = [];
        }
    });
</script>
   <?php
}
add_action( 'wp_footer', 'custom_footer' );

// Naveen code
add_filter('wpseo_title','nhs_page_title1',10,1);

function nhs_page_title1($title){
    global $wp;
    $current_url = home_url(add_query_arg(array(), $wp->request));
    $curl = explode('/scotlands-service-directory/',$current_url);
if(count($curl)>1){
    $key = '065671d43cfa4e38b9788f2aba0c356a';
    $args = array(
        'headers' => array(
            'Ocp-Apim-Subscription-Key' => $key,
            'Authorization' => $key
        ),
    ); 
$url= home_url($wp->request);
$url = explode("/",$url);
$last_part = end($url);
$durl = explode("/",$curl[1]);
if(count($durl)=='2'){
    $dataset = array_slice(array_filter($url), -2)[0];
} else {
    $dataset = array_slice(array_filter($url), -1)[0];
}
switch ($dataset) {
    case "aes-and-minor-injuries-units":
       $title = "A&ES and Minor Injuries Units";
       $url = "accident-and-emergency";
       $ptitle = 'Accident And Emergency';
       break;
    case "dental-services":
        $title = "Dental services";
        $url = "dentist";
        $ptitle = 'Dental services';
        break;
    case "gp-practices":
        $title = "GP practices";
        $url = "gp-practice";
        $ptitle = 'GP practice';
        break;
    case "health-and-wellbeing-services":
        $title = "Health and Wellbeing services";
        $url = "hwb";
        $ptitle = 'Health and Well-being';
        break;
    case "hospitals":
        $title = "Hospitals";
        $url = "hospital";
        $ptitle = 'Hospitals';
        break;
    case "opticians":
        $title = "Opticians";
        $url = "optician";
        $ptitle = 'Opticians';
        break;
    case "pharmacies":
        $title = "Pharmacies";
        $url = "pharmacy";
        $ptitle = 'Pharmacies';
        break;
    case "sexual-health-clinics":
        $title = "Sexual health clinics";
        $url = "sexual-health-clinic";
        $ptitle = 'Sexual Health Clinics';
        break;
  default:
    $ser = 0;
    $url = "accident-and-emergency";
    }
    //ssd detail page
    if(count($durl)=='2'){
    $response = wp_remote_get('https://nsdfapp1.azure-api.net/nsd/'.$url.'/'.$last_part, $args);
    if (!is_wp_error($response)){
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);
        return $data->Name.' - '.$ptitle;  
    }
    } else {
        return $title.' | NHS Inform';  
    }
        } else {
            return $title;  

        }
}

function add_sidebar_info() {
    if ( is_single() || is_page() ): ?>
        <?php 
            include(dirname(__FILE__) . "/ssd/sidebar_infome.php");
            global $wp;

            $base = home_url(); 
            $current = home_url( $wp->request );
            $main = str_replace($base, '', $current);

            $id = strval(get_the_ID());
    
            $current_collection = json_encode(array('dataset'=>'post-'.$main,'Id'=>$id,'name'=>get_the_title()));

           // echo $current_collection;
            side_info_me($current_collection,get_the_ID());
        ?>
    <?php 
    endif;
}


function add_search_from($url,$filter) {
    ?>
    <form class="search-results relative js-location" id="search-form" action="<?= $url ?>"  method="GET">
        <input id="sortby" name="sortby" type="hidden" value="_distance">
        <input id="sortdir" name="sortdir" type="hidden" value="Asc">
        <input type="hidden" id="locpt" name="locpt" value="" class="js-locpt">
          <input name="q" type="text" id="location-input" class="search-results__input js-geolocation__input">
           <button type="submit" class="search-results__submit btn--green btn"><i class="fa fa-search"></i>
           <!-- <i class="fa-solid fa-magnifying-glass"></i> -->
        </button>
    </form>

    <?php 

    if ($filter != NULL && !empty($filter)) {
        $urls = $url.'?'.$filter.'&';
    }else{
        $urls = $url.'?';
    }

    ?>
    <script type="text/javascript">
 

      // const API_KEY = 'AIzaSyBcxJ4JU_Ie4ePFv3yMAcBWSeRgS2xgpg0';
      // const searchForm = document.getElementById('search-form');
      // searchForm.addEventListener('submit', event => {
      //   event.preventDefault();
      //   const locationInput = document.getElementById('location-input').value;
      //   const geocoder = new google.maps.Geocoder();
      //   geocoder.geocode({ address: locationInput }, (results, status) => {
      //     if (status === 'OK') {
      //       const location = results[0].geometry.location;
      //       const newUrl = `<?= $urls ?>sortby=_distance&sortdir=Asc&locpt=${location.lat()},${location.lng()}&q=`;
      //       window.location.href = newUrl;
      //     } else {
      //       const newUrl = `<?= $urls ?>sortby=_distance&sortdir=Asc&locpt=55.378051,-3.435973&q=`;
      //       window.location.href = newUrl;
      //     }
      //   });
      // });

      // function initMap() {
      // }
      // const script = document.createElement('script');
      // script.src = `https://maps.googleapis.com/maps/api/js?key=${API_KEY}&callback=initMap`;
      // document.body.appendChild(script);
    </script>
<?php
}


function my_enqueue_geolocation_scripts() {
  wp_enqueue_script( 'Geolocation', get_template_directory_uri() . '/js/geolocation.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'my_enqueue_geolocation_scripts' );
