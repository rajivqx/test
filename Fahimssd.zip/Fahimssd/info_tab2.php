<style type="text/css">
    .nhsuk-section-break--l, hr {
        margin-bottom: 40px;
    }
    .nhsuk-section-break--l, hr {
        margin-top: 40px;
    }
    .large-10 {
        width: 79.33333%;
        width: -webkit-calc(83.33333% - 36px);
        width: calc(83.33333% - 36px);
    }
</style>
<div class="print_details_info">
    <a href="" class="ifmBtn push-right back_btn" title="Click here to go back.">
        <i class="fa fa-angle-left" aria-hidden="true"></i>Back
    </a>
    <button id="ifmPrintPage" class="ifmBtn push-right" onclick="initPreview()">Print <i class="fa fa-print" aria-hidden="true"></i></button>

    <button type="submit" id="download-pdf" class="ifmBtn push-right pdf_download"   title="Click here to save this pages information.">Save</button>
    


    <div id="ifmPreview">
      <div id="ifmPreviewContainer">
        <?php 

        if (isset($_COOKIE['data'])):

            $key = '065671d43cfa4e38b9788f2aba0c356a';

            $args = array(
                'headers' => array(
                    'Ocp-Apim-Subscription-Key' => $key,
                    'Authorization' => $key
                ),
            ); 

            $service_user_data = $_COOKIE['data'];
            $service_user_data = preg_replace('/\\\"/',"\"", $service_user_data);
            $json_array = json_decode($service_user_data);
            foreach ($json_array as $json_object): ?>
                <?php  if (strpos($json_object->dataset, 'post-') !== false):  ?>
                <?php 
                    $post = get_post( $json_object->Id );
                    if ( $post ): ?>
                        <hr>
                        <div class="ifmPreviewItem" data-id="11179" data-type="dtNsdService" style="page-break-after: always">
                          <h1 class="giga bold primary-color push--bottom"> <?= $json_object->name ?> </h1>

                          <div class="editor">
                              
                            <?= $post->post_content; ?>

                          </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                <?php 
                    $response = wp_remote_get('https://nsdfapp1.azure-api.net/nsd/'.$json_object->dataset.'/'.$json_object->Id, $args);

                    if (!is_wp_error($response)):
                        $body = wp_remote_retrieve_body($response);
                        $data = json_decode($body);
                        if ($data):
                    ?>
                        <hr>
                        <div class="ifmPreviewItem" data-id="11179" data-type="dtNsdService" style="page-break-after: always">
                          <h1 class="giga bold primary-color push--bottom"> <?= $json_object->name ?> </h1>
                          <div class="editor beta push--bottom">
                            <h3 class="delta dark-grey-2">Services Offered</h3>
                            <ul class="nhsuk-list nhsuk-list--bullet">
                                <?php if (isset($data->Service) && !empty($data->Service)): ?>
                                    <?php foreach (@$data->Service as $service): ?>
                                        <li><?= $service->ServiceSubType->Text ?></li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                          </div>
                          <div class="row push--ends">
                            <div class="col-sm-12">
                              <h3> Opening times </h3>
                            </div>
                            <div class="cf">
                            <div class="col-12 medium-6 delta">
                                <h3 class="delta dark-grey-2 push-half--bottom">Normal opening times</h3>
                                <div class="panel-times">
                                    <dl class="nhsuk-body-m">
                                        <?php if (isset($data->Schedule->DailySchedule) && !empty($data->Schedule->DailySchedule)): ?>
                                            <?php foreach (@$data->Schedule->DailySchedule as $dailySchedule): ?>
                                                <dt>
                                                    <?= @$dailySchedule->DayOfWeek; ?>
                                                </dt>
                                                <dd>
                                                    <?php if ($dailySchedule->Open == $dailySchedule->Close): ?>
                                                        Closed
                                                    <?php else: ?>

                                                        <?= @date('h:i', strtotime($dailySchedule->Open)); ?> - <?= @date('h:i', strtotime($dailySchedule->Close)) ?>
                                                    <?php endif; ?>
                                                </dd>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </dl>
                                </div>
                            </div>
                        </div>
                            <?php if (isset($data->Schedule->ScheduleInformation) && !empty(@$data->Schedule->ScheduleInformation)): ?>
                                <div class="col-12 push--ends">
                                    <span class="gamma dark-grey-2">
                                        <p>
                                            <?= @$data->Schedule->ScheduleInformation;  ?>
                                        </p>
                                    </span>
                                </div>
                            <?php endif; ?>


                            <div class="col-12 push--ends contact_details">
                                <h3>
                                    Contact details
                                </h3>
                                <div class="row">
                                    <div class="col-sm-12 col-md-6 left_contact">
                                        <dl>
                                            <dt class="nhsuk-body-m bold no-margin">
                                               <?=  @$data->Contact->Phone->Primary->Description ?>
                                            </dt>
                                            <dd class="nhsuk-body-m">
                                               <?=  @$data->Contact->Phone->Primary->Number ?>
                                            </dd>
                                        </dl>
                                        <dl>
                                            <?php if (isset($data->Contact->EmailAddress) && !empty(@$data->Contact->EmailAddress)):?>
                                                <dt class="nhsuk-body-m bold no-margin">
                                                    Email
                                                </dt>
                                                <dd class="nhsuk-body-m">
                                                    

                                                        <?php foreach (@$data->Contact->EmailAddress as $emailAddress): ?>
                                                            <a class="wordbreak" href="mailto:<?= @$emailAddress; ?>">
                                                             <?= @$emailAddress; ?>
                                                            </a>
                                                        <?php endforeach; ?>
                                                </dd>
                                            <?php endif; ?>
                                        </dl>

                                        <dl>
                                        <?php if (isset($data->Contact->ExternalUrl->Uri) && !empty($data->Contact->ExternalUrl->Uri)): ?>
                                            <dt class="nhsuk-body-m bold no-margin">Website</dt>
                                                <dd class="nhsuk-body-m">
                                                    <a href="<?=  @$data->Contact->ExternalUrl->Uri; ?>" class="external" target="_blank">
                                                        <?=  @$data->Contact->ExternalUrl->Uri; ?>
                                                    </a>
                                                </dd>
                                            </dl>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-6 col-md-6 push--bottom right_contact">
                                        <h3 class="delta dark-grey-2">Address</h3>
                                        <address class="beta dark-grey-3 push-half--bottom">
                                            <?php  if (isset($data->Contact->Address1) && !empty($data->Contact->Address1)):?>
                                                <?= $data->Contact->Address1 ?><br>
                                            <?php endif; ?>
                                            <?php  if (isset($data->Contact->Address2) && !empty($data->Contact->Address2)):?>
                                                <?= $data->Contact->Address2 ?><br>
                                            <?php endif; ?>
                                            <?php  if (isset($data->Contact->Address3) && !empty($data->Contact->Address3)):?>
                                                <?= $data->Contact->Address3 ?><br>
                                            <?php endif; ?>
                                            <?php  if (isset($data->Contact->Town) && !empty($data->Contact->Town)):?>
                                                <?= $data->Contact->Town ?><br>
                                            <?php endif; ?>
                                            <?php  if (isset($data->Contact->County) && !empty($data->Contact->County)):?>
                                                <?= $data->Contact->County ?><br>
                                            <?php endif; ?>
                                            <?php  if (isset($data->Contact->Postcode) && !empty($data->Contact->Postcode)):?>
                                                <?= $data->Contact->Postcode ?>
                                            <?php endif; ?>

                                        </address>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-12 push--ends" id="last-updated-date">Last Updated: <?php $lp= explode('T',@$data->UpdatedDate); echo $lp[0]; ?></div>

                          </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; ?>
        <?php endif; ?>


        <div class="push--top print-only pdf_fotter" style="display:none;">
                <img src="<?php echo  get_template_directory_uri(); ?>/assets/images/macmillan.jpg" alt="">
                <br>
                <br>
                <div class="push--top push--bottom alpha">Info For Me was developed in partnership with Macmillan Cancer Support.</div>
                <div class="push--top push--bottom alpha">Created: 27/03/2023</div>
                <div class="push--top push--bottom alpha">Ref: MjAyMzAzMjd8LDMyOTAgMWdsYzExMTYvZGVudGFsLXNlcnZpY2VzLDM4MyAxbmF5MTExNi9ncC1wcmFjdGljZXMsMTM3NTUgMWhpbDExMTYvYWVzLWFuZC1taW5vci1pbmp1cmllcy11bml0cw%3D%3D</div>
                <div class="push--top push--bottom alpha">Disclaimer: This information is quality assured and made available by NHS inform and can be found at <a href="https://www.nhsinform.scot" target="_blank" title="Click here to visit NHS Inform (This will open in a new window).">www.nhsinform.scot</a></div>
            </div>


      </div>
    </div>

    <script type="text/javascript">
        jQuery(document).ready(function() {
            jQuery('.back_btn').on('click', function() {
                $.cookie('service_tab', 1,{ expires: 30, path: '/' });
            });
        })
    </script>
</div>


 

 <script>
    function initPreview() {
      var ifmPrintPage = document.getElementById('ifmPrintPage');
      ifmPrintPage.addEventListener('click', function() {

        var style = document.createElement('style');
        style.type = 'text/css';
        style.textContent = `
            @media print { 

            @page {
                  size: auto;
                  margin: 18px; 
                }
                @page :header,@page :footer {
                  display: none;
                }
                a.ifmBtn.push-right.back_btn,
                button#ifmPrintPage,
                button.ifmBtn.push-right.pdf_download,
                .breadcrumb_section,
                iframe,
                header,
                footer { 
                    display: none; 
                }
                .pdf_header{
                    display: flex !Important;
                }
                .pdf_fotter{
                    display: block !Important;
                }
                .panel-content{
                    border: 0;
                }
                .primary-color{
                    font-size: 40px;
                    padding-top: 14px; 
                    margin-bottom: 8px!important;
                }
                .nhsuk-body-m, address, p{
                    margin-bottom: 12px!important;
                }
                .ssd-infofor-me .editor p{
                    font-size: 19px;
                }
                .nhsuk-section-break--l, hr {
                    margin: 22px 0 !Important;
                }
                .row.push--ends h3,
                .editor h3, .nhsuk-details__text h3, .panel-body h3{
                    color: #000000;
                    font-size: 23px;
                }
                 h3.delta.dark-grey-2.push-half--bottom{
                    color: #000 !important;
                 }
                .shg-containeList p, ul>li {
                    font-weight: 600;
                    font-size: 16px;
                }
                .ssd-infofor-me ul{
                    margin-bottom: 12px !important;
                }
                .panel-times dd, .panel-times dt{
                    float: unset !important;
                }
                .panel-times dd, .panel-times dt{
                    font-weight: 500 !important;
                    font-size: 18px !important;
                    padding: 0 !important;
                    line-height: 22px;
                }
                body .left_contact dl dt, .left_contact dl dd{
                    color: #000 !important;
                    line-height: 12px !important;
                    font-size: 15px !important;
                }
                 body .left_contact dl dt a, .left_contact dl dd a{
                    color: #4d4d4d  !important;
                    text-decoration: underline;
                    line-height: 12px !important;
                }
                .left_contact dl{
                   margin: 0px !important; 
                }
                .right_contact h3.delta.dark-grey-2 {
                    margin-bottom: 8px !important;
                }

                .right_contact address {
                    color: #000 !important;
                    font-size: 20px !important;
                }
                .contact_details,
                .push--bottom{
                    margin: 0 !important;
                }
                div#last-updated-date{
                    color: #000 !important;
                    font-size: 14px !important;
                    font-weight: 600 !important;
                    margin: 0 !important;
                    line-height: 12px !important;
                }
            }
        `;
        document.head.appendChild(style);
        window.print();
        document.head.removeChild(style);
      });
    }
    if (ifmPreview !== null) {
        var newContent = ifmPreview.innerHTML.replace(/–/g, "-")
          , morenew = newContent.replace(/’/g, "'");
        ifmPreview.innerHTML = morenew;
        initPreview();
    }

  
 </script>


 <style type="text/css">
    .pdf_header{
        justify-content: space-between;
    }
    .pdf_header > div {
        width: 25%;
    }
    .pdf_header .logo-left img {
        width: 185px;
    }
    .pdf_header .logo-right img {
        width: 300px;
    }
    .pdf_fotter{
        color: #000;
        font-size: 14px !important;
        line-height: 20px;
    }
    .primary-color {
        line-height: 56px;
    }
    .ssd-infofor-me .editor {
        color: #000;
    }
    .ifmBtn i {
        font-size: 14px;
        padding: 0 5px;
        color: #515050;
    }
    .push-right {
        margin-right: 10px;
    }
    .nhsuk-heading-m, h3 {
        margin-bottom: 24px;
    }
    .ssd-infofor-me ul {
        padding: 0;
        margin-bottom: 24px;
    }
    .ssd-infofor-me ul li{
        list-style: none;
    }
    .row.push--ends h3 {
        color: #000;
        line-height: 32px;
        font-weight: 600;
    }
    h3.delta.dark-grey-2.push-half--bottom {
        color: #4d4d4d;
    }
    .panel-times dd, .panel-times dt {
        display: block;
        float: left;
        padding: 2px 0;
        width: 50%;
        margin-bottom: 0;
        color: #000;
        font-weight: 400;
    }
    .medium-6 {
        width: 46%;
        width: -webkit-calc(50% - 36px);
        width: calc(44% - 41px);
    }
    .left_contact dl dt, .left_contact dl dd {
        font-size: 16px;
        font-weight: 400;
        color: #4d4d4d;
        line-height: 24px;
        margin: 0;
    }
    .left_contact dl {
        margin-bottom: 8px;
    }
    .left_contact a:link {
        color: #03759b;
    }
    .left_contact a.external:after {
        content: "\f08e" !important;
        font-family: 'FontAwesome';
        margin-left: 5px;
        font-size: 11px;
        color: #013664;
    }
    div#last-updated-date {
        margin: 16px 0 !important;
    }
    .contact_details {
        margin-bottom: 16px !important;
    }
 </style>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script> 
<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
<script type="text/javascript">
    
// Define the Avenir W01 font in jsPDF
const avenirFont = {
  "normal": "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot",
  "bold": "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot",
  "italic": "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot",
  "bolditalic": "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot"
};

// Add the Avenir W01 font to jsPDF
const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
});
pdf.addFileToVFS(avenirFont.normal, "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot");
pdf.addFileToVFS(avenirFont.bold, "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot");
pdf.addFileToVFS(avenirFont.italic, "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot");
pdf.addFileToVFS(avenirFont.bolditalic, "http://localhost/nhs/wp-content/themes/nhsinform/healthy-living/fonts/AvenirLTW01-35Light.eot");
pdf.addFont(avenirFont.normal, "Avenir", "normal");
pdf.addFont(avenirFont.bold, "Avenir", "bold");
pdf.addFont(avenirFont.italic, "Avenir", "italic");
pdf.addFont(avenirFont.bolditalic, "Avenir", "bolditalic");

var elementHandler = {
    '#ignorePDF': function (element, renderer) {
        return true;
    },'a': function (element, renderer) {
    var href = element.href;
    if (href.indexOf('#') !== 0) {
      renderer.link(href, element.textContent, { underline: false });
    }
  }
};

var htmlContent = document.getElementById("print_doc");
html2canvas(htmlContent).then((canvas) => {

  const imgData = canvas.toDataURL("image/png");
  pdf.setFont("Avenir");
  pdf.setFontSize(12); 
  const downloadBtn = document.getElementById("download-pdf");
  const content = document.getElementById("ifmPreview");

  downloadBtn.addEventListener("click", () => {
    content.classList.add("highlight");

     const style = document.createElement('style');
      style.innerHTML = `
    
        h1, h2, h3, h4, h5, h6 {
          font-weight: bold;font-size: 12px;
        }
            .pdf_header .logo-left img {
            width: 19px !important;
            max-width: 19px;
          }
           .pdf_header .logo-right img {
            width: 19px !important;
            max-width: 19px;
          }
         .highlight img {
            max-width: 50%;
            width: 50%;
          }
      `;
      document.head.appendChild(style);
            

    pdf.fromHTML(
        htmlContent,
        7,
        7,
        {
            'width': 180,
            'elementHandlers': elementHandler
        },
        function() {
            
           pdf.save("my-pdf-file.pdf");
        
        document.head.removeChild(style);
    }); 
    
    setTimeout(() => {
        content.classList.remove("highlight");
      }, 500);
  });
  
});
</script>