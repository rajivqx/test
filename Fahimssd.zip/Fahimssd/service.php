<?php get_header(); ?>
    <?php 
    global $wp;
    $url= home_url( $wp->request );
    $url = explode("/",$url);
    $url = end($url);
    ?>
    <!--Banner Section HTML End-->
    <!-- Symptoms Section HTML Start -->
    <div class="bg-white-grey soft--bottom ssd-services-list">
        <div class="container">
            <?php 
                function ServiceAllServiceDatas($data){
                    global $wp;
                    $url= home_url( $wp->request );
                    $url = explode("/",$url);
                    $url = end($url);

                    switch ($url) {
                        case "dental-services":
                            $url = "dentist";
                            break;
                        case "gp-practices":
                            $url = "gp-practice";
                            break;
                        case "health-and-wellbeing-services":
                            $url = "hwb";
                            break;
                        case "hospitals":
                            $url = "hospital";
                            break;
                        case "opticians":
                            $url = "optician";
                            break;
                        case "pharmacies":
                            $url = "pharmacy";
                            break;
                        case "sexual-health-clinics":
                            $url = "sexual-health-clinic";
                            break;
                      default:
                        $url = "accident-and-emergency";
                    }

                    $key = $data;
                    $args = array(
                        'headers' => array(
                            'Ocp-Apim-Subscription-Key' => $key,
                            'Authorization' => $key
                        ),
                    ); 
                    $headers = array(
                       "Ocp-Apim-Subscription-Key: $key",
                       "Authorization: $key",
                    );

                    $arkey = array('svc'=>'','la'=>'Local Authority','svcsubtype'=>'Services Offered','scope'=>'','svctype'=>'Topic','scht'=>'Open on...','hb'=>'Health Board','ds'=>'');
                    $check_cler = [];
                    foreach ($arkey as $key => $value) {
                        if (!empty($_GET[$key])) {
                           $check_cler[$key] = $_GET[$key];
                        }
                    }

                    if(!empty($check_cler)){
                        $arkey2 = array('svc'=>'','la'=>'localAuthority','svcsubtype'=>'serviceSubType','scope'=>'','svctype'=>'serviceType','scht'=>'scheduleTags','hb'=>'healthboard','ds'=>'');
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
                        $actual_link = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
                        $actual_link =  explode("?",$actual_link)[1];
                        $actual_link =  explode("&",$actual_link);
                        $data =[];
                        foreach ($actual_link as $values) {
                            $actual_link2 =  explode("=",$values);
                            if (array_key_exists($actual_link2[0],$arkey2)){
                               $data[] =   $arkey2[$actual_link2[0]].'='.$actual_link2[1];
                            }
                        }
                        $parem = implode("&",$data);
                        
                        if (isset($_GET['page'])){

                            $url = 'https://nsdfapp1.azure-api.net/nsd/v2/Global?dataset='.$url.'&filtersOnly=False&'.$parem.'&page='.$_GET['page'];
                        }else{
                            $url = 'https://nsdfapp1.azure-api.net/nsd/v2/Global?dataset='.$url.'&filtersOnly=False&'.$parem;
                        }

                    }else{

                        if (isset($_GET['locpt'])) {
                            if (isset($_GET['searchTerm']) || isset($_GET['page'])){

                                if (isset($_GET['page'])) {
                                    $page = '&page='.$_GET['page'];
                                }else{
                                    $page = '';
                                }
                                if (isset($_GET['searchTerm'])) {
                                    $searchTerm_str = str_replace(' ', '', $_GET['searchTerm']);
                                    $searchTerm = '&locationPointRadius='.$searchTerm_str;
                                    
                                }else{
                                    $searchTerm = '';
                                }
                                $url = 'https://nsdfapp1.azure-api.net/nsd/v2/Global?dataset='.$url.'&filtersOnly=False&locationPoint='.$_GET['locpt'].$page.$searchTerm;
                            }else{
                                $url = 'https://nsdfapp1.azure-api.net/nsd/v2/Global?dataset='.$url.'&filtersOnly=False&locationPoint='.$_GET['locpt'];
                            }

                        }else{

                            if (isset($_GET['page'])){
                                $url = 'https://nsdfapp1.azure-api.net/nsd/v2/Global?dataset='.$url.'&filtersOnly=False&page='.$_GET['page'];
                            }else{
                                $url = 'https://nsdfapp1.azure-api.net/nsd/v2/Global?dataset='.$url.'&filtersOnly=False';
                            }
                        }
                    }
                    
                  ?>
                    <?php
                        if (isset($_GET['d'])){
                            if (!is_wp_error($response)){
                                $body = wp_remote_retrieve_body($response);
                                $data = json_decode($body);
                                if ($data){
                                    include(dirname(__FILE__) . "/service-details.php");
                                }
                            }
                        }else{
                            
                            $curl = curl_init($url);
                            curl_setopt($curl, CURLOPT_URL, $url);
                            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
                            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                            $resp = curl_exec($curl);
                            curl_close($curl);
                            $collectionJsone = json_decode($resp);
                            include(dirname(__FILE__) . "/service-list.php"); 
                        }
                    ?>
                <?php 
                }
                ServiceAllServiceDatas('065671d43cfa4e38b9788f2aba0c356a');
            ?>


                           
        </div>
</div>

 

<?php 
    get_footer();
?>

<!-- 2c70930a268a40ebbb497ab929f28fb1 -->