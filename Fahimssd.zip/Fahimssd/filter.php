<?php 
    $actualLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
?>
<span class="js-toggle btn btn--icon btn--feedback">Refine your search</span>
        
    <div id="search-filters" class="col small-12 large-3 no-print panel-search-filters">
        <?php 
            $arkey = array('svc'=>'','la'=>'Local Authority','svcsubtype'=>'Services Offered','scope'=>'','svctype'=>'Topic','scht'=>'Open on...','hb'=>'Health Board','ds'=>'');
            $check_cler = [];
            foreach ($arkey as $key => $value) {
                if (!empty($_GET[$key])) {
                   $check_cler[] = $_GET[$key];
                }
            }
            if (!empty($check_cler) || isset($_GET['locpt'])):
        ?>
        
        <h3 class="gamma bold push-half--bottom">Your Selections 
            <a href="<?= home_url( $wp->request ) ?>">
                Clear
                <span class="visuallyhidden">Your Selections</span>
            </a>
        </h3>
        <ul class="nhsuk-selected"></ul>
            <?php if (isset($_GET['locpt']) ): ?>
                <script>
                    jQuery(document).ready(function(){

                        const url = new URL(window.location.href);
                        const searchParams = new URLSearchParams(url.search);
                        searchParams.delete('locpt');
                        searchParams.delete('q');
                        searchParams.delete('sortby');
                        searchParams.delete('sortdir');
                        url.search = searchParams.toString();

                        jQuery(".nhsuk-selected").append(`
                             <li class="nhsuk-selected__item">
                                <a href="`+url.toString()+`" class="nhsuk-selected__link">
                                    <span class="nhsuk-selected__remove" aria-hidden="true">
                                        <span class="fa fa-xmark"></span>
                                    </span>
                                    Stop Searching This Location
                                </a>
                            </li>
                        `);
                    });
                </script>
            <?php endif; ?>
            <script>
                jQuery(document).ready(function(){
                    jQuery('li.filter__list-item.selected').each(function(){
                        var fil_text = jQuery(this).find('.f_title').text();
                        var url = jQuery(this).find('a').attr('href');
                         jQuery(".nhsuk-selected").append(`
                             <li class="nhsuk-selected__item">
                                <a href="`+url+`" class="nhsuk-selected__link">
                                    <span class="nhsuk-selected__remove" aria-hidden="true">
                                        <i class="fa fa-xmark" aria-hidden="true"></i>
                                    </span>
                                    `+fil_text+`
                                </a>
                            </li>
                        `);
                    });
                });
            </script>
        <?php endif; ?>

        <h3 class="gamma bold push-half--bottom">Refine your search</h3>
            <?php  
                $arkey = array('svc'=>'','la'=>'Local Authority','svcsubtype'=>'Services Offered','scope'=>'','svctype'=>'Topic','scht'=>'Open on...','hb'=>'Health Board','ds'=>'');
                  
            if($collectionJsone):
                foreach ($collectionJsone->Aggregations as $key => $value): 
                 if(array_key_exists($key,$arkey)):
                 if(!empty($arkey[$key]) && count($value->Items) > 0):
                    if($key=="scht"): ?>
                      <?php if (count($value->Items) > 1 || strpos($actualLink, 'scht') !== false): ?>   
                      <details class="nhsuk-details push-half--bottom">
                        <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-4" aria-expanded="false">
                            <span class="nhsuk-details__summary-text">
                                <?= $arkey[$key]; ?>  (<?= count($value->Items) ?>)
                            </span>
                        </summary>
                        <div class="push-half--left" id="details-content-4" aria-hidden="true">
                            <ul class="filter__list">
                                <?php sort($value->Items);?>
                                <?php foreach ($value->Items as $keys => $values):?>
                                    <?php if ($values->Text != 'None'): ?>
                                        <li class="filter__list-item <?php if ($values->Selected == true) { echo "selected"; } ?>">
                                            <?php 
                                                $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
                                                $actual_link = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
                                                $actual_link = str_replace('sortby=_distance&sortdir=Asc&',"",$actual_link);


                                                if(strpos($actual_link, 'page') !== false){
                                                    $actual_link2 =  explode("&",$actual_link);

                                                    $rm = [];
                                                    foreach ($actual_link2 as $key => $value) {
                                                            if(strpos($value, 'page') !== false){
                                                            $rm[] = $value;
                                                            }
                                                    }
                                                    $actual_link = str_replace('?'.$rm[0],"",$actual_link); 
                                                    $actual_link = str_replace('&'.$rm[0],"",$actual_link); 
                                                }
                                                ?>
                                                <?php if ($values->Selected == true): ?>
                                                    <?php 
                                                        $rem = $key."=".$values->Value;
                                                    ?>
                                                    <?php $actual_link = str_replace($rem,"",$actual_link); ?>
                                                    <a href="<?= $actual_link ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                                <?php  else: 
                                                if(strpos($actual_link, '?') !== false): ?>
                                                        <a href="<?= $actual_link ?>&<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                                        
                                                <?php else: ?>

                                                    <a href="?<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                                <?php endif; ?>
                                            <?php  endif;  ?>
                                                <span class="f_title"><?= $values->Text; ?></span>
                                                <span class="filter__list-count">(<?= $values->DocCount; ?>)</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </details>
                 <?php 
                    
                    endif; 
                    endif; 
                 endif; 
                 endif;
                endforeach;  

                foreach ($collectionJsone->Aggregations as $key => $value): 
                    if(array_key_exists($key,$arkey)):
                    if(!empty($arkey[$key]) && count($value->Items) > 0):
                       if($key=="svctype"):?>
                        <?php if (count($value->Items) > 1 || strpos($actualLink, 'svctype') !== false): ?>
                         <details class="nhsuk-details push-half--bottom">
                            <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-4" aria-expanded="false">
                                <span class="nhsuk-details__summary-text">
                                    <?= $arkey[$key]; ?>  (<?= count($value->Items) ?>)
                                </span>
                            </summary>
                            <div class="push-half--left" id="details-content-4" aria-hidden="true">
                                <ul class="filter__list">
                                    <?php sort($value->Items);?>
                                    <?php foreach ($value->Items as $keys => $values):?>
                                        <?php if ($values->Text != 'None'): ?>
                                            <li class="filter__list-item <?php if ($values->Selected == true) { echo "selected"; } ?>">
                                                <?php 
                                                    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
                                                    $actual_link = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
                                                    $actual_link = str_replace('sortby=_distance&sortdir=Asc&',"",$actual_link);


                                                    if(strpos($actual_link, 'page') !== false){
                                                        $actual_link2 =  explode("&",$actual_link);

                                                        $rm = [];
                                                        foreach ($actual_link2 as $key => $value) {
                                                                if(strpos($value, 'page') !== false){
                                                                $rm[] = $value;
                                                                }
                                                        }
                                                        $actual_link = str_replace('?'.$rm[0],"",$actual_link); 
                                                        $actual_link = str_replace('&'.$rm[0],"",$actual_link); 
                                                    }
                                                    ?>
                                                    <?php if ($values->Selected == true): ?>
                                                        <?php 
                                                            $rem = $key."=".$values->Value;
                                                        ?>
                                                        <?php $actual_link = str_replace($rem,"",$actual_link); ?>
                                                        <a href="<?= $actual_link ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                                    <?php  else: 
                                                    if(strpos($actual_link, '?') !== false): ?>
                                                            <a href="<?= $actual_link ?>&<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                                            
                                                    <?php else: ?>

                                                        <a href="?<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                                    <?php endif; ?>
                                                <?php  endif;  ?>
                                                    <span class="f_title"><?= $values->Text; ?></span>
                                                    <span class="filter__list-count">(<?= $values->DocCount; ?>)</span>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </details>
                   <?php
                       endif; 
                       endif; 
                    endif; 
                    endif;
                endforeach; 

   foreach ($collectionJsone->Aggregations as $key => $value): 
    if(array_key_exists($key,$arkey)):


    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 

    if(!empty($arkey[$key]) && count($value->Items) > 0):


       if(($key=="svcsubtype" && strpos($actual_link, 'health-and-wellbeing-services') == false) || $key=="svcsubtype" && strpos($actual_link, 'svctype') !== false):?>

        <?php if (count($value->Items) > 1 || strpos($actualLink, 'svcsubtype') !== false): ?>

        <details class="nhsuk-details push-half--bottom">
            <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-4" aria-expanded="false">
                <span class="nhsuk-details__summary-text">
                    <?= $arkey[$key]; ?>  (<?= count($value->Items) ?>)
                </span>
            </summary>
            <div class="push-half--left" id="details-content-4" aria-hidden="true">
                <ul class="filter__list">
                    <?php sort($value->Items);?>
                    <?php foreach ($value->Items as $keys => $values):?>
                        <?php if ($values->Text != 'None'): ?>
                            <li class="filter__list-item <?php if ($values->Selected == true) { echo "selected"; } ?>">
                                <?php 
                                    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
                                    $actual_link = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
                                    $actual_link = str_replace('sortby=_distance&sortdir=Asc&',"",$actual_link);


                                    if(strpos($actual_link, 'page') !== false){
                                        $actual_link2 =  explode("&",$actual_link);

                                        $rm = [];
                                        foreach ($actual_link2 as $key => $value) {
                                                if(strpos($value, 'page') !== false){
                                                $rm[] = $value;
                                                }
                                        }
                                        $actual_link = str_replace('?'.$rm[0],"",$actual_link); 
                                        $actual_link = str_replace('&'.$rm[0],"",$actual_link); 
                                    }
                                    ?>
                                    <?php if ($values->Selected == true): ?>
                                        <?php 
                                            $rem = $key."=".$values->Value;
                                        ?>
                                        <?php $actual_link = str_replace($rem,"",$actual_link); ?>
                                        <a href="<?= $actual_link ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                    <?php  else: 
                                    if(strpos($actual_link, '?') !== false): ?>
                                            <a href="<?= $actual_link ?>&<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                            
                                    <?php else: ?>

                                        <a href="?<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                    <?php endif; ?>
                                <?php  endif;  ?>
                                    <span class="f_title"><?= $values->Text; ?></span>
                                    <span class="filter__list-count">(<?= $values->DocCount; ?>)</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </details>
   <?php
       endif; 
       endif; 
    endif; 
    endif;
   endforeach; 

   foreach ($collectionJsone->Aggregations as $key => $value): 
    if(array_key_exists($key,$arkey)):
    if(!empty($arkey[$key]) && count($value->Items) > 0):
       if($key=="hb"): ?>

        <?php if (count($value->Items) > 1 || strpos($actualLink, 'hb') !== false): ?>
            
        <details class="nhsuk-details push-half--bottom">
            <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-4" aria-expanded="false">
                <span class="nhsuk-details__summary-text">
                    <?= $arkey[$key]; ?>  (<?= count($value->Items) ?>)
                </span>
            </summary>
            <div class="push-half--left" id="details-content-4" aria-hidden="true">
                <ul class="filter__list">
                    <?php sort($value->Items);?>
                    <?php foreach ($value->Items as $keys => $values):?>
                        <?php if ($values->Text != 'None'): ?>
                            <li class="filter__list-item <?php if ($values->Selected == true) { echo "selected"; } ?>">
                                <?php 
                                    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
                                    $actual_link = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
                                    $actual_link = str_replace('sortby=_distance&sortdir=Asc&',"",$actual_link);


                                    if(strpos($actual_link, 'page') !== false){
                                        $actual_link2 =  explode("&",$actual_link);

                                        $rm = [];
                                        foreach ($actual_link2 as $key => $value) {
                                                if(strpos($value, 'page') !== false){
                                                $rm[] = $value;
                                                }
                                        }
                                        $actual_link = str_replace('?'.$rm[0],"",$actual_link); 
                                        $actual_link = str_replace('&'.$rm[0],"",$actual_link); 
                                    }
                                    ?>
                                    <?php if ($values->Selected == true): ?>
                                        <?php 
                                            $rem = $key."=".$values->Value;
                                        ?>
                                        <?php $actual_link = str_replace($rem,"",$actual_link); ?>
                                        <a href="<?= $actual_link ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                    <?php  else: 
                                    if(strpos($actual_link, '?') !== false): ?>
                                            <a href="<?= $actual_link ?>&<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                            
                                    <?php else: ?>

                                        <a href="?<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                    <?php endif; ?>
                                <?php  endif;  ?>
                                    <span class="f_title"><?= $values->Text; ?></span>
                                    <span class="filter__list-count">(<?= $values->DocCount; ?>)</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </details>
    <?php
       endif; 
       endif; 
    endif; 
    endif;
   endforeach; 

   foreach ($collectionJsone->Aggregations as $key => $value): 
    if(array_key_exists($key,$arkey)):
    if(!empty($arkey[$key]) && count($value->Items) > 1):
     if($key == "la"):?>

        <?php if (count($value->Items) > 1  || strpos($actualLink, 'la') !== false): ?>
        <details class="nhsuk-details push-half--bottom">
            <summary class="nhsuk-details__summary" role="button" aria-controls="details-content-4" aria-expanded="false">
                <span class="nhsuk-details__summary-text">
                    <?= $arkey[$key]; ?>  (<?= count($value->Items) ?>)
                </span>
            </summary>
            <div class="push-half--left" id="details-content-4" aria-hidden="true">
                <ul class="filter__list">
                    <?php sort($value->Items);?>
                    <?php foreach ($value->Items as $keys => $values):?>
                        <?php if ($values->Text != 'None'): ?>
                            <li class="filter__list-item <?php if ($values->Selected == true) { echo "selected"; } ?>">
                                <?php 
                                    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
                                    $actual_link = trim($actual_link,"&sortby=_distance&sortdir=Asc"); 
                                    $actual_link = str_replace('sortby=_distance&sortdir=Asc&',"",$actual_link);


                                    if(strpos($actual_link, 'page') !== false){
                                        $actual_link2 =  explode("&",$actual_link);

                                        $rm = [];
                                        foreach ($actual_link2 as $key => $value) {
                                                if(strpos($value, 'page') !== false){
                                                $rm[] = $value;
                                                }
                                        }
                                        $actual_link = str_replace('?'.$rm[0],"",$actual_link); 
                                        $actual_link = str_replace('&'.$rm[0],"",$actual_link); 
                                    }
                                    ?>
                                    <?php if ($values->Selected == true): ?>
                                        <?php 
                                            $rem = $key."=".$values->Value;
                                        ?>
                                        <?php $actual_link = str_replace($rem,"",$actual_link); ?>
                                        <a href="<?= $actual_link ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                    <?php  else: 
                                    if(strpos($actual_link, '?') !== false): ?>
                                            <a href="<?= $actual_link ?>&<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                            
                                    <?php else: ?>

                                        <a href="?<?= $key ?>=<?= $values->Value; ?>&sortby=_distance&sortdir=Asc" class="filter__list-link">
                                    <?php endif; ?>
                                <?php  endif;  ?>
                                    <span class="f_title"><?= $values->Text; ?></span>
                                    <span class="filter__list-count">(<?= $values->DocCount; ?>)</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </details>

<?php 
    endif;
    endif;
    endif; 
endif;
endforeach;?>



<?php endif; ?>

                    
            </div> 