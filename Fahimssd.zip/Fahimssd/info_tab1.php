<ul id="draggable-list"></ul> 
<?php 
    if (isset($_COOKIE['data'])):

        if ($_COOKIE['data'] == '[]'): ?>
            <script type="text/javascript">
                jQuery(document).ready(function() {
                    jQuery('#draggable-list').append('<p style="padding: 0; margin: 0; text-align: center; font-weight: bold">You have not saved any items yet.</p>');
                });
            </script>
       <?php endif;

        $service_user_data = $_COOKIE['data'];
        $service_user_data = preg_replace('/\\\"/',"\"", $service_user_data);
?>
    <script type="text/javascript">
    


        let itemsData = <?= $service_user_data ?>;
        const draggableList = document.getElementById('draggable-list');

        function updateItemsData() {
          itemsData = [...draggableList.querySelectorAll('li')].map((li, index) => {

            const aTag = li.querySelector('a');
            const data_id = li.querySelector('span');
            const button = li.querySelector('button');

            return {dataset: button.textContent ,Id: data_id.textContent, name: aTag.textContent};
          });
        }
        draggableList.addEventListener('dragstart', (event) => {
            if (event.target.tagName === 'A') {
                event.preventDefault();
                return;
            }
          event.target.classList.add('dragging');

        });

        draggableList.addEventListener('dragend', (event) => {
          event.target.classList.remove('dragging');
            updateItemsData();
            const expirationTime = new Date(Date.now() + 3600000).toUTCString();
            const jsonString = JSON.stringify(itemsData);
            document.cookie = "data="+jsonString+"; expires=" + expirationTime + "; path=/";
        });

        draggableList.addEventListener('dragover', (event) => {
          event.preventDefault();
          const afterElement = getDragAfterElement(draggableList, event.clientY);
          const draggable = document.querySelector('.dragging');
          if (afterElement == null) {
            draggableList.appendChild(draggable);
          } else {
            draggableList.insertBefore(draggable, afterElement);
          }
        });
        function getDragAfterElement(container, y) {
          const draggableElements = [...container.querySelectorAll('li:not(.dragging)')];
          return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) {
              return {offset: offset, element: child};
            } else {
              return closest;
            }
          }, {offset: Number.NEGATIVE_INFINITY}).element;
        }

        function getUrl(url){

            switch (url) {
                case "dentist":
                    url = "scotlands-service-directory/dental-services";
                    break;
                case "gp-practice":
                    url = "scotlands-service-directory/gp-practices";
                    break;
                case "hwb":
                    url = "scotlands-service-directory/health-and-wellbeing-services";
                    break;
                case "hospital":
                    url = "scotlands-service-directory/hospitals";
                    break;
                case "optician":
                    url = "scotlands-service-directory/opticians";
                    break;
                case "pharmacy":
                    url = "scotlands-service-directory/pharmacies";
                    break;
                case "sexual-health-clinic":
                    url = "scotlands-service-directory/sexual-health-clinics";
                    break;
                case "accident-and-emergency":
                    url = "scotlands-service-directory/aes-and-minor-injuries-units";
                    break;
                default:
                    url = url.replace('post-/', '');
            };
  
            return url;
        }
        draggableList.innerHTML = itemsData.map(item => `<li class="ifmCartItem" draggable="true"><a class="ifmCartItem__title" href="<?php echo esc_url( home_url( '/' ) ); ?>`+getUrl(item.dataset)+`/${item.Id}">${item.name}</a><span title="Drag" class="ifmMoveIcon">${item.Id}</span><button title="Remove" id="${item.Id}" class="ifmRemoveIcon">${item.dataset}</button></li>`).join('');

    </script>


    <?php 
        $service_user_data = $_COOKIE['data'];
        $service_user_data = preg_replace('/\\\"/',"\"", $service_user_data);
        $json_array = json_decode($service_user_data);
        if (!empty($json_array )) {
           $datas  = $json_array ;
        }else{
            $datas  = [];
        }
        if (count($datas) > 0):
    ?>
        <div id="ifmButtonWrapper">
            <button id="ifmRemoveAllButton" class="ifmBtn">Remove All</button>
             <a href="" class="ifmBtn push-right ifmBtn--checkout" title="Click here to go back.">
                <button type="submit" id="ifmCheckoutButton" class="ifmBtn ifmBtn--checkout">Print, Save, Share</button>
            </a>
            </form>
        </div>
    <?php endif; ?>

    <script type="text/javascript">
        jQuery(document).ready(function() {

            // remove all
            jQuery('button#ifmRemoveAllButton').on('click', function() {
                var numItems = $('.user_info span').text(0);
                $.cookie('data', '[]',{ expires: 30, path: '/' });

                jQuery('div#ifmButtonWrapper').remove();
                jQuery('#draggable-list li').remove();
                jQuery('#draggable-list').append('<p style="padding: 0; margin: 0; text-align: center; font-weight: bold">You have not saved any items yet.</p>');
            });

            // nex_tab
            $.cookie('service_tab', 1,{ expires: 30, path: '/' });

            jQuery('.ifmBtn--checkout').on('click', function() {
                let itemsData = $.cookie('data');
                $.cookie('service_tab', 2,{ expires: 30, path: '/' });
            });


            // remove one by one

            jQuery('.ifmRemoveIcon').on('click', function() {

                let storedDataString = $.cookie('data');
                try {
                    let jsonStr = JSON.parse(storedDataString);
                    let count = jsonStr.length-1;
                    var numItems = $('.user_info span').text(count);
                } catch (e) {
                  var numItems = $('.user_info span').text(0);
                }


                var numItems = $('.ifmCartItem').length;
                if (numItems < 2) {
                    let myData = $.cookie('data');
                    let jsonStr = JSON.parse(myData);
                    let remove = jQuery(this).attr('id');
                    let indexToRemove = -1;
                    let id;

                    for (let i = 0; i < jsonStr.length; i++) {
                      if (jsonStr[i].Id === remove ) {
                        indexToRemove = i;
                        id = jsonStr[i].Id;
                        break;
                      }
                    }

                    if (indexToRemove !== -1) {
                        let newArray = jsonStr.filter(obj => obj.Id !== id);
                        let dataStrinsg = JSON.stringify(newArray); 
                        $.cookie('data', dataStrinsg,{ expires: 30, path: '/' });
                    }

                    jQuery(this).closest('li').remove();
                    jQuery('div#ifmButtonWrapper').remove();
                    jQuery('#draggable-list').append('<p style="padding: 0; margin: 0; text-align: center; font-weight: bold">You have not saved any items yet.</p>');
                }else{

                    let myData = $.cookie('data');
                    let jsonStr = JSON.parse(myData);
                    let remove = jQuery(this).attr('id');
                    let indexToRemove = -1;
                    let id;

                    for (let i = 0; i < jsonStr.length; i++) {

                        console.log(jsonStr[i].Id);
                        console.log(remove);

                      if (jsonStr[i].Id === remove ) {
                        indexToRemove = i;
                        id = jsonStr[i].Id;
                        break;
                      }
                    }

                    if (indexToRemove !== -1) {
                        let newArray = jsonStr.filter(obj => obj.Id !== id);
                        let dataStrinsg = JSON.stringify(newArray); 
                        $.cookie('data', dataStrinsg,{ expires: 30, path: '/' });
                        console.log(newArray);
                    }
                    jQuery(this).closest('li').remove();
                }
            });
        });
    </script>

    <style type="text/css">
        ul#draggable-list {
            background: #eee;
            padding: 12px;
            list-style: none;
            margin: 24px 0;
        }
        .ifmCartItem__title {
            display: block;
            margin: 0.5rem 0;
            width: calc(100% - 96px);
        }
        li.ifmCartItem{
            padding: 12px;
            background: #fff;
            margin-bottom: 12px;
            position: relative;
        }
        .ifmMoveIcon, .ifmRemoveIcon {
            border: none;
            color: rgb(209,202,202);
            width: 28px;
            height: 28px;
            outline: none;
            padding: 4px;
            float: left;
            position: absolute;
        }
        .ifmMoveIcon {
            background: #dcedf4 url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxMy4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDE0OTQ4KSAgLS0+DQo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4iICJodHRwOi8vd3d3LnczLm9yZy9HcmFwaGljcy9TVkcvMS4xL0RURC9zdmcxMS5kdGQiPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiDQoJIGlkPSJzdmcyIiBpbmtzY2FwZTp2ZXJzaW9uPSIwLjQ4LjQgcjk5MzkiIHNvZGlwb2RpOmRvY25hbWU9Im1vdmUuc3ZnIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIiB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSINCgkgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiIHdpZHRoPSIxMjAwcHgiIGhlaWdodD0iMTIwMHB4Ig0KCSB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCAxMjAwIDEyMDAiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPHBhdGggaWQ9InBhdGgxNDY2MSIgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgZD0iTTAsNjAwbDIwNi45MDksMjA2LjkwOWwtMC42MjMtMTQ0Ljc2NGgzMzEuNTY4djMzMi4xNTNsLTE0Mi45MzMsMC42MjMNCglMNjAwLDEyMDBsMjA2LjkwOS0yMDYuOTA5bC0xNDQuNzY0LDAuNjIyVjY2Mi4xNDZIOTk0LjNsMC42MjIsMTQyLjkzM0wxMjAwLDYwMEw5OTMuMDkxLDM5My4wOTFsMC42MjMsMTQ0Ljc2M0g2NjIuMTQ2VjIwNS43MDENCglsMTQyLjkzMy0wLjYyM0w2MDAsMEwzOTMuMDkxLDIwNi45MDlsMTQ0Ljc2NC0wLjYyM3YzMzEuNTY4SDIwNS43MDFsLTAuNjIzLTE0Mi45MzNMMCw2MDBMMCw2MDB6Ii8+DQo8L3N2Zz4NCg==) no-repeat;
            text-indent: -9999em;
            background-size: 20px;
            background-position: center;
            display: block;
            right: 52px;
            top: 20px;
        }
        
        .ifmRemoveIcon {
            background: #dcedf4 url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDIwLjEuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHZpZXdCb3g9IjAgMCA2NDUuMyA2NDUuMyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNjQ1LjMgNjQ1LjM7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBvbHlnb24gcG9pbnRzPSI1NTcuMiwwIDMyMi40LDIzNC44IDg3LjcsMCAwLjQsODguMSAyMzQuOCwzMjIuNCAwLDU1Ny4yIDg4LjEsNjQ0LjUgMzIyLjQsNDEwLjEgNTU3LjYsNjQ1LjMgNjQ0LjksNTU3LjIgCgk0MTAuMSwzMjIuNCA2NDUuMyw4Ny4zICIvPgo8L3N2Zz4K) no-repeat;
            text-indent: -9999em;
            background-size: 13px;
            background-position: center;
            margin-right: 6px;
            right: 12px;
            top: 20px;
        }
        .draggable {
          cursor: move;
        }

        .dragging {
          opacity: 0.5;
        }

    </style>
<?php endif; ?>