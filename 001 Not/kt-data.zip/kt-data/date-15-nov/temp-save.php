<?php

/*
<?php $home_url = home_url(); ?>

<?php $home_url = home_url( '/about-us' ); ?>

<?php $home_url = home_url( '/contact', 'https' ); ?>


// Link for Help https://usersinsights.com/wordpress-login-redirect/

if (is_page('about-us')) {
        // Redirect to the new destination
        wp_redirect('https://example.com/new-about-us-page');

*/



function thrv_custom_page_redirect1() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    elseif(is_page('host-profile') && is_user_logged_in() && current_user_can('host'))
    {
        wp_redirect(home_url('/host-profile'));
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect1');

function thrv_custom_page_redirect2() {
    // Check if it's the specific page you want to redirect from
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect2');



//################Retrieving data from two table###########################

SELECT post.post_id, post.title, post.content, custom.custom_id, custom.custom_data
FROM post
JOIN custom ON post.post_id = custom.post_id;



//#################################################################
<?php
function custom_post_statuses() {
    register_post_status('approved', array(
        'label' => _x('Approved', 'post'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
    ));

    register_post_status('rejected', array(
        'label' => _x('Rejected', 'post'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
    ));
}
add_action('init', 'custom_post_statuses');


function send_approval_rejection_email($new_status, $old_status, $post) {
    if ($new_status == 'approved' || $new_status == 'rejected') {
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Post Status Update';
        $message = "Your post titled '{$post->post_title}' has been {$new_status}.";
        wp_mail($to, $subject, $message);
    }
}
add_action('transition_post_status', 'send_approval_rejection_email', 10, 3);



//######################################################

function send_rejection_email($new_status, $old_status, $post) {
    if ($new_status == 'rejected' && $old_status != 'rejected') {
        
        
        //$message = "We're sorry, but your post titled '{$post->post_title}' has been rejected.";

        $message = '<!DOCTYPE html>
        <html lang="en">
        
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Verify Account</title>
                <!-- css -->
                <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
            </head>
        
            <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
                <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                    <tbody>
                       
                        <tr>
                            <td>
                                <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ProviderName],</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">I hope you are doing well.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">Thank you for submitting your service, </strong>[ServiceName]</strong>, for inclusion on our </strong>[THRV Team]</strong>. We appreciate the time and effort you put into developing your offering.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> After careful consideration, we regret to inform you that we are unable to approve your service for listing at this time. This decision is based on [brief reason if applicable, e.g., "our current focus areas", "specific criteria not met"].</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> We value your contribution to the wellness community and encourage you to consider reapplying in the future. If you would like detailed feedback or guidance on how to align your service with our platform criteria, please feel free to reach out. We are more than happy to assist.

                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0;">Best regards,</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        
        </html>';
        
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Update on Your Service Submission to [THRV Team]';

        // Assuming $post_id is the ID of your custom post
        $post_id = 123; // Replace with your custom post ID

        // Get the author ID of the custom post
        $author_id = get_post_field('post_author', $post_id);

        // Get the author name using the author ID
        $author_name = get_the_author_meta('display_name', $author_id);

        // Output or use the author name as needed
        //echo 'Author Name: ' . $author_name;

        // Get the custom post title using the post ID
        $custom_post_title = get_the_title($post_id);


        $data['provider_name']="Aman Host";
        //$data['provider_name']="Aman Host";
        $data['service_name']="Song Traning";
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ProviderName]', '[ServiceName]'], [$user_data['provider_name'], $user_data['service_name']] $message);
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
        wp_mail($to, $subject, $htmlContent, $headers);
        
    }
}
add_action('transition_post_status', 'send_rejection_email', 10, 3);
