<?php

/*
Template Name: Feedback Url
*/

thrv_email_template_feedback();



$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM wp_posts AS posts INNER JOIN wp_jet_appointments AS jet_appointments ON posts.ID = jet_appointments.service LEFT JOIN wp_postmeta AS postmeta ON posts.ID = postmeta.post_id  
WHERE posts.post_type = 'experiences' AND postmeta.meta_key = 'experience-type' AND jet_appointments.slot_end < '".$timestamp."' AND jet_appointments.status = 'completed' 
ORDER BY  CAST( jet_appointments.slot as DECIMAL ) DESC LIMIT 6";


/**

$sql="select * from wp_jet_appointments where slot_end <= time()"
UNION
select id, content as title, details from page where content
like '%$str%' or content like '%$str%'";

*/


// Fetch results

$results = $wpdb->get_results($sql);

foreach ($results as $user_detail) {
	echo "<pre>";
	$user = get_user_by( 'ID', $user_detail->user_id);
	print_r($user->user_login);

}

/** Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
    	//$to = $user_detail->user_email;
    	$to = "rajiv.jayaswal@kiwitech.com";
    	$subject = 'Please provide valuable feedback and rating to our experince';
    	// Add URL to the email body

}
Loop End */
    
?>
