<?php
function thrv_custom_page_redirect() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}

add_action('template_redirect', 'thrv_custom_page_redirect');


function custom_role_redirect() {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        // Check if the user has the particular role you want to redirect
        if (in_array('desired_user_role', $current_user->roles)) {
            // Redirect the user with the desired role to the home page
            wp_redirect(home_url());
            exit();
        }
    }
}

// Hook the function to the 'template_redirect' action
add_action('template_redirect', 'custom_role_redirect');



function custom_multi_role_redirect() {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();

        // Define the two roles you want to check
        $desired_roles = array('role1', 'role2');

        // Check if the user has at least one of the desired roles
        if (array_intersect($desired_roles, $current_user->roles)) {
            // Redirect the user with the desired roles to the home page
            wp_redirect(home_url());
            exit();
        }
    }
}

// Hook the function to the 'template_redirect' action
add_action('template_redirect', 'custom_multi_role_redirect');
