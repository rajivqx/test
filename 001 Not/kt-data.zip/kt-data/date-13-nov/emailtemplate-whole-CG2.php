//#########################################
<?php

if(isset($_POST['submit'])){
$str=mysqli_real_escape_string($con, $_POST['str']);
$sql="select id, title, details from news where title
like '%$str%' or details like '%$str%'
UNION
select id, content as title, details from page where content
like '%$str%' or content like '%$str%'";
$res=mysqli_query($con, $sql);
if(mysqli_num_rows($res)>0){
while($row=mysqli_fetch_assoc($res)){
echo $row['title'];
echo "<br/>";
}
}else{
echo "No data found";
}
?>

//#################################



<?php
// custom end point for Feedback URL

add_action( 'rp_my_feedback_func', 'my_feedback_func' );

function my_feedback_func() {
  
 $timestamp = time();
 //$timestamp =1701185400;


global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);


// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
	//$to = $user_detail->user_email;
	$to = "neeraj.sharma@kiwitech.com";
	$subject = 'Please provide valuable feedback and rating to our experince';
	// Add URL to the email body
	
	
	
	// Add URL to the email body
	$url = 'https://thrv.app/user-profile/'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: ".$url."\n";
	
	
	
	// Additional headers if needed
	$headers = array('Content-Type: text/html; charset=UTF-8');
	
	
	//wp_mail($to, $subject, $body, $headers);

	// Send email
	if( $feedback_status != 1)
	{
		wp_mail($to, $subject, $body, $headers);

		$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";

		$wpdb->query($sql2);
		 echo "sent email";
	}

   }
}

?>





//################################
<!-- email_template.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Template</title>
</head>
<body>
    <h1>Hello, [UserName]!</h1>
    <p>Your email is: [UserEmail]</p>
</body>
</html>

//################################
<?php
// functions.php or your custom plugin file

function send_custom_email() {
    global $wpdb; // Access the WordPress database functions

    // Retrieve data from WordPress database
    $user_data = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}users WHERE ID = 1", ARRAY_A);

    // Recipient email address
    $to = $user_data['user_email'];

    // Subject of the email
    $subject = "Dynamic Data Email";

    // Load HTML template content
    $htmlTemplate = file_get_contents(get_template_directory() . '/email_template.php');

    // Replace placeholders with dynamic data
    $htmlContent = str_replace(['[UserName]', '[UserEmail]'], [$user_data['display_name'], $user_data['user_email']], $htmlTemplate);

    // Set content type to HTML
    add_filter('wp_mail_content_type', function () {
        return 'text/html';
    });

    // Send the email
    $mailSent = wp_mail($to, $subject, $htmlContent);

    // Remove the content type filter
    remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');

    return $mailSent;
}
?>
//#############################################################
<?php
// Example usage
send_custom_email();
?>

