

//##########################################################################################
// Rajiv file include here.
require get_template_directory() . '/inc/r1-custom.php';
require get_template_directory() . '/inc/r2-custom.php';



<?php

//First Short code
function display_related_posts($array = array()) 
    {
    return '<h3>My First simple Shortcode</h3>';
    }

add_shortcode('display_related_posts', 'display_related_posts');
 
// echo do_shortcode('[display_related_posts]');



// 2nd Shortcode Example
// Define the shortcode function
function custom_shortcode_function() {
    return '<p>Hello, this is a custom shortcode!</p>';
}

// Register the shortcode
add_shortcode('custom_shortcode', 'custom_shortcode_function');

//[custom_shortcode]



// 3rd Shortcode Example
// Define the shortcode function with a parameter
function rj_custom_shortcode_function($atts) {
    // Extract shortcode attributes
    $atts = shortcode_atts(
        array(
            'name' => 'Guest', // Default value if 'name' attribute is not provided
        ),
        $atts,
       // 'rj_custom_shortcode'
    );

    // Use the parameter value in the output
    $output = '<p>Hello, ' . esc_html($atts['name']) . '! This is a custom shortcode.</p>';

    return $output;
}

// Register the shortcode
add_shortcode('rj_custom_shortcode', 'rj_custom_shortcode_function');

//[rj_custom_shortcode name="John"]




//custom Endpoint
function custom_hello_world_endpoint() {
    register_rest_route('custom/v1', '/myendpoint/', array(
        'methods' => 'GET',
        'callback' => 'custom_hello_world_callback',
    ));
}

add_action('rest_api_init', 'custom_hello_world_endpoint');

function custom_hello_world_callback() {
   return 'Hello, World! This is a My First custom endpoint.';
   //echo'Hello World';
}
// Custom End point URL
//http://abcx.co.in/wp-json/custom/v1/myendpoint/








<?php

/*
 * Plugin Name:       Rajiv My Plugin
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the basics with this plugin.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Rajiv Jayaswal
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       rajiv-my-plugin
 * Domain Path:       /languages
 */


// Security check: Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


// Plugin activation tasks

//register_activation_hook(__FILE__, 'your_plugin_activation');



// Deactivation hook

/**
 function your_plugin_deactivation() {
  
  if (!current_user_can('activate_plugins')) {
        wp_die(__('You do not have permission to deactivate this plugin.', 'your-plugin-text-domain'));
    }
    // Additional security checks or cleanup tasks
    // Plugin deactivation tasks
}
*/


//register_deactivation_hook(__FILE__, 'your_plugin_deactivation');

// Plugin installation tasks

//register_installation_hook(__FILE__, 'your_plugin_ installation);





