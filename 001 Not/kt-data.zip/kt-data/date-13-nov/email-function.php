<?php

function send_custom_email($to, $subject, $recipient_name, $custom_message) {
    // Load HTML template content
    $htmlTemplate = file_get_contents(get_template_directory() . '/email_template.php');

    // Replace placeholders with dynamic data
    $htmlContent = str_replace(['%recipient_name%', '%custom_message%'], [$recipient_name, $custom_message], $htmlTemplate);

    // Set content type to HTML
    add_filter('wp_mail_content_type', function () {
        return 'text/html';
    });

    // Send the email
    $mailSent = wp_mail($to, $subject, $htmlContent);

    // Remove the content type filter
    remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');

    return $mailSent;
}
