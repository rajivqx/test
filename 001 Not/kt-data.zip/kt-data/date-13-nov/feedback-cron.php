<?php

/*
Template Name: Feedback Url
*/

$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);


// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
    	//$to = $user_detail->user_email;
    	$to = "rajiv.jayaswal@kiwitech.com";
    	$subject = 'Please provide valuable feedback and rating to our experince';
    	// Add URL to the email body
	
	
	
	// Add URL to the email body
	$url = 'https://thrv.app/user-profile/'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: $url\n";
	
	
	
	// Additional headers if needed
	$headers = array('Content-Type: text/html; charset=UTF-8');
	
	
	//wp_mail($to, $subject, $body, $headers);

	// Send email
	if( $feedback_status != 1)
	{
		wp_mail($to, $subject, $body, $headers);

		//$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"

		//$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";

		$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";

		$wpdb->query($sql2);
	}


    	
    
	
}




echo"<pre>";
print_r($results);
print_r($userId);
print_r($appointmentId);
print_r($feedback_status);
print_r($to);
print_r($subject);
echo"</pre";
    	
    
?>
