<?php

/*
<?php $home_url = home_url(); ?>

<?php $home_url = home_url( '/about-us' ); ?>

<?php $home_url = home_url( '/contact', 'https' ); ?>


// Link for Help https://usersinsights.com/wordpress-login-redirect/

if (is_page('about-us')) {
        // Redirect to the new destination
        wp_redirect('https://example.com/new-about-us-page');

*/


//#################################################################################################################################

global $wpdb;
$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}your_table_name" );

 /**
  * 
    global $post:

    Here are some key pieces of information you can extract from $post:

    ID: $post->ID gives you the unique identifier for the post.
    
    Title: $post->post_title provides the title of the post.
    
    Content: $post->post_content holds the content of the post.
    
    Date: $post->post_date and $post->post_date_gmt give you the date and GMT date of the post.
    
    Author: $post->post_author tells you the author's ID.
    
    Permalink: $post->guid gives you the permalink for the post.

  */   

//###################################################################################################################################


function get_author_related_posts($author_id, $excluded_post){

    global $wpdb;
    $author_posts = $wpdb->get_results(
    "
    SELECT post_author, ID
    FROM $wpdb->posts
    WHERE post_author = '$author_id' and ID != '$excluded_post'
    ORDER BY ID DESC
    "
    );

    return $author_posts;
}



//###################################################################################################################################

//To create a custom WordPress query to select posts based on a custom meta value, you can use the WP_Query class
$args = array(
    'post_type' => 'post', // Replace with your custom post type if needed
    'meta_key' => 'your_meta_key', // Replace with the key of your custom meta field
    'meta_value' => 'your_meta_value', // Replace with the value you want to select
    'meta_compare' => '=', // You can change this to '>', '<', '!=' based on your needs
    'orderby' => 'date', // You can change this to any other valid orderby parameter
    'order' => 'DESC', // Change to 'ASC' for ascending order
    'posts_per_page' => -1, // Set the number of posts to display. -1 for all
);

$query = new WP_Query($args);

if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        // Your loop content goes here
        the_title();
        the_content();
        // Additional loop content
    }
    wp_reset_postdata(); // Reset post data to prevent conflicts
} else {
    // No posts found
    echo 'No posts found';
}

//####################################################################

$args = array(
    'post_type' => 'car-cc',
    'meta_query' => array(
      array(
        'key' => 'type-select',
        'value' => '1',
        'compare' => '='
  ),
      array(
        'key' => 'type-gen',
        'value' => 'my-great-type',
        'compare' => 'LIKE'
      )
    )
  );
  
  $query = new WP_Query( $args );


//###################################################################################################################################

//The term "author meta" typically refers to information associated with a user's profile, which can include custom fields or metadata.

//1. Retrieve Author Meta Data:
//To retrieve meta data for a specific author, you can use the get_the_author_meta() function. 
$author_id = get_the_author_meta('ID'); // Get the ID of the current post's author
$author_meta_value = get_the_author_meta('your_meta_key', $author_id);
// Replace 'your_meta_key' with the actual meta key you want to retrieve


//2. Display Author Meta Data in a Post Loop:
// Inside the loop
$author_id = get_the_author_meta('ID');
$author_meta_value = get_the_author_meta('your_meta_key', $author_id);

echo 'Author Meta: ' . esc_html($author_meta_value);


//3. Update Author Meta Data:
//To update author meta data, you can use the update_user_meta() function. 
$author_id = get_the_author_meta('ID');
update_user_meta($author_id, 'your_meta_key', 'new_meta_value');


// Replace 'your_meta_key' with the actual meta key and 'new_meta_value' with the updated value
//4. Display Author Meta Data on Author Archive Page:
//If you want to display author meta data on an author archive page, you can modify the author template (author.php).
$author_id = get_queried_object_id();
$author_meta_value = get_the_author_meta('your_meta_key', $author_id);

echo 'Author Meta: ' . esc_html($author_meta_value);


//##################################################################################################################################

//global $post variable is used to access information about the current post being processed in the WordPress loop or within certain template files. When you use $post within a function or template file, it refers to the global post object.

//1. Initialization:
global $post;

//2. Accessing Post Data:
$post_id = $post->ID; // Get the post ID
$post_title = $post->post_title; // Get the post title
$post_content = $post->post_content; // Get the post content

//3. Modifying Post Data:
$post->post_title = 'New Title';
//After modifying the post data, it's important to use wp_reset_postdata() to reset the global $post variable to its original value.

//4. Use Cases:
//Inside the Loop:
if (have_posts()) {
    while (have_posts()) {
        the_post();
        global $post; // Initialize $post
        // Access post data here
    }
}

//Within Custom Functions or Template Files:
function custom_function() {
    global $post; // Initialize $post
    // Access or modify post data here
}

//Example
if (have_posts()) {
    while (have_posts()) {
        the_post();
        global $post; // Initialize $post

        // Access post data
        $post_id = $post->ID;
        $post_title = $post->post_title;

        // Modify post data
        $post->post_title = 'Modified Title';

        // Output post content
        echo $post->post_content;
    }
}

wp_reset_postdata(); // Reset global $post


//###################################################################################################################################

function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    // Radius of the Earth in kilometers
    $radius = 6371;

    // Convert latitude and longitude from degrees to radians
    $lat1 = deg2rad($lat1);
    $lon1 = deg2rad($lon1);
    $lat2 = deg2rad($lat2);
    $lon2 = deg2rad($lon2);

    // Calculate differences in coordinates
    $dlat = $lat2 - $lat1;
    $dlon = $lon2 - $lon1;

    // Haversine formula
    $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlon / 2) * sin($dlon / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    // Distance in kilometers
    $distance = $radius * $c;

    return $distance;
}

// Example usage
$latitude1 = 37.7749;
$longitude1 = -122.4194;

$latitude2 = 34.0522;
$longitude2 = -118.2437;

$distance = calculateDistance($latitude1, $longitude1, $latitude2, $longitude2);

echo 'Distance: ' . $distance . ' km';

//####################################################################################################################################

//To use GPS in PHP, you typically interact with GPS data from devices or services that provide location information. Here are two common scenarios:
//Capture GPS Coordinates from a Device:
//If you have a GPS-enabled device (e.g., a smartphone) that provides GPS coordinates, you can capture and send that data to a server using PHP. For example, you might use a mobile app to get the GPS coordinates and send them to a PHP server.
//Example PHP code for receiving GPS coordinates from a client:    
// Assuming data is sent via POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get GPS coordinates from POST data
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    // Process the coordinates as needed
    echo "Received coordinates - Latitude: $latitude, Longitude: $longitude";
}

//Geocoding with an API:
// Example using Google Maps Geocoding API
$address = '1600 Amphitheatre Parkway, Mountain View, CA';
$apiKey = 'YOUR_GOOGLE_MAPS_API_KEY';

$address = urlencode($address);
$url = "https://maps.googleapis.com/maps/api/geocode/json?address=$address&key=$apiKey";

// Make API request
$response = file_get_contents($url);
$data = json_decode($response, true);

// Extract and display coordinates
if ($data['status'] === 'OK') {
    $latitude = $data['results'][0]['geometry']['location']['lat'];
    $longitude = $data['results'][0]['geometry']['location']['lng'];
    echo "Latitude: $latitude, Longitude: $longitude";
} else {
    echo "Error: Unable to geocode address.";
}

//##################################################################################################################################

//Built-in WP-Cron system to schedule and run cron jobs. WP-Cron allows you to schedule events and tasks within your WordPress site. 
//Method 1: Using the WP-Cron Functions:
//Open your theme's functions.php file and use the wp_schedule_event function to schedule a custom function. For example, to run a function named my_cron_function every day:

// Schedule an event to run every day
add_action('my_custom_cron', 'my_cron_function');
if (!wp_next_scheduled('my_custom_cron')) {
    wp_schedule_event(time(), 'daily', 'my_custom_cron');
}

// Your custom function
function my_cron_function() {
    // Your code here
}


//Disable Default WP-Cron:
define('DISABLE_WP_CRON', true);


//Method 2: Set Up a System Cron Job:
//Disable Default WP-Cron:
define('DISABLE_WP_CRON', true);
//Set Up a System Cron Job:
//Schedule a system-level cron job to trigger WordPress cron. Add the following line to your server's crontab:
*/5 * * * * wget -q -O - http://yourdomain.com/wp-cron.php?doing_wp_cron >/dev/null 2>&1



//###################################################################################################################################


function thrv_custom_page_redirect1() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    elseif(is_page('host-profile') && is_user_logged_in() && current_user_can('host'))
    {
        wp_redirect(home_url('/host-profile'));
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect1');

function thrv_custom_page_redirect2() {
    // Check if it's the specific page you want to redirect from
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect2');




//#################################################################
<?php
function custom_post_statuses() {
    register_post_status('approved', array(
        'label' => _x('Approved', 'post'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
    ));

    register_post_status('rejected', array(
        'label' => _x('Rejected', 'post'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
    ));
}
add_action('init', 'custom_post_statuses');


function send_approval_rejection_email($new_status, $old_status, $post) {
    if ($new_status == 'approved' || $new_status == 'rejected') {
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Post Status Update';
        $message = "Your post titled '{$post->post_title}' has been {$new_status}.";
        wp_mail($to, $subject, $message);
    }
}
add_action('transition_post_status', 'send_approval_rejection_email', 10, 3);



