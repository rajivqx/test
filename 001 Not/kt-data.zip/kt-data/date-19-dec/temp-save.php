<?php



function send_rejection_email($new_status, $old_status, $post) {
    if ($new_status == 'rejected' && $old_status != 'rejected') {
        
        
        //$message = "We're sorry, but your post titled '{$post->post_title}' has been rejected.";

        $message = '<!DOCTYPE html>
        <html lang="en">
        
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Verify Account</title>
                <!-- css -->
                <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
            </head>
        
            <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
                <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                    <tbody>
                       
                        <tr>
                            <td>
                                <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ProviderName],</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">I hope you are doing well.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">Thank you for submitting your service, </strong>[ServiceName]</strong>, for inclusion on our </strong>[THRV Team]</strong>. We appreciate the time and effort you put into developing your offering.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> After careful consideration, we regret to inform you that we are unable to approve your service for listing at this time. This decision is based on [brief reason if applicable, e.g., "our current focus areas", "specific criteria not met"].</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> We value your contribution to the wellness community and encourage you to consider reapplying in the future. If you would like detailed feedback or guidance on how to align your service with our platform criteria, please feel free to reach out. We are more than happy to assist.

                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0;">Best regards,</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        
        </html>';
        
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Update on Your Service Submission to [THRV Team]';

        // Assuming $post_id is the ID of your custom post
        //$post_id = 123; // Replace with your custom post ID

        // Get the author ID of the custom post
        $author_id = get_post_field('post_author', $post_id);

        // Get the author name using the author ID
        $author_name = get_the_author_meta('display_name', $author_id);

        // Output or use the author name as needed
        //echo 'Author Name: ' . $author_name;

        // Get the custom post title using the post ID
        $custom_post_title = get_the_title($post_id);


        $data['provider_name']=$author_name;
        //$data['provider_name']="Rajiv Host";
        $data['service_name']=$custom_post_title;
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ProviderName]', '[ServiceName]'], [$user_data['provider_name'], $user_data['service_name']] $message);
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
        wp_mail($to, $subject, $htmlContent, $headers);
        
    }
}
add_action('transition_post_status', 'send_rejection_email', 10, 3);









/** 

function custom_post_statuses() {
    register_post_status('rejected', array(
        'label' => _x('Rejected', 'news'),
        'public' => true,
        'exclude_from_search' => false,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
    ));
}
add_action('init', 'custom_post_statuses');


function customize_news_approval_email($new_status, $old_status, $post) {
    if ($post->post_type === 'news' && $new_status == 'approved' && $old_status != 'approved') {
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Your News has been Approved and Published';
        $message = "Dear Author,\n\n";
        $message .= "Congratulations! Your news article titled '{$post->post_title}' has been approved and published by the administrator. ";
        $message .= "You can view it here: " . get_permalink($post->ID) . "\n\n";
        $message .= "Thank you,\nThe Administrator";

        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send the customized email
        wp_mail($to, $subject, $message, $headers);
    }
}
add_action('transition_post_status', 'customize_news_approval_email', 10, 3);
*/

function send_approval_email($new_status, $old_status, $post) {
    if ($post->post_type === 'experiences' && $new_status == 'approved' && $old_status != 'approved') {
        
        
        //$message = "We're sorry, but your post titled '{$post->post_title}' has been rejected.";

        $message = '<!DOCTYPE html>
        <html lang="en">
        
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Verify Account</title>
                <!-- css -->
                <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
            </head>
        
            <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
                <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                    <tbody>
                       
                        <tr>
                            <td>
                                <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ProviderName],</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">I hope you are doing well.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">We are thrilled to inform you that your submitted service, [Service Name], has been successfully reviewed and approved by our team. Your offering is now live on our [Platform Name] and accessible to our community.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> Your expertise and dedication to wellness are evident, and we are excited to showcase your service to our users. We believe it will make a significant impact on their wellness journey.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> Should you have any questions or need further assistance, please dont hesitate to reach out. We are here to support you.
                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> Thank you for being a vital part of our wellness community. We look forward to your continued success on [Platform Name].
                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0;">Best regards,</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        
        </html>';
        
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Congratulations! Your Service is Now Live on THRV';

        // Assuming $post_id is the ID of your custom post
        //$post_id = 123; // Replace with your custom post ID

        // Get the author ID of the custom post
        $author_id = get_post_field('post_author', $post_id);

        // Get the author name using the author ID
        $author_name = get_the_author_meta('display_name', $author_id);

        // Output or use the author name as needed
        //echo 'Author Name: ' . $author_name;

        // Get the custom post title using the post ID
        $custom_post_title = get_the_title($post_id);


        $data['provider_name']=$author_name;
        //$data['provider_name']="Rajiv Host";
        $data['service_name']=$custom_post_title;
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ProviderName]', '[ServiceName]'], [$data['provider_name'], $data['service_name']] $message);
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
        wp_mail($to, $subject, $htmlContent, $headers);
        
    }
}
add_action('transition_post_status', 'send_approval_email', 10, 3);
