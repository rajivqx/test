<?php
/**
 * Theme functions and definitions.
 *
 * For additional information on potential customization options,
 * read the developers' documentation:
 *
 * https://developers.elementor.com/docs/hello-elementor-theme/
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'HELLO_ELEMENTOR_CHILD_VERSION', '2.0.0' );

/**
 * Load child theme scripts & styles.
 *
 * @return void
 */
function hello_elementor_child_scripts_styles() {

	wp_enqueue_style(
		'hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css', [ 'hello-elementor-theme-style', ]
	);
	  // Enqueue your custom JavaScript file
	  wp_enqueue_script("google-map", "https://maps.googleapis.com/maps/api/js?key=AIzaSyDfeUIUxqX1xaNPuSqvc3sM2VVu8zkpbcQ&libraries=places", [], HELLO_ELEMENTOR_CHILD_VERSION, true);
	  wp_enqueue_script('custom-js', get_stylesheet_directory_uri() . '/custom.js', [], HELLO_ELEMENTOR_CHILD_VERSION, true); 

}
add_action( 'wp_enqueue_scripts', 'hello_elementor_child_scripts_styles', 20 );

function custom_login_redirect( $redirect_to, $request, $user ) {
    // Get the current user's role
    $user_role = $user->roles[0];
	// Set the URL to redirect users to based on their role
	if ( $user_role == 'host' ) {
		$redirect_to = '/host-profile/';
	}
	if ( $user_role == 'subscriber' ) {
		if (isset($_REQUEST['redirect_to']) && strpos($_REQUEST['redirect_to'],'/experiences/') !== false){
			$redirect_to = $_REQUEST['redirect_to'];
		}else{
			$redirect_to = '/';
		}
	}
    return $redirect_to;
}
add_filter( 'login_redirect', 'custom_login_redirect', 10, 3 );

//filter for distance

add_filter( 'jet-smart-filters/query/final-query', 'itchy_amend_map_query', 20 );
function itchy_amend_map_query( $query) {

	if(isset($query['geo_query'])){	
		$current_location = 'enable';
		$user_loc_lat = $query['geo_query']['latitude'];	
		$user_loc_long = $query['geo_query']['longitude'];
		//echo "hey i am geo user set";
	}

	// My filter Query ID is branch-map, only target this filter query, replace this with yours.
	if($query['jet_smart_filters'] == 'jet-engine-maps/branch-map-new' || $query['jet_smart_filters'] == 'jet-engine/branch-listing-new'){
		if( isset( $query['meta_query'] ) ) {
			//echo "hi i am inside it";
			$query_builder = \Jet_Engine\Query_Builder\Manager::instance();
			// My Geo Search query builder ID is 2, replace this with yours.
			if($query['jet_smart_filters'] == 'jet-engine-maps/branch-map-new'){
				$branch_geo_search_query = $query_builder->get_query_by_id(14);
			}			
			if($query['jet_smart_filters'] == 'jet-engine/branch-listing-new'){
				$branch_geo_search_query = $query_builder->get_query_by_id(16);
			}
			if( !$branch_geo_search_query->query ) return $query;

			// Set default query builder lat, lng and radius, make sure the geo search query has these values.
			$default = $branch_geo_search_query->query;
			$lat = ( isset( $default['geosearch_location']['lat'] ) )? $default['geosearch_location']['lat'] : 48.90556633542393;
			$lng = ( isset( $default['geosearch_location']['lng'] ) )? $default['geosearch_location']['lng'] : 32.601387079344406;
			$radius = ( isset( $default['geosearch_distance'] ) )? $default['geosearch_distance'] : 10000;

			$address = '';

			foreach( $query['meta_query'] as $meta_query => $SubmetaQuery) {

				$targetKey = 'itchy_search_by_radius_new';
				if (isset($SubmetaQuery['key']) && $SubmetaQuery['key'] === $targetKey) {
					
					$radius = absint( sanitize_text_field( trim( $SubmetaQuery['value'][0] ) ) );
					//echo $radius;
					$indexOfTarget = $meta_query;
					unset($query['meta_query'][$indexOfTarget]);
					break;
				}
			}
			
			// Make sure clear the meta query because we really dont want to search branch by any fields.
			// If you don't do this, the query will return empty result because no itchy_search_by_radius meta key is found.
			//unset( $query['meta_query']);

			if( $current_location == 'enable' ) {
				$lat = $user_loc_lat;
				$lng = $user_loc_long;
			
			}	
			$query['geo_query'] = array(
				'latitude'  => $lat,
				'longitude' => $lng,
				'distance'  => $radius,
			);
		

		}
	}
	//print_r($query);
	return $query;
}

// setting the default status of experiences to pending at the time of creation
add_action( 'save_post_experiences', 'set_post_default_category', 10,3 );

 function set_post_default_category( $post_id, $post, $update ) {
	global $wpdb;
	$prefix = $wpdb->prefix;

	$post_date = $post->post_date;
	$post_modified  = $post->post_modified;
	
	//if($post_date == $post_modified){
		$wpdb->update($prefix.'posts', array('post_status'=>'pending'), array('ID'=>$post_id));				
	//}
 }



// adding additional column to wp_list table
add_filter('manage_edit-experiences_columns','action_link_column_addition');
function action_link_column_addition($columns){
	$columns['approve_action'] = __('Approve Action','custom-column');
	return $columns;
}

// adding entites to newly created column
add_action('manage_experiences_posts_custom_column','display_column_entity',10,2);
function display_column_entity($column,$post_id){
	$post_status = get_post_status($post_id);
	if($column==='approve_action'){
		switch($post_status){
			case 'pending':
				echo '<a href="'.admin_url().'options-general.php?page=options_page_slug&postType=experiences&sta=publish&post_id='.$post_id.'">Approve</a> / <a href="'.admin_url().'options-general.php?page=options_page_slug&postType=experiences&sta=draft&post_id='.$post_id.'">Reject</a>';
				break;
			case 'publish':
				echo '<a href="'.admin_url().'options-general.php?page=options_page_slug&postType=experiences&sta=draft&post_id='.$post_id.'">Reject</a>';
				break;
			case 'draft':
				echo '<a href="'.admin_url().'options-general.php?page=options_page_slug&postType=experiences&sta=publish&post_id='.$post_id.'">Approve</a> ';
				break;
		}

	}
}

add_action( 'admin_menu', 'approval_action_page' );
function approval_action_page(){
		add_options_page(
			__( 'Page Title', 'textdomain' ),
			__( 'Circle Tree Login', 'textdomain' ),
			'manage_options',
			'options_page_slug',
			'approval_action'
		);
}

function approval_action(){
	global $wpdb;
	$current_user = wp_get_current_user();
	$post_id = $_GET['post_id'];
	$post_type = $_GET['postType'];
	$post_status = $_GET['sta'];
	$post = get_post($post_id);
	$post_addr = get_post_meta($post_id,'address',true);
	$prefix = $wpdb->prefix;
	$old_status = get_post_field( 'post_status', $post_id ); 
	if($_GET['post_id']){
		echo "hello".' <strong>'.$current_user->user_email.'</strong>'.'<br/><br/>';
		$up = $wpdb->update($prefix.'posts', array('post_status'=>$post_status),array('ID'=>$post_id));
		if($up){
			$author_id = get_post_field( 'post_author', $post_id ); 
			$user = get_userdata($author_id);
			$latlong = getLatLong($post_addr);
			update_post_meta($post_id,'884d9804999fc47a3c2694e49ad2536a_hash',md5($user->user_pass));
			update_post_meta($post_id,'884d9804999fc47a3c2694e49ad2536a_lat',$latlong['lat']);
			update_post_meta($post_id,'884d9804999fc47a3c2694e49ad2536a_lng',$latlong['lng']);
			send_rejection_email($post_status, $old_status, $post);
			echo '<strong>'.$post->post_title.'</strong> status is now changed'."<br/>";
			echo '<a href="'.admin_url('edit.php?post_status=publish&post_type=experiences').'">Go back -></a>';
		}
	}
	else{
		echo "Please check again, Something is wrong.";
	}
}
function getLatLong($address) {
    $apiKey = 'AIzaSyDfeUIUxqX1xaNPuSqvc3sM2VVu8zkpbcQ';
    $address = str_replace(' ', '+', $address);
    $apiUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=$address&key=$apiKey";
    $response = file_get_contents($apiUrl);
    $data = json_decode($response);
    if ($data->status == "OK") {
        $lat = $data->results[0]->geometry->location->lat;
        $lng = $data->results[0]->geometry->location->lng;

        return ['lat' => $lat, 'lng' => $lng];
    } else {
        return ['error' => 'Geocoding API request failed'];
    }
}

/*--------------------------------------------------------------
Get user phone no
-------------------------------------------------------------*/
function user_current_phone_number($attr) {
    	global $wpdb;
  
	if ( is_user_logged_in() ) {
		$user_id = get_current_user_id();
			
			$user_meta_data = $wpdb->get_row('SELECT DISTINCT it.meta_value FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 220 and e.user_id = '.$user_id.' and e.form_id = 25 and fi.type="phone" order by it.created_at DESC LIMIT 0,1');
	
		return $user_meta_data->meta_value;
	} else {
		return '';
	}
}
add_shortcode('usermeta', 'user_current_phone_number');

/*--------------------------------------------------------------
Get user phone no
-------------------------------------------------------------*/
function user_phone_number($attr) {
    	global $wpdb;
  	$value = shortcode_atts( array(
      'user_id' => 'user_id',
   ), $attr );
	if ( is_user_logged_in() ) {
			
			$user_meta_data = $wpdb->get_row('SELECT DISTINCT it.meta_value FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 220 and e.user_id = '.$value['user_id'].' and e.form_id = 25 and fi.type="phone" order by it.created_at DESC LIMIT 0,1');
	
		return $user_meta_data->meta_value;
	} else {
		return '';
	}
}
add_shortcode('user_phone_number', 'user_phone_number');

function user_avatar_value($attr) {
    global $wpdb;
	$value = shortcode_atts( array(
      'post_author' => 'post_author',
   ), $attr );

	if ( is_user_logged_in() ) {
		$user_image = get_avatar($value['post_author'], 96, '', '',  array('size' => 96, 'height' => 100, 'width' => 100));
	
		return $user_image;
	} else {
		return '';
	}
}
add_shortcode('user_avatar_value', 'user_avatar_value');

function post_author_data($attr) {
    global $wpdb;
	$value = shortcode_atts( array(
      'post_id' => 'post_id',
      'post_avatar' => 'post_avatar',
   ), $attr );
	$author_id = get_post_field('post_author' , $value['post_id']);
	if ( is_user_logged_in() ) {
		if($value['post_avatar'] == 1){
			$user_image = get_avatar( $author_id, 96, '', '',  array('size' => 96, 'height' => 100, 'width' => 100));
			return $user_image;
		}else{
			$user_info = get_userdata($author_id);
			return $user_info->display_name;
		}
	} else {
		return '';
	}
}
add_shortcode('post_author_data', 'post_author_data');

function booking_details_link($attr) {
    global $wpdb;
	$value = shortcode_atts( array(
      'appointment_id' => 'appointment_id',
   ), $attr );

	if ( is_user_logged_in() ) {
		$user_id = get_current_user_id();
		$user_meta_data = $wpdb->get_row('SELECT * FROM wp_posts AS posts INNER JOIN wp_jet_appointments AS jet_appointments ON posts.ID = jet_appointments.service WHERE jet_appointments.id = '.$value["appointment_id"].' AND posts.post_type = "experiences" LIMIT 0,1');
		$url = get_site_url().'/experiences/'.$user_meta_data->post_name.'?appointment_id='.$value["appointment_id"];
		return '<a href="'.$url.'">See Booking Details</a>';
	} else {
		return '';
	}
}
add_shortcode('booking_details_link', 'booking_details_link');

/*-------------------------------------
shortcode to obtain dynamic apointment detail
---------------------------------------*/

add_shortcode('booking-detail','booking_detail');
function booking_detail(){
	ob_start();
	global $wpdb;
	$appointment_id = $_GET['appointment_id'];
	$res = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."jet_appointments WHERE  ID='$appointment_id'");
	$service = $res->service;
	$post = get_post($service);
	$title = $post->post_title;
	$date = $res->date;
	$slot = $res->slot;
	$slot_end = $res->slot_end;
	//$tz = file_get_contents('https://ipinfo.io/?token=4cfdaf9a26641b');
	?>
     <div>
		<div><?php echo $title; ?></div>
		<div><?php echo get_post_meta($service,'experience-type',true);?></div>
	    <div>
			<input type="hidden" value="<?=$date?>" class="fetched-date">
			<input type="hidden" value="<?=$slot?>" class="fetched-time-start">
			<input type="hidden" value="<?=$slot_end?>" class="fetched-time-end">
			<div class="converted-date"><?php echo date('M d,Y',$date);?></div>
			<div><span class="converted-time-start"><?php echo date('h:i a',$slot);?></span> - <span class="converted-time-end"><?php echo date('h:i a',$slot_end);?></span></div>
		</div> 
	</div>
	<?php
	return ob_get_clean();
	
}

// Hide Top Bar For Subscriber
function tf_check_user_role( $roles ) {
    /*@ Check user logged-in */
    if ( is_user_logged_in() ) :
        /*@ Get current logged-in user data */
        $user = wp_get_current_user();
        /*@ Fetch only roles */
        $currentUserRoles = $user->roles;
        /*@ Intersect both array to check any matching value */
        $isMatching = array_intersect( $currentUserRoles, $roles);
        $response = false;
        /*@ If any role matched then return true */
        if ( !empty($isMatching) ) :
            $response = true;        
        endif;
        return $response;
    endif;
}
$roles = [ 'customer', 'subscriber', 'host' ];
if ( tf_check_user_role($roles) ) :
    add_filter('show_admin_bar', '__return_false');
endif;



add_filter('wsf_filter_tag', 'wsf_filter_function', 10, 2);
// Filter function
function wsf_filter_function($form, $submit) {
	echo '<pre>';
	print_r($form);
	echo '</pre>';
    // Set meta key for field ID 123 (Change this to your field ID)
    // $meta_key = 'field_123';
    // // Get value submit object
    // $field_value_old = $submit->meta[$meta_key]['value'];
    // // Do something with $field_value_old (This is just an example)
    // $field_value_new = str_replace('replace_this', 'with_this', $field_value_old);
    // // Set value in submit object
    // $submit->meta[$meta_key]['value'] = $field_value_new;
    // Return the submit object back to WS Form
    return $submit;
}

/*-------------------------------------
shortcode to obtain Appointment post(experience) meta_value
---------------------------------------*/

function post_meta_appointment($attr){
	global $wpdb;
	$value = shortcode_atts( array(
      'meta_key' => 'meta_key',
      'appointment_id' => 'appointment_id',
      'booking_tab' => 'booking_tab',
   ), $attr );

	$res = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."jet_appointments WHERE  ID=".$value['appointment_id']."");
	$service = $res->service;
	$experience_type = get_post_meta($service,'experience-type',true);
	// $user_tz = wp_timezone_string();
	$user_tz1 = get_user_tz();
	$user_tz =  $_COOKIE['visitortimezone'];
	$current_datetime_utc = date('m/d/Y H:i:s');
	$slot_datetime_utc = date('m/d/Y H:i:s', $res->slot);
	$slot_end_datetime_utc = date('m/d/Y H:i:s', $res->slot_end);

	$current_datetime_user_tz = new DateTime($current_datetime_utc, new DateTimeZone('UTC') );
	$current_datetime_user_tz->setTimeZone(new DateTimeZone($user_tz));
	$current_datetime_user_tz_format =  $current_datetime_user_tz->format('U');

	$slot_datetime_utc_user_tz = new DateTime($slot_datetime_utc, new DateTimeZone('UTC') );
	$slot_datetime_utc_user_tz->setTimeZone(new DateTimeZone($user_tz));
	$slot_datetime_utc_user_tz_format =  $slot_datetime_utc_user_tz->format('U');

	$slot_end_datetime_utc_user_tz = new DateTime($current_datetime_utc, new DateTimeZone('UTC') );
	$slot_end_datetime_utc_user_tz->setTimeZone(new DateTimeZone($user_tz));
	$slot_end_datetime_utc_user_tz_format =  $slot_end_datetime_utc_user_tz->format('U');

	$slot_date = $slot_datetime_utc_user_tz->format('M j, Y');
	$slot_time = $slot_datetime_utc_user_tz->format('h:i a');

	$post_meta = get_post_meta($service, $value['meta_key'], true);
	if($value['meta_key'] == 'video_call_url'){
		if($experience_type == 'inperson'){
			$experience_address = get_post_meta($service,'address',true);
			$style = '';
			if($value['booking_tab'] == 0){
				$style = 'style="text-align:left;"';
			}
			return '<div class="address-box"> <h6  '.$style.'>Address :</h6><p class="experience_address"  '.$style.'>' .$experience_address. '</p> </div>';
		}else{
			if($slot_datetime_utc_user_tz_format > $current_datetime_user_tz_format){
				return '<button id="join_on" class="join-date-info">Join on '.$slot_date.' '.$slot_time.'</button>';
			}elseif ($current_datetime_user_tz_format >= $slot_datetime_utc_user_tz_format && $current_datetime_user_tz_format <= $slot_end_datetime_utc_user_tz_format){
				return '<a href="'.$post_meta.'" id="join_now" class="join-event-btn" target="_blank">Join Now</a>';
			}
		}
	}
	return $post_meta;
	
}

add_shortcode('post_meta_appointment', 'post_meta_appointment');

function appointment_datetime_to_show($attr){
	global $wpdb;
	$value = shortcode_atts( array(
      'appointment_id' => 'appointment_id',
   ), $attr );
	$res = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."jet_appointments WHERE  ID=".$value['appointment_id']."");
	// $user_tz = wp_timezone_string();
	$user_tz1 = get_user_tz();
	$user_tz =  $_COOKIE['visitortimezone'];
	$slot_start_datetime_utc = date('m/d/Y H:i:s', $res->slot);
	$slot_end_datetime_utc = date('m/d/Y H:i:s', $res->slot_end);

	$slot_start_datetime_utc_user_tz = new DateTime($slot_start_datetime_utc, new DateTimeZone('UTC') );
	$slot_start_datetime_utc_user_tz->setTimeZone(new DateTimeZone($user_tz));

	$slot_end_datetime_utc_user_tz = new DateTime($slot_end_datetime_utc, new DateTimeZone('UTC') );
	$slot_end_datetime_utc_user_tz->setTimeZone(new DateTimeZone($user_tz));

	$slot_start_date = $slot_start_datetime_utc_user_tz->format('M j, Y');
	$slot_start_time = $slot_start_datetime_utc_user_tz->format('h:i a');
	$slot_end_time = $slot_end_datetime_utc_user_tz->format('h:i a');
	$slot_timezone = $slot_start_datetime_utc_user_tz->format('T');

	return $slot_start_date.' | '.$slot_start_time.' - '.$slot_end_time.' '.$slot_timezone;
	
}

add_shortcode('appointment_datetime_to_show', 'appointment_datetime_to_show');

function get_user_tz(){
	?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
   	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.39/moment-timezone-with-data-10-year-range.js"></script>
	<script>
		var visitortime = new Date().getTimezoneOffset();;
        var visitortimezone = moment.tz.guess();
        document.cookie = "visitortimezone = "+visitortimezone;
	<?php
	$user_tz = "<script>document.writeline(visitortimezone)</script>"?> 
	</script>
	<?php
	return $user_tz;
}

function get_modal_popup($attr){
	global $wpdb;
	$value = shortcode_atts( array(
      'appointment_id' => 'appointment_id',
   ), $attr );
	$res_jet_appointments = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."jet_appointments WHERE  ID=".$value['appointment_id']."");
	// $user_tz = wp_timezone_string();
	$user_tz1 = get_user_tz();
	$user_tz =  $_COOKIE['visitortimezone'];
	$current_datetime_utc = date('m/d/Y H:i:s');
	$slot_datetime_utc = date('m/d/Y H:i:s', $res_jet_appointments->slot);

	$current_datetime_user_tz = new DateTime($current_datetime_utc, new DateTimeZone('UTC') );
	$current_datetime_user_tz->setTimeZone(new DateTimeZone($user_tz));
	$current_datetime_user_tz_format =  $current_datetime_user_tz->format('U');

	$slot_datetime_utc_user_tz = new DateTime($slot_datetime_utc, new DateTimeZone('UTC') );
	$slot_datetime_utc_user_tz->setTimeZone(new DateTimeZone($user_tz));
	$slot_datetime_utc_user_tz_format =  $slot_datetime_utc_user_tz->format('U');

	if($slot_datetime_utc_user_tz_format <= $current_datetime_user_tz_format){
		return '';
	}

	$res = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."jet_appointments_meta WHERE  appointment_id=".$value['appointment_id']." and meta_key='_cancel_url'");
	return '<div class="elementor-element elementor-element-68431ed elementor-widget elementor-widget-bdt-modal" data-id="68431ed" data-element_type="widget" 					data-widget_type="bdt-modal.default">
				<div class="elementor-widget-container"  style="text-align: center;">
					<div class="bdt-modal-wrapper">
						<a class="bdt-modal-button elementor-button elementor-size-sm" data-bdt-toggle="target: #bdt-modal-'.$value['appointment_id'].'" href="javascript:void(0)" role="button"  style=" color: #FF6060; background: unset;">
							<span class="elementor-button-text">Cancel Booking</span>
						</a>
					</div>
				</div>
			</div>
			<div id="bdt-modal-'.$value['appointment_id'].'" class="bdt-modal-68431ed bdt-modal bdt-flex-top cancel-appointment" data-bdt-modal="" data-settings="{&quot;id&quot;:&quot;bdt-modal-68431ed&quot;,&quot;widgetId&quot;:&quot;bdt-modal-68431ed&quot;,&quot;layout&quot;:&quot;default&quot;,&quot;splashDelay&quot;:false,&quot;splashInactivity&quot;:false,&quot;displayTimes&quot;:false,&quot;displayTimesExpire&quot;:12,&quot;cacheOnAdmin&quot;:false,&quot;scrollDirection&quot;:false,&quot;scrollOffset&quot;:false,&quot;scrollSelector&quot;:false,&quot;modal_id&quot;:&quot;#bdt-modal-68431ed&quot;,&quot;custom_section&quot;:false,&quot;closeBtnDelayShow&quot;:false,&quot;delayTime&quot;:false,&quot;pageID&quot;:663}" tabindex="-1">
				<div class="bdt-modal-dialog bdt-margin-auto-vertical" role="dialog" aria-modal="true">
					<button class="bdt-modal-close-default elementor-animation- bdt-icon bdt-close" id="bdt-modal-close-button" type="button" data-bdt-close="" aria-label="Close"><svg width="14" height="14" viewBox="0 0 14 14"><line fill="none" stroke="#000" stroke-width="1.1" x1="1" y1="1" x2="13" y2="13"></line><line fill="none" stroke="#000" stroke-width="1.1" x1="13" y1="1" x2="1" y2="13"></line></svg>
					</button>
					<div class="bdt-modal-header bdt-text-center">
						<h3 class="bdt-modal-title">Cancel Booking?</h3>
					</div>
					<div class="bdt-modal-body bdt-text-center bdt-overflow-auto" bdt-overflow-auto="" style="min-height: 150px; max-height: 435.812px;">
						Your booking will be canceled and you won’t be able to have this experience!
						<a class="button danger-button cancel_booking_btn" href="javascript:void(0)" data-appointment_id="'.$value['appointment_id'].'">Cancel Booking</a>
					</div>
					<div class="bdt-modal-footer bdt-text-left">
						<button class="bdt-modal-close-default elementor-animation- bdt-icon bdt-close close-modal-btn" id="bdt-modal-close-button" type="button" data-bdt-close="" aria-label="Close"> Cancel <svg width="14" height="14" viewBox="0 0 14 14"><line fill="none" stroke="#000" stroke-width="1.1" x1="1" y1="1" x2="13" y2="13"></line><line fill="none" stroke="#000" stroke-width="1.1" x1="13" y1="1" x2="1" y2="13"></line></svg>
						</button>
					</div>
				</div>
			</div>';
}
add_shortcode('get_modal_popup', 'get_modal_popup');

function current_datetime_timestamp($attr){
	$current_datetime_utc = date('U');
	// $current_datetime_user_tz = new DateTime($current_datetime_utc, new DateTimeZone('UTC') );
	// $current_datetime_user_tz_format =  $current_datetime_user_tz->format('Y/m/d h:i:s');
	return $current_datetime_utc;
}

add_shortcode('current_datetime_timestamp', 'current_datetime_timestamp');

function get_data_toshow_appointment($attr){
	$appointment_type = '';
	$value = shortcode_atts( array(
      'appointment_type' => 'appointment_type',
   ), $attr );
	if($value['appointment_type'] == 'completed'){
		$appointment_type = 'Confirmed';
	}elseif($value['appointment_type'] == 'virtual'){
		$appointment_type = 'Online';
	}else{
		$appointment_type = 'In-Person';
	}
	return $appointment_type;
}

add_shortcode('get_data_toshow_appointment', 'get_data_toshow_appointment');


add_action('wp_logout','auto_redirect_after_logout');

function auto_redirect_after_logout(){
  wp_safe_redirect( home_url() );
  exit;
}

add_shortcode('makeCalender','make_calender');
function make_calender($atts) {
		
		
		$atts = shortcode_atts( array(
		'post_id' => 'post_id',
	), $atts );


	?>
  	<div class="booking-detail-calender">
        <div  id="datepicker"></div>
        <input type="hidden" value="<?php echo get_the_title($atts['post_id'])?>" id="post_title"/>
        <input type="hidden" value="<?=$atts['post_id']?>" class="currentPostId" id="currentPostId">
		<input type="hidden" class="currentSlotId" id="currentSlotId">
		<input type="hidden"  id="slotDate">
    </div>
	<?php 
	$redirect = home_url() . '/login?redirect_to=' . urlencode( $_SERVER['REQUEST_URI'] );
	if (is_user_logged_in() && loggedin_user_role()) {
				echo '<div class="booking-slots-info"><div id="selectSlots" class=""></div><button class="button" disabled="true" id="paynow">Book Now</button><div id="bottom-detail"></div>
				</div>';
			} else {
				echo '<div class="booking-slots-info"><div id="selectSlots" class=""></div><a class="button" href="'.$redirect.'">Sign Up to Book</a><div id="bottom-detail"></div>
				</div>';
	  		}
 }

function loggedin_user_role() {
	$roles = ['subscriber'];
    /*@ Check user logged-in */
    if (is_user_logged_in() ){
        /*@ Get current logged-in user data */
        $user = wp_get_current_user();
        /*@ Fetch only roles */
        $currentUserRoles = $user->roles;
        /*@ Intersect both array to check any matching value */
        $isMatching = array_intersect( $currentUserRoles, $roles);
        $response = false;
        /*@ If any role matched then return true */
        if ( !empty($isMatching) ) {
			$response = true;
		}
        return $response;
	}
}



function initialize_datepicker() {
	global $wpdb;
	$post_id = get_the_ID();
	$disabled_id = get_post_meta($post_id,'day_off',true);
	$working_id = get_post_meta($post_id,'working_days',true);
	$slotsArr = [];
	$workingArr = [];
	$table = $wpdb->prefix.'exp_day_off';
	$res = $wpdb->get_results("SELECT * FROM ".$table." WHERE ins_id='$disabled_id'");

	$table2 = $wpdb->prefix.'exp_day_working';
	$res2 = $wpdb->get_results("SELECT * FROM ".$table2." WHERE ins_id='$working_id'");
	foreach($res2 as $entity2){
		$workingArr[] = [
			'day_work_start'=>strtotime($entity2->day_work_start),
			'day_work_end'=>strtotime($entity2->day_work_end)
		];
	}

	foreach($res as $entity){
		$slotsArr[] = [
			'start'=>strtotime($entity->day_off_start),
			'end'=>strtotime($entity->day_off_end)
		];
	}


    $slots = json_encode($slotsArr);
	$slotWorking = json_encode($workingArr);
    ?>
    <script>
	    jQuery("body").on("click", ".appointment-slot", function () {
			let curr = jQuery(this);
			let price = curr.data('price');
			let priceToShow = curr.data('price-to-show');
			let date = curr.data('date');
			let text = curr.text();
			let postTitle = jQuery('#post_title').val();
			let number = curr.data('number');
			let slotId = curr.data('slot_id');
			let remaining = curr.data('remaining');
			let detString = '<div class="post-title">';
			detString+= '<h6>'+postTitle+'</h6>';
			detString+='<div class="group-row">';
			detString+='<div class="date-time-wrp"><span>'+date+'</span><span>'+text+'</span></div>';
			if(number){
				detString+='<div class="number-fo-join">'+number+' person group </div>';
			}
			if(remaining){
				detString+='<div class="date-time-wrp"><span>'+remaining+' person remaining</span></div>';
			}
			detString+='</div>';
			detString+='</div>';
			jQuery('#bottom-detail').html(detString);
            jQuery('#bottom-detail').addClass("booking-item-info");
			jQuery('#paynow').text("Pay "+priceToShow);
			jQuery('#paynow').removeAttr('disabled');
            jQuery('#paynow').addClass("pay-now-btn");
			jQuery('#currentSlotId').val(''+slotId+'');
			jQuery('#slotDate').val(''+date+'');

            // Add/Remove Appointement Slot
            jQuery(".slot-list-wrp .appointment-slot").removeClass('selected');
            jQuery(curr).addClass('selected');
            
		})

			
		function DisableDates(date) {
			let slotArr = '<?php echo $slots ?>';
			let slotWorking = '<?php echo $slotWorking;?>';
			let slotWorkingList = JSON.parse(slotWorking);
			
			let slotList = JSON.parse(slotArr);
			let slotW
			var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
			const d = new Date(string);
			let stringStamp = d.getTime()/1000;
			//console.log(stringStamp);
			let k = 0;
             console.log(slotList,"slot Off");
			if(slotWorkingList.length > 0){
				k = 1;
				for(let j=0;j<slotWorkingList.length;j++){
					let slotWorking = slotWorkingList[j];
					if(parseInt(stringStamp) >= parseInt(slotWorking.day_work_start) && parseInt(stringStamp) <= parseInt(slotWorking.day_work_end) ){
						k = 0;
						for(let l=0;l<slotList.length;l++){
							let slotOff =slotList[l];
							if(parseInt(stringStamp) >= parseInt(slotOff.start) && parseInt(stringStamp) <= parseInt(slotOff.end) ){
								k = 1
								break;
							}
						}
						break;
					}
				}
			 }
			else{
				for(let m=0;m<slotList.length;m++){
					let slot =slotList[m];
					if(parseInt(stringStamp) >= parseInt(slot.start) && parseInt(stringStamp) <= parseInt(slot.end) ){
						k = 1
						break;
					}
					break;

				}
			}

			//console.log(k);
	
		    return [k==0];
		
		}
        jQuery(document).ready(function($) {
			//$("#datepicker").datepicker();
            $("#datepicker").datepicker({
				minDate: 0,
				dateFormat: 'd M yy',
				beforeShowDay:DisableDates,
        		onSelect: function(dateText, inst) {
					var selectDate = dateText;
					const minDat = dateText;
					
					$("#paynow").text("Book Now");
					$("#paynow").attr("disabled","true");
					

					$.ajax({
						url: '<?php echo get_stylesheet_directory_uri()?>/helper/appointmentCalender.php',
						method: "POST",
						data: {selectDate,currentPostId:parseInt('<?=$post_id?>')},
						success: function(data) {
							$('#bottom-detail').empty();
								
							if ($.trim(data) === '') {
								$('#selectSlots').html("No Result Found");
							    $('#paynow').text('Book Now');
								jQuery('#paynow').addClass("button");
								$('#paynow').attr('disabled','disabled');
								$(".booking-slots-info").addClass("no-result");
							} else {
								$('#selectSlots').html(data);
								$(".booking-slots-info").addClass("show");
								$(".booking-slots-info").removeClass("no-result");
							}
						},
						error: function(xhr, status, error) {
							console.error("Error: " + status, error);
						}
					});
        		}
      		});
        });
		jQuery("body").on('click','#paynow',function(e){
			e.preventDefault();
			let slotId = jQuery('#currentSlotId').val();
			let postId = jQuery('#currentPostId').val();
			let slotDate = jQuery('#slotDate').val();
			let url = '<?=home_url()?>/stripe-form/?postId='+postId+'&slotId='+slotId+'&slotDate='+slotDate;
			window.location.href=url;
 		})

		/*jQuery("body").on('touchstart','.ui-datepicker-next',function(){
			alert("hello")
		 })

		jQuery(".ui-datepicker-next").click(function(){
			alert("hello");
		})*/
    </script>
    <?php
}
add_action('wp_footer', 'initialize_datepicker');

function formidable_entry_by_post($attr) {
    	global $wpdb;
        $post_id = get_the_ID();
        $entry_id = $wpdb->get_var("SELECT id FROM wp_frm_items WHERE post_id='".$post_id."'");
        
	return $entry_id;
}
add_shortcode('thrv-frm-field-value', 'formidable_entry_by_post');


add_shortcode('currentPostStatus','get_current_post_status');

	function get_current_post_status($atts) {
		
		$atts = shortcode_atts( array(
			'post_id' => 'post_id',
		), $atts );

	return get_post_status( $atts['post_id']);

}
add_shortcode('currentUserBookingsCalender','get_user_bookings_calender');

	function get_user_bookings_calender($atts) {
		
		if ( is_user_logged_in() ) {
			$current_user_id = get_current_user_id();
			//return $current_user_id;
		} else {
			//return '';
		}?>
		<div class="booking-detail-calender">
        <div  id="datepicker1"></div>
        <input type="hidden" value="<?php echo $current_user_id?>" id="current_user_id"/>
    </div>


<?php }
function initialize_datepicker_show_host_bookings() {
    ?>
    <script>
	    
        jQuery(document).ready(function($) {
			var currentDate = new Date();

    		// Format the current date as per the datepicker's dateFormat
    		var formattedCurrentDate = $.datepicker.formatDate('d M yy', currentDate);

 
            $("#datepicker1").datepicker({
				minDate: 0,
				dateFormat: 'd M yy',
				//defaultDate: currentDate,
				dateText: new Date(),
        		onSelect: function(dateText, inst) {
					var selectDate = dateText;
					//const minDat = dateText;
					var showSelectDate = "My slots for "+selectDate;
					$('.elementor-element-f72fef1 .elementor-heading-title').html(showSelectDate);
					var user_id = $('#current_user_id').val();
					$.ajax({
						url: '<?php echo get_stylesheet_directory_uri()?>/helper/hostAppointmentCalender.php',
						method: "POST",
						data: {selectDate,user_id},
						//dataType:'HTML',
						success: function(data) {
							var res = JSON.parse(data);
							
								$('#my-slots').html(res);
						},
						error: function(xhr, status, error) {
							console.error("Error: " + status, error);
						}
					});
        		}
      		 });
			$("#datepicker1").datepicker("setDate", formattedCurrentDate);
    		$('.ui-datepicker-current-day').click(); // rapresent the current selected day
        });
    </script>
    <?php
}
add_action('wp_footer', 'initialize_datepicker_show_host_bookings');

add_shortcode('booking_slot_type', 'booking_slot_type');

function booking_slot_type($attr){
	global $wpdb;
	$slot_type = '';
	$value = shortcode_atts( array(
      'group_id' => 'group_id',
   ), $attr );
	if($value['group_id'] == NULL){
		$slot_type = 'Personal';
	}else{
		$res_temp_slot_expType = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."temp_slot WHERE  id=".$value['group_id']."");
		if($res_temp_slot_expType->expType == 'in-person'){
			$slot_type = 'Personal';
		}else{
			$slot_type = $res_temp_slot_expType->expType;
		}
	}
	return $slot_type;
}


// add_action('frm_after_update_entry', 'log_entry_data', 10, 2);

// function log_entry_data($entry_id, $form_id){
// 	if($form_id == '11'){
// 		$entry_data = FrmEntry::getOne($entry_id, true);

// 		$post_id = $entry_data->post_id;

// 		$post_data = array(
// 			'ID'          => $post_id,
// 			'post_status' => 'pending', // Set the desired status here
// 		);

// 		wp_update_post($post_data);
// 		//echo '</pre>';
// 	}
    
// }

function get_current_user_fav_backup($atts) {
	$redirect = home_url() . '/login?redirect_to=' . urlencode( $_SERVER['REQUEST_URI'] );
	if (is_user_logged_in() && loggedin_user_role()) {
		echo FrmFormsController::get_form_shortcode( array( 'id' => 42 ) );
	} else {
		echo '<button type="button"><a href="'.$redirect.'"><i class="fa fa-heart-o"></i></a></button>';
	}
}
add_shortcode('currentUseType','get_current_user_fav');

function post_slug_data($attr) {
	global $wpdb;
	$value = shortcode_atts( array(
      'post_id' => 'post_id',
   ), $attr );
	$post_name = get_post_field('post_name' , $value['post_id']);
	return '<a href="https://thrv.app/experiences/'.$post_name.'">';

}
add_shortcode('post_slug_data', 'post_slug_data');

function get_current_user_fav($atts) {
	global $wpdb;
	$redirect = home_url() . '/login?redirect_to=' . urlencode( $_SERVER['REQUEST_URI'] );
	$value = shortcode_atts( array(
      'post_id' => 'post_id',
   ), $atts );
	$current_user = wp_get_current_user();
	$user_meta_data = $wpdb->get_row('SELECT DISTINCT * FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 474 and it.meta_value = '.$value['post_id'].' and e.user_id = '.$current_user->id.' and e.form_id = 42 order by it.created_at DESC LIMIT 0,1');
	if (is_user_logged_in() && loggedin_user_role()) {
		if(!empty($user_meta_data)){
			echo '<button type="button" class="frm_final_submit1" data-post_id="'.$value['post_id'].'"><i class="fa fa-heart" style="color: red;"></i></button>';
			echo '<div style="display:none;">'.FrmFormsController::get_form_shortcode( array( 'id' => 42 ) ).'</div>';

		}else{
			echo FrmFormsController::get_form_shortcode( array( 'id' => 42 ) );
		}
	} else {
		echo '<button type="button"><a href="'.$redirect.'"><i class="fa fa-heart-o"></i></a></button>';
	}
}
add_shortcode('get_current_user_fav_backup', 'get_current_user_fav_backup');


//to make category as required field before submission
// function custom_validate_field($errors, $posted_field, $posted_value) {
// 	//add_filter('frm_continue_submission', '__return_false');
//     if ($posted_field->id == 113 && $posted_value == 0 ) {
//         // Add a custom error message
//         print_r("field is found here");
// 		print_r($posted_value);
// 		$errors['field' . $posted_field->id] = 'Please fill in the dynamically created field.';
// 		//add_action('frm_submit_entry', 'custom_display_error_script', 10, 2);
//     }
//      return $errors;
// }

// add_filter('frm_validate_field_entry', 'custom_validate_field', 10, 3);


// Rajiv Custome code starting from here............................
//Email Custom Template Function for review rating
function thrv_email_template_feedback() {
            
    $timestamp = time();
    global $wpdb;
    $table_name = $wpdb->prefix . 'jet_appointments';
    // Your SQL query
	$sql = "SELECT * FROM wp_posts AS posts INNER JOIN wp_jet_appointments AS jet_appointments ON posts.ID = jet_appointments.service LEFT JOIN wp_postmeta AS postmeta ON posts.ID = postmeta.post_id  
	WHERE posts.post_type = 'experiences' AND postmeta.meta_key = 'experience-type' AND jet_appointments.slot_end < '".$timestamp."' AND jet_appointments.status = 'completed' and feedback_status IS NULL 
	ORDER BY  CAST( jet_appointments.slot as DECIMAL ) DESC LIMIT 6";

    // Fetch results
    $results = $wpdb->get_results($sql);
    // Loop through the users and send email to each one
    foreach ($results as $appointment_detail) {
       
        $user = get_user_by( 'ID', $appointment_detail->user_id);
		$host = get_user_by( 'ID', $appointment_detail->by_user);
        $userId = $appointment_detail->user_id;
        $appointmentId = $appointment_detail->ID;
        $feedback_status = $appointment_detail->feedback_status;
        $to = $user->user_email;
        
        //$to = "neeraj.sharma@yopmail.com";
        $subject = 'Share Your Feedback on Your Recent Session';
        // Add URL to the email body

    $htmlTemplate='<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Verify Account</title>
            <!-- css -->
            <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
        </head>
        <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
            <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                <tbody>
                    <tr>
                        <td>
                            <img style="margin-bottom: 26px; height: 37px;" title="logo" alt="logo" src="[ThrvLogo]" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ClientName],</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;">We hope you enjoyed your recent session with <strong> [ProviderName]! </strong></p>
                            <p style="margin: 0 0 16px;"> Your feedback is crucial in helping us maintain the quality of our services. Please rate your experience: </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 16px;"> ⭐⭐⭐⭐⭐</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="display: flex;">
                            <a href="https://thrv.app/user-profile/" style="color: #fff; padding: 16px 44px; border-radius: 36px; background: #25394A; font-weight: 600; text-decoration: none;  margin: 0 0 30px;">Rate Your Session</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;"> Your rating helps ensure our providers are meeting the high standards our community expects. </p>
                            <p style="margin: 0 0 16px;"> Want to share more about your experience? Feel free to leave a detailed review <a href="https://thrv.app/user-profile/" style="color:#0096FF;" > here</a> </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0;">Thank you for helping us create a better wellness community on THRV Team.</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </body>
    </html>';

		
        $user_data['client_name']= isset($user->user_login)?$user->user_login:'User';
        $user_data['provider_name']= isset($host->user_login)?$host->user_login:'Host';
        $thrv_logo="https://thrv.app/wp-content/uploads/2022/03/logo.png";
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ClientName]', '[ProviderName]', '[ThrvLogo]'],
		[$user_data['client_name'], $user_data['provider_name'], $thrv_logo], $htmlTemplate);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        //wp_mail($to, $subject, $htmlContent, $headers);
        // Send email
        if($feedback_status != 1)
        {
            wp_mail($to, $subject,  $htmlContent, $headers);
            $sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";
            $wpdb->query($sql2);
            echo "mail sent for".$appointmentId."</br>";
        }
        
    }
}
add_action( 'ask_feedback_email_func', 'thrv_email_template_feedback' );
//Page Redirection host profile
function thrv_custom_page_redirect_host() {
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('host-profile') && is_user_logged_in() && current_user_can('subscriber')) {
        // Redirect logged-in users with 'host' capability to '/host-profile'
        wp_redirect(home_url('/user-profile'));
        exit();
    }

    // Add some debugging statements
    error_log("Conditions not met for redirection on 'host-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect_host');
//Page Redirection user profile
function thrv_custom_page_redirect_user() {
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('user-profile') && is_user_logged_in() && current_user_can('host')) {
		wp_redirect(home_url('/host-profile'));
        exit();
    }
	
    // Add some debugging statements
    error_log("Conditions not met for redirection on 'user-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect_user');

function get_rating_modal_button($attr){
	global $wpdb;
	$value = shortcode_atts( array(
      'appointment_id' => 'appointment_id',
      'on_hover_item' => 'on_hover_item',
      'font_size' => 'font_size',
   ), $attr );
	$current_user = wp_get_current_user();
	$res_jet_appointments = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."jet_appointments WHERE  ID=".$value['appointment_id']."");

	$user_appointment_rating_data = $wpdb->get_row('SELECT DISTINCT * FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 493 and it.meta_value = '.$value['appointment_id'].' and e.user_id = '.$current_user->id.' and e.form_id = 44 order by it.created_at DESC LIMIT 0,1');
	if(!$user_appointment_rating_data && $value['on_hover_item'] == 1){
		//return rating modal Button
		return '<div class="elementor-element elementor-element-447cda2 add_review elementor-widget elementor-widget-bdt-modal" data-id="447cda2" data-element_type="widget" data-widget_type="bdt-modal.default">
			   <div class="elementor-widget-container">
			      <div class="bdt-modal-wrapper">
			         <a class="bdt-modal-button add-rating-btn elementor-button elementor-size-sm" data-appointment_id="'.$value['appointment_id'].'" data-post_id="'.$res_jet_appointments->service.'" data-bdt-toggle="target: #bdt-modal-447cda2" href="javascript:void(0)" role="button">
			            <!-- <span > -->
			            <span class="elementor-button-text">  Add Review</span>
			            <!-- </span> -->
			         </a>
			      </div>
			   </div>
			</div>';
	}else{
		//return stars rating
		$user_appointment_rating_stars = $wpdb->get_row('SELECT DISTINCT it.meta_value FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 479 and e.id = '.$user_appointment_rating_data->item_id.' and e.user_id = '.$current_user->id.' and e.form_id = 44 order by it.created_at DESC LIMIT 0,1');
		$user_rating = $user_appointment_rating_stars->meta_value;
		// echo '<div>';
		for ($i=0; $i < $user_rating  ; $i++) { 
			echo '<i class="fa fa-star mlr-3" style="color:black; font-size:'.$value['font_size'].';"></i>';
		}
		for ($i=0; $i < (5-$user_rating)  ; $i++) { 
			echo '<i class="fa fa-star-o mlr-3" style="color:black; font-size:'.$value['font_size'].';"></i>';
		}
		// echo '</div>';
	}
}
add_shortcode('get_rating_modal_button', 'get_rating_modal_button');

function get_rating_modal_popup($attr){
	
	echo '
		<div id="bdt-modal-447cda2" class="bdt-modal-447cda2 rating-modal bdt-modal bdt-flex-top" data-bdt-modal="" data-settings="{&quot;id&quot;:&quot;bdt-modal-447cda2&quot;,&quot;widgetId&quot;:&quot;bdt-modal-447cda2&quot;,&quot;layout&quot;:&quot;default&quot;,&quot;splashDelay&quot;:false,&quot;splashInactivity&quot;:false,&quot;displayTimes&quot;:false,&quot;displayTimesExpire&quot;:12,&quot;cacheOnAdmin&quot;:false,&quot;scrollDirection&quot;:false,&quot;scrollOffset&quot;:false,&quot;scrollSelector&quot;:false,&quot;modal_id&quot;:&quot;#bdt-modal-447cda2&quot;,&quot;custom_section&quot;:false,&quot;closeBtnDelayShow&quot;:false,&quot;delayTime&quot;:false,&quot;pageID&quot;:6569}" tabindex="-1">
		   <div class="bdt-modal-dialog bdt-margin-auto-vertical" role="dialog" aria-modal="true">
		      <button class="bdt-modal-close-default elementor-animation- bdt-icon bdt-close" id="bdt-modal-close-button" type="button" data-bdt-close="" aria-label="Close">
		         <svg width="40" height="40" viewBox="0 0 40 40">
		            <line fill="none" stroke="#000" stroke-width="1.1" x1="1" y1="1" x2="13" y2="13"></line>
		            <line fill="none" stroke="#000" stroke-width="1.1" x1="13" y1="1" x2="1" y2="13"></line>
		         </svg>
		      </button>
		      <div class="bdt-modal-header bdt-text-left">
		         <h3 class="bdt-modal-title">Add Review</h3>
		      </div>
		      <div class="bdt-modal-body bdt-text-">
		         '.FrmFormsController::get_form_shortcode( array( 'id' => 44 ) ).'
		      </div>
		      <div class="bdt-modal-footer bdt-text-left">
		         <button class="bdt-modal-close-default elementor-animation- bdt-icon bdt-close close-modal-btn" id="bdt-modal-close-button" type="button" data-bdt-close="" aria-label="Close">
		            Cancel 
		         </button>
		      </div>
		   </div>
		</div>';
}
add_shortcode('get_rating_modal_popup', 'get_rating_modal_popup');

function get_average_rating($attr){
	global $wpdb;
	$value = shortcode_atts( array(
      'post_id' => 'post_id',
   ), $attr );

	$post_rating_data = $wpdb->get_row('SELECT count(*) as total_count FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 494 and it.meta_value = '.$value['post_id'].' and e.form_id = 44 order by it.created_at DESC');
	if($post_rating_data->total_count > 0){
		$user_appointment_rating_data = $wpdb->get_row('SELECT ROUND(AVG(it.meta_value), 1) as meta_value FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 479 and e.form_id = 44 order by it.created_at DESC');
		echo '<div class="rating-review-heading"> <i class="fa fa-star"></i> <p> <span>'.$user_appointment_rating_data->meta_value.'</span>'. $post_rating_data->total_count.' Ratings and reviews </p></div>';
	}else{
		echo "";
	}
}
add_shortcode('get_average_rating', 'get_average_rating');

function the_dramatist_return_post_id() {
    return get_the_ID();
}
add_shortcode( 'return_post_id', 'the_dramatist_return_post_id' );

function get_ratings($attr){
	global $wpdb;
	$value = shortcode_atts( array(
      'appointment_id' => 'appointment_id',
      'font_size' => 'font_size',
   ), $attr );

	$user_appointment_rating_data = $wpdb->get_row('SELECT DISTINCT * FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 493 and it.meta_value = '.$value['appointment_id'].' and e.form_id = 44 order by it.created_at DESC LIMIT 0,1');

	$user_appointment_rating_stars = $wpdb->get_row('SELECT DISTINCT it.meta_value FROM wp_frm_item_metas it JOIN wp_frm_fields fi ON it.field_id = fi.id JOIN wp_frm_items e ON e.id = it.item_id WHERE fi.id = 479 and e.id = '.$user_appointment_rating_data->item_id.' and e.form_id = 44 order by it.created_at DESC LIMIT 0,1');
	$user_rating = $user_appointment_rating_stars->meta_value;
	$rating = '';
	for ($i=0; $i < $user_rating  ; $i++) { 
		$rating .= '<i class="fa fa-star mlr-3" style="color:black; font-size:'.$value['font_size'].';"></i>';
	}
	for ($i=0; $i < (5-$user_rating)  ; $i++) { 
		$rating .= '<i class="fa fa-star-o mlr-3" style="color:black; font-size:'.$value['font_size'].';"></i>';
	}
	return '<p>'.$rating.'</p>';
}
add_shortcode('get_ratings', 'get_ratings');


/* Send Email on Approve and Reject */
function send_rejection_email($new_status, $old_status, $post) {
    if ($new_status == 'draft' && $old_status != 'draft') {
		$subject = 'Update on Your Service Submission to THRV.';
        $message = '<!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Verify Account</title>
                <!-- css -->
                <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
            </head>
            <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
                <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                    <tbody>
                    	<tr>
		            <td>
		             <img style="margin-bottom: 26px; height: 37px;" title="logo" alt="logo" src="[ThrvLogo]" />
		            </td>
                    	</tr>
                        <tr>
                            <td>
                                <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ProviderName],</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">I hope you are doing well.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">Thank you for submitting your service, </strong>[ServiceName]</strong>, for inclusion on our </strong>THRV</strong>. We appreciate the time and effort you put into developing your offering.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> After careful consideration, we regret to inform you that we are unable to approve your service for listing at this time.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> We value your contribution to the wellness community and encourage you to consider reapplying in the future. If you would like detailed feedback or guidance on how to align your service with our platform criteria, please feel free to reach out. We are more than happy to assist.

                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0;">Best regards,</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>';
	    }
		if ($new_status == 'publish' && $old_status != 'publish') {
		$subject = 'Congratulations! Your Service is Now Live on THRV';
		$message = '<!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Verify Account</title>
                <!-- css -->
                <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
            </head>
        
            <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
                <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                    <tbody>
                       <tr>
    		            <td>
    		             <img style="margin-bottom: 26px; height: 37px;" title="logo" alt="logo" src="[ThrvLogo]" />
    		            </td>
                    	</tr>
                        <tr>
                            <td>
                                <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ProviderName],</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">I hope you are doing well.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0 0 8px;">We are thrilled to inform you that your submitted service, [ServiceName], has been successfully reviewed and approved by our team. Your offering is now live on our THRV and accessible to our community.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> Your expertise and dedication to wellness are evident, and we are excited to showcase your service to our users. We believe it will make a significant impact on their wellness journey.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> Should you have any questions or need further assistance, please dont hesitate to reach out. We are here to support you.
                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p style="margin: 0 0 16px;"> Thank you for being a vital part of our wellness community. We look forward to your continued success on THRV.
                            </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin: 0;">Best regards,</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>';
		}

	if (($new_status == 'draft' && $old_status != 'draft')  || ($new_status == 'publish' && $old_status != 'publish')) {
        $to = get_the_author_meta('user_email', $post->post_author);
        // Get the author ID of the custom post
        $author_id = get_post_field('post_author', $post->ID);
        // Get the author name using the author ID
        $author_name = get_the_author_meta('display_name', $author_id);
        // Get the custom post title using the post ID
        $custom_post_title = get_the_title($post->ID);
        $data['provider_name']=$author_name;
        $data['service_name']=$custom_post_title;
        $thrv_logo="https://thrv.app/wp-content/uploads/2022/03/logo.png";
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ProviderName]', '[ServiceName]','[ThrvLogo]'], [$data['provider_name'], $data['service_name'],$thrv_logo],
		 $message);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        wp_mail($to, $subject, $htmlContent, $headers);
    }
}
