<?php


// Rajiv Custome code starting from here............................
//Email Custom Template Function for review rating
function thrv_email_template_feedback() {
            
    $timestamp = time();
    global $wpdb;
    $table_name = $wpdb->prefix . 'jet_appointments';
    // Your SQL query
	$sql = "SELECT * FROM wp_posts AS posts INNER JOIN wp_jet_appointments AS jet_appointments ON posts.ID = jet_appointments.service LEFT JOIN wp_postmeta AS postmeta ON posts.ID = postmeta.post_id  
	WHERE posts.post_type = 'experiences' AND postmeta.meta_key = 'experience-type' AND jet_appointments.slot_end < '".$timestamp."' AND jet_appointments.status = 'completed' and feedback_status IS NULL 
	ORDER BY  CAST( jet_appointments.slot as DECIMAL ) DESC LIMIT 6";

    // Fetch results
    $results = $wpdb->get_results($sql);
    // Loop through the users and send email to each one
    foreach ($results as $appointment_detail) {
       
        $user = get_user_by( 'ID', $appointment_detail->user_id);
		$host = get_user_by( 'ID', $appointment_detail->by_user);
        $userId = $appointment_detail->user_id;
        $appointmentId = $appointment_detail->ID;
        $feedback_status = $appointment_detail->feedback_status;
        $to = $user->user_email;
        
        //$to = "neeraj.sharma@yopmail.com";
        $subject = 'Share Your Feedback on Your Recent Session';
        // Add URL to the email body

    $htmlTemplate='<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Verify Account</title>
            <!-- css -->
            <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
        </head>
        <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
            <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                <tbody>
                    <tr>
                        <td>
                            <img style="margin-bottom: 26px; height: 37px;" title="logo" alt="logo" src="[ThrvLogo]" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ClientName],</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;">We hope you enjoyed your recent session with <strong> [ProviderName]! </strong></p>
                            <p style="margin: 0 0 16px;"> Your feedback is crucial in helping us maintain the quality of our services. Please rate your experience: </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 16px;"> ⭐⭐⭐⭐⭐</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="display: flex;">
                            <a href="https://thrv.app/user-profile/" style="color: #fff; padding: 16px 44px; border-radius: 36px; background: #25394A; font-weight: 600; text-decoration: none;  margin: 0 0 30px;">Rate Your Session</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;"> Your rating helps ensure our providers are meeting the high standards our community expects. </p>
                            <p style="margin: 0 0 16px;"> Want to share more about your experience? Feel free to leave a detailed review <a href="https://thrv.app/user-profile/" style="color:#0096FF;"> here</a> </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0;">Thank you for helping us create a better wellness community on THRV Team.</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </body>
    </html>';

		
        $user_data['client_name']= isset($user->user_login)?$user->user_login:'User';
        $user_data['provider_name']= isset($host->user_login)?$host->user_login:'Host';
        $thrv_logo="https://thrv.app/wp-content/uploads/2022/03/logo.png";
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ClientName]', '[ProviderName]', '[ThrvLogo]'],
		[$user_data['client_name'], $user_data['provider_name'], $thrv_logo], $htmlTemplate);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        //wp_mail($to, $subject, $htmlContent, $headers);
        // Send email
        if($feedback_status != 1)
        {
            wp_mail($to, $subject,  $htmlContent, $headers);
            $sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";
            $wpdb->query($sql2);
            echo "mail sent for".$appointmentId."</br>";
        }
        
    }
}
add_action( 'ask_feedback_email_func', 'thrv_email_template_feedback' );