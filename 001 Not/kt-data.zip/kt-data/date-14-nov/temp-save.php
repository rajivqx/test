<?php

/*
<?php $home_url = home_url(); ?>

<?php $home_url = home_url( '/about-us' ); ?>

<?php $home_url = home_url( '/contact', 'https' ); ?>


// Link for Help https://usersinsights.com/wordpress-login-redirect/

if (is_page('about-us')) {
        // Redirect to the new destination
        wp_redirect('https://example.com/new-about-us-page');

*/



function thrv_custom_page_redirect1() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    elseif(is_page('host-profile') && is_user_logged_in() && current_user_can('host'))
    {
        wp_redirect(home_url('/host-profile'));
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect1');

function thrv_custom_page_redirect2() {
    // Check if it's the specific page you want to redirect from
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect2');

